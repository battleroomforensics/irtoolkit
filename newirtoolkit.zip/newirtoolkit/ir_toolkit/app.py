"""
IR Toolkit — Flask backend
Run: python app.py
Then open: http://localhost:5000
"""

from flask import Flask, render_template, request, jsonify, send_file
import os, sys

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 500 * 1024 * 1024  # 500 MB upload limit

# ── Route: main UI ──────────────────────────────────────────────────────────
@app.route("/")
def index():
    return render_template("index.html")

# ── Native file / folder picker ─────────────────────────────────────────────
@app.route("/api/pick-path", methods=["POST"])
def pick_path():
    """
    Open a native OS file or folder dialog and return the selected path.
    POST body: { "mode": "folder" | "file", "title": "...", "initial": "..." }
    Uses tkinter which runs on the server (localhost), so the dialog appears
    on the user's desktop — exactly what we want for a local app.
    """
    data    = request.json or {}
    mode    = data.get("mode", "folder")   # "folder" or "file"
    title   = data.get("title", "Select path")
    initial = data.get("initial", "")
    filetypes = data.get("filetypes", [])  # e.g. [["CSV files", "*.csv"]]

    try:
        import tkinter as tk
        from tkinter import filedialog

        root = tk.Tk()
        root.withdraw()          # hide the root window
        root.attributes("-topmost", True)   # dialog appears on top

        if mode == "file":
            ft = [(label, pat) for label, pat in filetypes] if filetypes else [("All files", "*.*")]
            path = filedialog.askopenfilename(
                title=title,
                initialdir=initial if os.path.isdir(initial) else os.path.dirname(initial),
                filetypes=ft,
                parent=root,
            )
        elif mode == "files":
            ft = [(label, pat) for label, pat in filetypes] if filetypes else [("All files", "*.*")]
            paths = filedialog.askopenfilenames(
                title=title,
                initialdir=initial if os.path.isdir(initial) else os.path.dirname(initial),
                filetypes=ft,
                parent=root,
            )
            path = list(paths)
        else:  # folder
            path = filedialog.askdirectory(
                title=title,
                initialdir=initial if os.path.isdir(initial) else "",
                parent=root,
            )

        root.destroy()

        if not path:
            return jsonify({"cancelled": True, "path": None})
        return jsonify({"cancelled": False, "path": path})

    except ImportError:
        return jsonify({"error": "tkinter not available on this system"}), 500
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ── Register module blueprints ──────────────────────────────────────────────
from modules.yara_module     import yara_bp
from modules.hasher_module   import hasher_bp
from modules.ual_module      import ual_bp
from modules.artifact_module import artifact_bp
from modules.sigma_module    import sigma_bp

app.register_blueprint(yara_bp,     url_prefix="/api/yara")
app.register_blueprint(hasher_bp,   url_prefix="/api/hasher")
app.register_blueprint(ual_bp,      url_prefix="/api/ual")
app.register_blueprint(artifact_bp, url_prefix="/api/artifact")
app.register_blueprint(sigma_bp,    url_prefix="/api/sigma")

# ── Health check ────────────────────────────────────────────────────────────
@app.route("/api/health")
def health():
    return jsonify({"status": "ok", "version": "1.0.0"})

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))

    try:
        import yara
        _key_modules = {"pe", "elf", "math", "hash"}
        _missing = []
        for mod in _key_modules:
            probe = f'import "{mod}"\nrule probe{{condition: true}}'
            try:
                yara.compile(source=probe)
            except Exception:
                _missing.append(mod)
        if _missing:
            print(f"\n  ⚠  WARNING: yara-python is missing modules: {', '.join(sorted(_missing))}")
            print(f"     Rules using these modules will be skipped during scans.")
            print(f"     Run  python setup.py  to attempt a fix.\n")
        else:
            print(f"\n  ✓  yara-python modules OK: pe, elf, math, hash and more available\n")
    except ImportError:
        print("\n  ⚠  WARNING: yara-python not installed. Run python setup.py\n")

    print(f"  IR Toolkit running at http://localhost:{port}\n")
    app.run(host="127.0.0.1", port=port, debug=False)


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))

    # Warn if yara-python is missing key modules
    try:
        import yara
        _key_modules = {"pe", "elf", "math", "hash"}
        _missing = []
        for mod in _key_modules:
            probe = f'import "{mod}"\nrule probe{{condition: true}}'
            try:
                yara.compile(source=probe)
            except Exception:
                _missing.append(mod)
        if _missing:
            print(f"\n  ⚠  WARNING: yara-python is missing modules: {', '.join(sorted(_missing))}")
            print(f"     Rules using these modules will be skipped during scans.")
            print(f"     Run  python setup.py  to attempt a fix.\n")
        else:
            print(f"\n  ✓  yara-python modules OK: pe, elf, math, hash and more available\n")
    except ImportError:
        print("\n  ⚠  WARNING: yara-python not installed. Run python setup.py\n")

    print(f"  IR Toolkit running at http://localhost:{port}\n")
    app.run(host="127.0.0.1", port=port, debug=False)
