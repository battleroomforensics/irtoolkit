/* IR Toolkit — Frontend JS
   All data flows through the Flask backend at /api/*
   No fake simulation — real responses or clear errors.
*/

// ── Helpers ──────────────────────────────────────────────────────────────────
const $ = id => document.getElementById(id);

function toast(msg, duration=2800) {
  const t = $('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.remove('show'), duration);
}

function formatSize(n) {
  if (n < 1024) return n + ' B';
  if (n < 1048576) return (n/1024).toFixed(1) + ' KB';
  if (n < 1073741824) return (n/1048576).toFixed(2) + ' MB';
  return (n/1073741824).toFixed(2) + ' GB';
}

async function apiFetch(url, opts={}) {
  const resp = await fetch(url, opts);
  if (!resp.ok) {
    const body = await resp.json().catch(() => ({error: resp.statusText}));
    throw new Error(body.error || resp.statusText);
  }
  return resp;
}

function openModal(id)  { $(id).classList.add('open'); }
function closeModal(id) { $(id).classList.remove('open'); }

// ── Native path picker ───────────────────────────────────────────────────────
async function pickPath(mode, title, initial, filetypes) {
  try {
    const r = await apiFetch('/api/pick-path', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ mode, title, initial: initial || '', filetypes: filetypes || [] }),
    });
    const data = await r.json();
    if (data.error) { toast('Path picker error: ' + data.error); return null; }
    if (data.cancelled) return null;
    return data.path;
  } catch(e) {
    toast('Could not open file dialog: ' + e.message);
    return null;
  }
}

// Helper: attach a browse button to a text input
// Usage: addBrowseButton('my-input-id', 'folder', 'Select folder')
function addBrowseButton(inputId, mode, title, filetypes) {
  const inp = $(inputId);
  if (!inp || inp.dataset.browseAttached) return;
  inp.dataset.browseAttached = '1';
  const btn = document.createElement('button');
  btn.className = 'btn';
  btn.style.cssText = 'font-size:11px;padding:5px 9px;flex-shrink:0;white-space:nowrap';
  btn.textContent = '📂';
  btn.title = 'Browse…';
  btn.onclick = async () => {
    const path = await pickPath(mode, title, inp.value, filetypes);
    if (path) {
      inp.value = typeof path === 'string' ? path : path[0];
      inp.dispatchEvent(new Event('input'));
    }
  };
  // Wrap input and button in a flex row
  const wrap = document.createElement('div');
  wrap.style.cssText = 'display:flex;gap:6px;align-items:center';
  inp.parentNode.insertBefore(wrap, inp);
  wrap.appendChild(inp);
  wrap.appendChild(btn);
}

// ── NAV ──────────────────────────────────────────────────────────────────────
document.querySelectorAll('.nav-item').forEach(item => {
  item.onclick = () => {
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    item.classList.add('active');
    document.querySelectorAll('.module').forEach(m => m.classList.remove('active'));
    $('mod-' + item.dataset.mod).classList.add('active');
  };
});

// ═══════════════════════════════════════════════════════════════════
// YARA MODULE
// ═══════════════════════════════════════════════════════════════════
let _rules      = [];
let _editingId  = null;
let _ruleSearch = '';
let _rulePage   = 0;
let _rulePageSize = 10;

async function loadRules() {
  try {
    const [rulesResp, infoResp, modsResp] = await Promise.all([
      apiFetch('/api/yara/rules'),
      apiFetch('/api/yara/storage-info'),
      apiFetch('/api/yara/modules'),
    ]);
    _rules = await rulesResp.json();
    const info = await infoResp.json();
    const mods = await modsResp.json();

    const rfp = $('rules-file-path');
    const ydp = $('yar-dir-path');
    if (rfp) rfp.textContent = info.rules_file;
    if (ydp) ydp.textContent = info.yar_dir;

    // Show YARA module availability
    const modBox = $('yara-modules-info');
    if (modBox) {
      const avail   = mods.available || [];
      const unavail = mods.unavailable || [];
      modBox.innerHTML = `
        <strong style="color:var(--text)">YARA modules available:</strong>
        ${avail.map(m => `<span style="font-family:var(--font-mono);font-size:10px;padding:1px 6px;border-radius:4px;background:rgba(29,158,117,0.12);color:var(--accent)">${m}</span>`).join(' ')}
        ${unavail.length ? `&nbsp; <strong style="color:var(--text)">unavailable:</strong>
        ${unavail.map(m => `<span style="font-family:var(--font-mono);font-size:10px;padding:1px 6px;border-radius:4px;background:rgba(226,75,74,0.1);color:var(--danger)">${m}</span>`).join(' ')}
        <span style="color:var(--hint);font-size:10px">&nbsp;(rules using these are skipped)</span>` : ''}`;
    }

    _rulePage = 0;
    renderRules();
  } catch(e) {
    $('rules-list').innerHTML = `<div class="empty-state">Failed to load rules: ${e.message}</div>`;
  }
}

function toggleStoragePaths() {
  const box = $('storage-paths-box');
  if (box) box.style.display = box.style.display === 'none' ? '' : 'none';
}

// Returns custom rules that match the current search term (excludes forge packages)
function _filteredRules() {
  const custom = _rules.filter(r => !r.is_forge_package);
  if (!_ruleSearch) return custom;
  const q = _ruleSearch.toLowerCase();
  return custom.filter(r =>
    r.name.toLowerCase().includes(q) ||
    r.tag.toLowerCase().includes(q)  ||
    r.body.toLowerCase().includes(q)
  );
}

function renderRules() {
  const customRules = _rules.filter(r => !r.is_forge_package);
  const forgePkgs   = _rules.filter(r => r.is_forge_package);
  const filtered    = _filteredRules();   // filters custom rules only
  const totalPages  = Math.max(1, Math.ceil(filtered.length / _rulePageSize));
  if (_rulePage >= totalPages) _rulePage = totalPages - 1;
  const pageRules   = filtered.slice(_rulePage * _rulePageSize, (_rulePage + 1) * _rulePageSize);
  const selCount    = customRules.filter(r => r.selected).length;

  const rc = $('rule-count');
  if (rc) rc.textContent = customRules.length +
    (forgePkgs.length ? ` + ${forgePkgs.length} Forge pkg${forgePkgs.length>1?'s':''}` : '');

  const list = $('rules-list');

  // ── Forge package summary cards ──
  const forgeCardsHtml = forgePkgs.map(pkg => `
    <div style="background:rgba(29,158,117,0.06);border:1px solid var(--accent);border-radius:var(--radius);padding:9px 13px;display:flex;align-items:center;gap:10px;margin-bottom:4px">
      <div style="flex:1;min-width:0">
        <div style="font-size:12px;font-weight:500;color:var(--accent)">📦 ${escHtml(pkg.name)}</div>
        <div style="font-size:11px;color:var(--muted);margin-top:2px">Compiled as a complete package · all imports and private rules work correctly</div>
        ${pkg.path ? `<div style="font-size:10px;color:var(--hint);font-family:var(--font-mono);margin-top:2px">${escHtml(pkg.path)}</div>` : ''}
      </div>
      <div style="font-size:11px;color:var(--muted);text-align:right;flex-shrink:0">
        <div style="color:var(--accent)">Always included in scans</div>
        <div style="color:var(--hint);font-size:10px">Not individually selectable</div>
      </div>
    </div>`).join('');

  // ── Toolbar ──
  const toolbarHtml = `
    <div id="rules-toolbar" style="display:flex;flex-direction:column;gap:8px;flex-shrink:0">
      <div style="display:flex;gap:8px;align-items:center">
        <input type="text" id="rule-search-input" placeholder="Search custom rules…"
               value="${escHtml(_ruleSearch)}"
               oninput="onRuleSearch(this.value)"
               style="flex:1;font-size:12px;padding:6px 10px;border:1px solid var(--border2);border-radius:var(--radius);background:var(--card);color:var(--text);font-family:var(--font-sans)"/>
        ${_ruleSearch ? `<button class="btn" onclick="onRuleSearch('')" style="flex-shrink:0">✕ Clear</button>` : ''}
        <select onchange="onPageSizeChange(this.value)"
                style="font-size:12px;padding:5px 8px;border:1px solid var(--border2);border-radius:var(--radius);background:var(--card);color:var(--text);flex-shrink:0">
          ${[10,25,50,100,250].map(n =>
            `<option value="${n}" ${n===_rulePageSize?'selected':''}>${n} per page</option>`).join('')}
        </select>
      </div>
      <div style="display:flex;gap:8px;align-items:center;font-size:12px;color:var(--muted)">
        <button class="btn" style="font-size:11px" onclick="selectAllFiltered(true)">
          Select all${_ruleSearch?' matching':''} (${filtered.length.toLocaleString()})
        </button>
        <button class="btn" style="font-size:11px" onclick="selectPageRules(true)">Select page</button>
        <button class="btn" style="font-size:11px" onclick="selectAllFiltered(false)">Deselect all</button>
        <span style="margin-left:auto;color:var(--hint)">
          ${selCount > 0 ? `<strong style="color:var(--accent)">${selCount.toLocaleString()} selected</strong> &nbsp;·&nbsp;` : ''}
          ${_ruleSearch
            ? `${filtered.length.toLocaleString()} match${filtered.length!==1?'es':''} of ${customRules.length.toLocaleString()}`
            : `${customRules.length.toLocaleString()} custom rule${customRules.length!==1?'s':''}`}
        </span>
      </div>
    </div>`;

  if (!filtered.length && !forgePkgs.length) {
    list.innerHTML = toolbarHtml +
      `<div class="empty-state">${_ruleSearch ? `No rules match "${escHtml(_ruleSearch)}"` : 'No rules yet.'}</div>`;
    return;
  }

  const cardsHtml = pageRules.filter(r => !r.is_forge_package).map(r => `
    <div class="rule-card ${r.selected?'selected':''}">
      <input type="checkbox" class="rule-check" ${r.selected?'checked':''} onchange="toggleSelect(${r.id})"/>
      <div class="rule-info">
        <div class="rule-name">${escHtml(r.name)}</div>
        <div class="rule-meta">${r.body.split('\n').length} lines</div>
        <div class="rule-tags">
          <span class="tag">${escHtml(r.tag)}</span>
          <span class="tag sev-${r.sev}">${r.sev}</span>
        </div>
      </div>
      <div class="rule-actions">
        <button class="icon-btn" title="Edit" onclick="openEditRule(${r.id})">✎</button>
        <button class="icon-btn" title="Delete" style="color:var(--danger)" onclick="deleteRule(${r.id})">🗑</button>
      </div>
    </div>`).join('');

  const paginationHtml = totalPages > 1 ? `
    <div style="display:flex;align-items:center;justify-content:center;gap:6px;padding-top:4px;flex-shrink:0">
      <button class="btn" style="font-size:11px" ${_rulePage===0?'disabled':''} onclick="goToPage(0)">«</button>
      <button class="btn" style="font-size:11px" ${_rulePage===0?'disabled':''} onclick="goToPage(${_rulePage-1})">‹</button>
      <span style="font-size:12px;color:var(--muted);padding:0 8px">
        Page ${_rulePage+1} of ${totalPages} &nbsp;·&nbsp;
        ${_rulePage*_rulePageSize+1}–${Math.min((_rulePage+1)*_rulePageSize,filtered.length)} of ${filtered.length.toLocaleString()}
      </span>
      <button class="btn" style="font-size:11px" ${_rulePage>=totalPages-1?'disabled':''} onclick="goToPage(${_rulePage+1})">›</button>
      <button class="btn" style="font-size:11px" ${_rulePage>=totalPages-1?'disabled':''} onclick="goToPage(${totalPages-1})">»</button>
    </div>` : '';

  list.innerHTML = forgeCardsHtml + toolbarHtml + cardsHtml + paginationHtml;

  const inp = $('rule-search-input');
  if (inp && _ruleSearch) { inp.focus(); inp.setSelectionRange(inp.value.length, inp.value.length); }
}


function onRuleSearch(val) {
  _ruleSearch = val;
  _rulePage   = 0;
  renderRules();
  // Keep focus in the input
  const inp = $('rule-search-input');
  if (inp) { inp.focus(); inp.setSelectionRange(inp.value.length, inp.value.length); }
}

function onPageSizeChange(val) {
  _rulePageSize = parseInt(val);
  _rulePage     = 0;
  renderRules();
}

function goToPage(n) {
  _rulePage = n;
  renderRules();
  // Scroll rules list to top
  const list = $('rules-list');
  if (list) list.scrollTop = 0;
}

function selectAllFiltered(val) {
  const filtered = _filteredRules();
  const ids = new Set(filtered.map(r => r.id));
  if (val) {
    // Select all filtered rules
    _rules.forEach(r => { if (ids.has(r.id)) r.selected = true; });
  } else {
    // Deselect all rules regardless of filter
    _rules.forEach(r => r.selected = false);
  }
  renderRules();
}

function selectPageRules(val) {
  const filtered  = _filteredRules();
  const pageRules = filtered.slice(_rulePage * _rulePageSize, (_rulePage + 1) * _rulePageSize);
  const ids = new Set(pageRules.map(r => r.id));
  _rules.forEach(r => { if (ids.has(r.id)) r.selected = val; });
  renderRules();
}

function escHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function toggleSelect(id) {
  const r = _rules.find(x => x.id === id);
  if (r) r.selected = !r.selected;
  renderRules();
}

// Add / Edit modal
$('btn-add-rule').onclick = () => {
  _editingId = null;
  $('modal-title').textContent = 'Add YARA Rule';
  ['new-rule-name','new-rule-tag','new-rule-body'].forEach(id => $(id).value = '');
  $('new-rule-sev').value = 'med';
  openModal('modal-backdrop');
};

function openEditRule(id) {
  const r = _rules.find(x => x.id === id);
  if (!r) return;
  _editingId = id;
  $('modal-title').textContent = 'Edit Rule';
  $('new-rule-name').value = r.name;
  $('new-rule-tag').value  = r.tag;
  $('new-rule-sev').value  = r.sev;
  $('new-rule-body').value = r.body;
  openModal('modal-backdrop');
}

$('modal-close').onclick = $('modal-cancel').onclick = () => closeModal('modal-backdrop');
$('modal-backdrop').onclick = e => { if (e.target === $('modal-backdrop')) closeModal('modal-backdrop'); };

$('modal-save').onclick = async () => {
  const name = $('new-rule-name').value.trim();
  const body = $('new-rule-body').value.trim();
  if (!name || !body) { toast('Name and rule body are required.'); return; }
  const payload = { name, tag: $('new-rule-tag').value.trim()||'general', sev: $('new-rule-sev').value, body };
  try {
    if (_editingId) {
      await apiFetch(`/api/yara/rules/${_editingId}`, { method:'PUT', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload) });
    } else {
      await apiFetch('/api/yara/rules', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload) });
    }
    closeModal('modal-backdrop');
    await loadRules();
    toast(_editingId ? 'Rule updated.' : 'Rule added.');
  } catch(e) { toast('Error: ' + e.message); }
};

async function deleteRule(id) {
  if (!confirm('Delete this rule?')) return;
  try {
    await apiFetch(`/api/yara/rules/${id}`, { method: 'DELETE' });
    await loadRules();
    toast('Rule deleted.');
  } catch(e) { toast('Error: ' + e.message); }
}

// Import .yar
$('btn-import').onclick = () => $('import-yar-input').click();
$('import-yar-input').onchange = async e => {
  const files = e.target.files;
  if (!files.length) return;
  const fd = new FormData();
  Array.from(files).forEach(f => fd.append('files', f));
  try {
    const r = await apiFetch('/api/yara/import', { method:'POST', body:fd });
    const data = await r.json();
    await loadRules();
    toast(`Imported ${data.imported} rule(s).`);
    if (data.errors.length) console.warn('Import errors:', data.errors);
  } catch(e) { toast('Import failed: ' + e.message); }
  $('import-yar-input').value = '';
};

// Export all rules
$('btn-export-rules').onclick = () => { window.location.href = '/api/yara/export'; };

// Scan
let _scanSource = null;

$('btn-scan').onclick = () => {
  const path = $('scan-path').value.trim();
  if (!path) { $('scan-path').focus(); return; }
  const useSelected = $('opt-selected').checked;
  const ruleIds = useSelected ? _rules.filter(r => r.selected).map(r => r.id) : [];
  if (useSelected && !ruleIds.length) { toast('No rules selected.'); return; }

  const term = $('scan-terminal');
  term.innerHTML = '';
  term.classList.add('visible');
  $('btn-scan').disabled = true;
  $('btn-stop-scan').style.display = '';

  const body = {
    path,
    recursive: $('opt-recursive').checked,
    timeout:   $('opt-timeout').checked ? 30 : 0,
    rule_ids:  ruleIds.length ? ruleIds : null,
  };

  if (_scanSource) _scanSource.close();

  // Use SSE for streaming results
  fetch('/api/yara/scan', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(body),
  }).then(resp => {
    const reader = resp.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    function read() {
      reader.read().then(({ done, value }) => {
        if (done) {
          $('btn-scan').disabled = false;
          $('btn-stop-scan').style.display = 'none';
          return;
        }
        buffer += decoder.decode(value, { stream: true });
        const events = buffer.split('\n\n');
        buffer = events.pop();
        events.forEach(ev => {
          const line = ev.replace(/^data: /, '');
          if (!line) return;
          try {
            const { cls, text } = JSON.parse(line);
            appendTermLine(term, cls, text);
          } catch(e) {}
        });
        read();
      });
    }
    read();
    _scanSource = { close: () => reader.cancel() };
  }).catch(e => {
    appendTermLine(term, 'error', '[!] Scan failed: ' + e.message);
    $('btn-scan').disabled = false;
    $('btn-stop-scan').style.display = 'none';
  });
};

$('btn-stop-scan').onclick = () => {
  if (_scanSource) { _scanSource.close(); _scanSource = null; }
  appendTermLine($('scan-terminal'), 'warn', '[!] Scan stopped by user.');
  $('btn-scan').disabled = false;
  $('btn-stop-scan').style.display = 'none';
};

function appendTermLine(container, cls, text) {
  const p = document.createElement('p');
  p.className = 't-' + cls;
  p.textContent = text;
  container.appendChild(p);
  container.scrollTop = container.scrollHeight;
}

// ═══════════════════════════════════════════════════════════════════
// FILE HASHER MODULE
// ═══════════════════════════════════════════════════════════════════
let _fileData      = null;
let _hasherFile    = null;
let _yargenRule    = '';
let _quickRule     = '';
let _selStrings    = new Set();
let _quickMode     = 'hash';
let _sizeTolPct    = 0;
let _setupLogIndex = 0;
let _setupPoller   = null;

// ── Drop / file input ─────────────────────────────────────────────
$('hasher-file-input').onchange = e => handleHasherFile(e.target.files[0]);
const hdz = $('hasher-dropzone');
hdz.ondragover = e => { e.preventDefault(); hdz.classList.add('drag'); };
hdz.ondragleave = () => hdz.classList.remove('drag');
hdz.ondrop = e => { e.preventDefault(); hdz.classList.remove('drag'); handleHasherFile(e.dataTransfer.files[0]); };

async function handleHasherFile(file) {
  if (!file) return;
  _hasherFile = file;
  _selStrings = new Set();
  _quickMode  = 'hash';
  _sizeTolPct = 0;
  _yargenRule = '';
  _quickRule  = '';

  const fd = new FormData();
  fd.append('file', file);
  try {
    const r  = await apiFetch('/api/hasher/hash', { method: 'POST', body: fd });
    _fileData = await r.json();
  } catch(e) {
    toast('Hash error: ' + e.message);
    return;
  }

  // Pre-select top 10 strings by score
  const scored = [..._fileData.strings].sort((a,b) => scoreStr(b) - scoreStr(a));
  _selStrings  = new Set(scored.slice(0, 10));

  renderHashResults();
  // yarGen is NOT auto-run — user clicks "▶ Run yarGen" in the yarGen section
}

function scoreStr(s) {
  return s.length * 0.6 + new Set(s).size * 0.3 + (/[^a-zA-Z0-9 ]/.test(s) ? 10 : 0);
}

// ── Render full results panel ─────────────────────────────────────
function renderHashResults() {
  const d = _fileData;
  $('hasher-drop-view').style.display    = 'none';
  $('hasher-results-view').style.display = 'flex';
  $('btn-hasher-reset').style.display    = '';

  $('hasher-results-body').innerHTML = `

    <!-- ── File info ── -->
    <div class="h-section" id="hsec-info">
      <div class="h-section-hdr" onclick="toggleHSection('hsec-info')">
        <span>File info &amp; hashes</span>
        <span class="h-chevron" style="margin-left:auto">▾</span>
      </div>
      <div class="h-section-body">
        <div class="card-header" style="border-bottom:none">
          <span style="font-size:13px;font-weight:500">${escHtml(d.name)}</span>
          <span style="font-size:11px;color:var(--hint)">${formatSize(d.size)}</span>
        </div>
        <div class="hash-grid" style="padding:0 14px 12px">
          <div class="hash-row"><div class="hash-label">Type</div><div class="hash-value" style="color:var(--muted)">${escHtml(d.magic.label)}</div><div></div></div>
          <div class="hash-row"><div class="hash-label">Magic</div><div class="hash-value" style="font-size:10px">${escHtml(d.magic.hex.substring(0,48))}</div><div></div></div>
          ${['MD5','SHA1','SHA256','SHA512'].map(algo => {
            const key = algo.toLowerCase();
            const val = algo === 'SHA512' ? d[key].substring(0,40)+'…' : d[key];
            return `<div class="hash-row">
              <div class="hash-label">${algo}</div>
              <div class="hash-value">${escHtml(val)}</div>
              <button class="copy-btn" onclick="navigator.clipboard.writeText('${d[key]}').then(()=>toast('${algo} copied.'))">copy</button>
            </div>`;
          }).join('')}
        </div>
      </div>
    </div>

    <!-- ── Strings ── -->
    <div class="h-section" id="hsec-strings">
      <div class="h-section-hdr" onclick="toggleHSection('hsec-strings')">
        <span>Extracted strings <span style="font-weight:400;text-transform:none;letter-spacing:0;font-size:10px;color:var(--hint)">&nbsp;${d.strings.length} found · top 10 pre-selected</span></span>
        <div style="display:flex;gap:6px;align-items:center;margin-left:auto" onclick="event.stopPropagation()">
          <span style="font-size:10px;padding:2px 7px;background:var(--bg);border:1px solid var(--border);border-radius:10px;color:var(--hint)" id="str-sel-count">${_selStrings.size} selected</span>
          <button class="btn" style="font-size:11px" onclick="selectTopStr(15)">Top 15</button>
          <button class="btn" style="font-size:11px" onclick="selectTopStr(0)">None</button>
          <span class="h-chevron">▾</span>
        </div>
      </div>
      <div class="h-section-body">
        <div class="strings-body" id="strings-list" style="max-height:150px"></div>
        <div class="v-resize-handle" data-target="strings-list" title="Drag to resize"></div>
      </div>
    </div>

    <!-- ── Quick rule ── -->
    <div class="h-section" id="hsec-quick">
      <div class="h-section-hdr" onclick="toggleHSection('hsec-quick')">
        <span>Quick rule <span style="font-weight:400;text-transform:none;letter-spacing:0;font-size:10px;color:var(--hint)">&nbsp;instant · hand-picked strings</span></span>
        <span class="h-chevron" style="margin-left:auto">▾</span>
      </div>
      <div class="h-section-body" style="padding:10px 14px;display:flex;flex-direction:column;gap:8px">
        <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
          <button class="mode-tab active" id="qmode-hash"    onclick="setQuickMode('hash')">Hash match</button>
          <button class="mode-tab"        id="qmode-strings" onclick="setQuickMode('strings')">String match</button>
          <button class="mode-tab"        id="qmode-or"      onclick="setQuickMode('or')">Hash OR strings</button>
          <div style="margin-left:auto;display:flex;align-items:center;gap:8px">
            <span style="font-size:11px;color:var(--muted)">Size tolerance</span>
            <input type="range" id="size-tol" min="0" max="50" step="5" value="0"
                   style="width:80px;accent-color:var(--accent)" oninput="updateSizeTol(this.value)"/>
            <span style="font-family:var(--font-mono);font-size:11px;min-width:36px" id="tol-label">exact</span>
          </div>
        </div>
        <div class="card" style="overflow:visible">
          <div class="card-header">
            <span class="card-title">Quick rule — editable</span>
            <div style="display:flex;gap:6px">
              <button class="btn" onclick="navigator.clipboard.writeText($('quick-rule-preview').textContent).then(()=>toast('Rule copied.'))">Copy</button>
              <button class="btn primary" onclick="addQuickRuleToLib()">Add to YARA lib</button>
            </div>
          </div>
          <div class="yara-preview" id="quick-rule-preview" contenteditable="true" spellcheck="false" style="max-height:200px"></div>
          <div class="v-resize-handle" data-target="quick-rule-preview" title="Drag to resize"></div>
        </div>
      </div>
    </div>

    <!-- ── yarGen ── -->
    <div class="h-section" id="hsec-yargen">
      <div class="h-section-hdr" onclick="toggleHSection('hsec-yargen')">
        <span>yarGen rule <span style="font-weight:400;text-transform:none;letter-spacing:0;font-size:10px;color:var(--hint)">&nbsp;goodware-filtered · deeper analysis</span></span>
        <div style="display:flex;gap:6px;align-items:center;margin-left:auto" onclick="event.stopPropagation()">
          <button class="btn primary" style="font-size:11px" id="btn-run-yargen" onclick="startYargen()">▶ Run yarGen</button>
          <span class="h-chevron">▾</span>
        </div>
      </div>
      <div class="h-section-body" style="padding:10px 14px;display:flex;flex-direction:column;gap:8px">
        <div class="terminal" id="yargen-run-terminal" style="max-height:180px"></div>
        <div id="yargen-rule-section" style="display:none;flex-direction:column;gap:0">
          <div class="card" style="overflow:visible">
            <div class="card-header">
              <span class="card-title">yarGen rule — editable</span>
              <div style="display:flex;gap:6px">
                <button class="btn" onclick="navigator.clipboard.writeText($('yargen-rule-preview').textContent).then(()=>toast('Rule copied.'))">Copy</button>
                <button class="btn primary" onclick="addYargenRuleToLib()">Add to YARA lib</button>
              </div>
            </div>
            <div class="yara-preview" id="yargen-rule-preview" contenteditable="true" spellcheck="false" style="max-height:200px"></div>
            <div class="v-resize-handle" data-target="yargen-rule-preview" title="Drag to resize"></div>
          </div>
        </div>
      </div>
    </div>
  `;

  renderStringsList();
  fetchQuickRule();
}

function toggleHSection(id) {
  const sec = $(id);
  if (sec) sec.classList.toggle('collapsed');
}

// ── Strings panel ─────────────────────────────────────────────────
function renderStringsList() {
  const scored = [..._fileData.strings].sort((a,b) => scoreStr(b) - scoreStr(a));
  $('strings-list').innerHTML = scored.map((s,i) => `
    <div class="string-item" onclick="toggleStr(${i})">
      <input type="checkbox" class="string-check" ${_selStrings.has(s)?'checked':''} onchange="toggleStr(${i})" onclick="event.stopPropagation()"/>
      <span class="string-val">${escHtml(s)}</span>
      <span class="string-len">${s.length}c</span>
    </div>`).join('');
  updateSelCount();
}

function toggleStr(i) {
  const scored = [..._fileData.strings].sort((a,b) => scoreStr(b) - scoreStr(a));
  const s = scored[i];
  if (_selStrings.has(s)) _selStrings.delete(s); else _selStrings.add(s);
  updateSelCount();
  const checks = document.querySelectorAll('.string-check');
  if (checks[i]) checks[i].checked = _selStrings.has(s);
  fetchQuickRule();
}

function selectTopStr(n) {
  const scored = [..._fileData.strings].sort((a,b) => scoreStr(b) - scoreStr(a));
  _selStrings  = new Set(scored.slice(0, n));
  renderStringsList();
  fetchQuickRule();
}

function updateSelCount() {
  const el = $('str-sel-count');
  if (el) el.textContent = _selStrings.size + ' selected';
}

// ── Quick rule generation ─────────────────────────────────────────
function setQuickMode(mode) {
  _quickMode = mode;
  ['hash','strings','or'].forEach(m => {
    const el = $('qmode-' + m);
    if (el) el.classList.toggle('active', m === mode);
  });
  fetchQuickRule();
}

function updateSizeTol(val) {
  _sizeTolPct = parseInt(val);
  const el = $('tol-label');
  if (el) el.textContent = _sizeTolPct === 0 ? 'exact' : '±' + _sizeTolPct + '%';
  fetchQuickRule();
}

async function fetchQuickRule() {
  if (!_fileData) return;
  const payload = {
    name:          _fileData.name,
    sha256:        _fileData.sha256,
    md5:           _fileData.md5,
    size:          _fileData.size,
    magic_label:   _fileData.magic.label,
    mode:          _quickMode,
    tolerance_pct: _sizeTolPct,
    strings:       [..._selStrings],
  };
  try {
    const r    = await apiFetch('/api/hasher/quick-rule', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(payload),
    });
    const data = await r.json();
    _quickRule = data.rule;
    const el = $('quick-rule-preview');
    if (el) el.textContent = data.rule;
  } catch(e) { console.warn('Quick rule error:', e); }
}

async function addQuickRuleToLib() {
  const preview  = $('quick-rule-preview');
  const ruleText = preview ? preview.textContent : _quickRule;
  if (!ruleText) { toast('No rule to add.'); return; }
  const match = ruleText.match(/rule\s+(\w+)/);
  const name  = match ? match[1] : (_fileData?.name?.replace(/[^a-zA-Z0-9_]/g,'_') || 'quick_rule');
  try {
    await apiFetch('/api/yara/rules', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ name, tag: 'quick-rule', sev: 'med', body: ruleText }),
    });
    await loadRules();
    toast('Quick rule added to YARA library.');
    document.querySelector('[data-mod="yara"]').click();
  } catch(e) { toast('Error: ' + e.message); }
}

// ── yarGen orchestration ──────────────────────────────────────────
async function startYargen() {
  try {
    const r    = await apiFetch('/api/hasher/setup-status');
    const data = await r.json();
    updateSetupIndicator(data.state);

    if (data.state === 'running') {
      $('hasher-setup-status-box').style.display = '';
      _setupLogIndex = 0;
      appendSetupLines(data.log);
      _setupLogIndex = data.log_total;
      pollSetupUntilReady();
    } else if (data.state === 'ready') {
      runYargen();
    } else if (data.state === 'failed') {
      const term = $('yargen-run-terminal');
      if (term) appendTermLine(term, 'error', '[!] yarGen setup failed. Check server logs and restart the app.');
    } else {
      setTimeout(startYargen, 1500);
    }
  } catch(e) { console.warn('Setup status check failed:', e); }
}

function pollSetupUntilReady() {
  if (_setupPoller) clearInterval(_setupPoller);
  _setupPoller = setInterval(async () => {
    try {
      const r    = await apiFetch(`/api/hasher/setup-status?since=${_setupLogIndex}`);
      const data = await r.json();
      appendSetupLines(data.log);
      _setupLogIndex = data.log_total;
      updateSetupIndicator(data.state);
      if (data.state === 'ready') {
        clearInterval(_setupPoller);
        $('hasher-setup-status-box').style.display = 'none';
        runYargen();
      } else if (data.state === 'failed') {
        clearInterval(_setupPoller);
        const term = $('yargen-run-terminal');
        if (term) appendTermLine(term, 'error', '[!] yarGen setup failed. Check server logs and restart the app.');
      }
    } catch(e) {}
  }, 1500);
}

function appendSetupLines(lines) {
  const term = $('setup-terminal');
  if (!term) return;
  lines.forEach(({cls, text}) => appendTermLine(term, cls, text));
}

function updateSetupIndicator(state) {
  const spinner = $('yargen-spinner');
  const label   = $('yargen-setup-label');
  if (!label) return;
  if (state === 'running') {
    if (spinner) spinner.style.display = '';
    label.textContent = 'Setting up yarGen...';
    label.style.color = 'var(--muted)';
  } else if (state === 'ready') {
    if (spinner) spinner.style.display = 'none';
    label.textContent = 'yarGen ready';
    label.style.color = 'var(--accent)';
  } else if (state === 'failed') {
    if (spinner) spinner.style.display = 'none';
    label.textContent = 'yarGen setup failed';
    label.style.color = 'var(--danger)';
  } else {
    if (spinner) spinner.style.display = '';
    label.textContent = 'Checking yarGen...';
  }
}

async function runYargen() {
  if (!_hasherFile) return;
  const term = $('yargen-run-terminal');
  if (!term) return;

  // Show terminal, disable run button while running
  term.innerHTML = '';
  term.classList.add('visible');
  const runBtn = $('btn-run-yargen');
  if (runBtn) { runBtn.disabled = true; runBtn.textContent = 'Running…'; }

  const fd = new FormData();
  fd.append('file', _hasherFile);

  try {
    const resp = await fetch('/api/hasher/yargen/run', { method: 'POST', body: fd });
    if (!resp.ok) {
      const err = await resp.json().catch(() => ({error: resp.statusText}));
      appendTermLine(term, 'error', '[!] ' + (err.error || resp.statusText));
      if (runBtn) { runBtn.disabled = false; runBtn.textContent = '▶ Run yarGen'; }
      return;
    }

    const reader  = resp.body.getReader();
    const decoder = new TextDecoder();
    let buf = '';

    async function read() {
      const { done, value } = await reader.read();
      if (done) {
        if (runBtn) { runBtn.disabled = false; runBtn.textContent = '↺ Re-run yarGen'; }
        return;
      }
      buf += decoder.decode(value, { stream: true });
      const events = buf.split('\n\n');
      buf = events.pop();
      events.forEach(ev => {
        const line = ev.replace(/^data: /, '');
        if (!line) return;
        try {
          const { cls, text } = JSON.parse(line);
          if (cls === 'rule') {
            _yargenRule = text;
            const section = $('yargen-rule-section');
            const preview = $('yargen-rule-preview');
            if (section) section.style.display = 'flex';
            if (preview) preview.textContent = text;
          } else {
            appendTermLine(term, cls, text);
          }
        } catch(e) {}
      });
      read();
    }
    read();
  } catch(e) {
    appendTermLine(term, 'error', '[!] Request failed: ' + e.message);
    if (runBtn) { runBtn.disabled = false; runBtn.textContent = '▶ Run yarGen'; }
  }
}

async function addYargenRuleToLib() {
  const preview  = $('yargen-rule-preview');
  const ruleText = preview ? preview.textContent : _yargenRule;
  if (!ruleText) { toast('No yarGen rule ready yet.'); return; }
  const match = ruleText.match(/rule\s+(\w+)/);
  const name  = match ? match[1] : (_fileData?.name?.replace(/[^a-zA-Z0-9_]/g,'_') || 'yargen_rule');
  try {
    await apiFetch('/api/yara/rules', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ name, tag: 'yargen', sev: 'med', body: ruleText }),
    });
    await loadRules();
    toast('yarGen rule added to YARA library.');
    document.querySelector('[data-mod="yara"]').click();
  } catch(e) { toast('Error: ' + e.message); }
}

$('btn-hasher-reset').onclick = () => {
  _fileData = null; _hasherFile = null; _yargenRule = ''; _quickRule = '';
  _selStrings = new Set(); _quickMode = 'hash'; _sizeTolPct = 0;
  if (_setupPoller) { clearInterval(_setupPoller); _setupPoller = null; }
  $('hasher-results-view').style.display     = 'none';
  $('hasher-drop-view').style.display        = 'flex';
  $('hasher-setup-status-box').style.display = 'none';
  $('btn-hasher-reset').style.display        = 'none';
  const label = $('yargen-setup-label');
  if (label) label.textContent = '';
  const spinner = $('yargen-spinner');
  if (spinner) spinner.style.display = 'none';
  $('hasher-file-input').value = '';
};

// Poll setup status on page load so the header indicator is always accurate
(async () => {
  try {
    const r    = await apiFetch('/api/hasher/setup-status');
    const data = await r.json();
    updateSetupIndicator(data.state);
    if (data.state === 'running') {
      _setupPoller = setInterval(async () => {
        try {
          const r2 = await apiFetch('/api/hasher/setup-status');
          const d2 = await r2.json();
          updateSetupIndicator(d2.state);
          if (d2.state !== 'running') { clearInterval(_setupPoller); _setupPoller = null; }
        } catch(e) {}
      }, 2000);
    }
  } catch(e) {}
})();


// ═══════════════════════════════════════════════════════════════════
// ARTIFACT PARSER MODULE
// ═══════════════════════════════════════════════════════════════════
let _artifactTools   = [];
let _toolStates      = {};
let _artifactRunning = false;
let _artifactReader  = null;

async function loadArtifactTools() {
  try {
    const r = await apiFetch('/api/artifact/tools');
    _artifactTools = await r.json();
    _artifactTools.forEach(t => { _toolStates[t.id] = t.default_on; });
    renderArtifactTools();
    // Attach browse buttons after tools render
    setTimeout(() => {
      addBrowseButton('inp-collection', 'folder', 'Select collection folder');
      addBrowseButton('inp-output',     'folder', 'Select output folder');
      addBrowseButton('inp-tools',      'folder', 'Select Zimmerman tools folder');
    }, 100);
  } catch(e) { console.error('Failed to load artifact tools:', e); }
}

function renderArtifactTools() {
  const enabled = _artifactTools.filter(t => _toolStates[t.id]).length;
  $('tool-count-label').textContent = `${enabled} of ${_artifactTools.length} enabled`;
  $('tool-grid').innerHTML = _artifactTools.map(t => `
    <div class="tool-card ${_toolStates[t.id]?'enabled':''} ${t._missing?'missing':''}"
         onclick="toggleArtifactTool('${t.id}')">
      <div class="tool-card-header">
        <input type="checkbox" class="tool-toggle" ${_toolStates[t.id]?'checked':''}
               onclick="event.stopPropagation();toggleArtifactTool('${t.id}')"/>
        <span class="tool-name">${t.name}</span>
        ${t._missing ? '<span style="font-size:9px;color:var(--danger);margin-left:auto">missing</span>' : ''}
        ${t._found  ? '<span style="font-size:9px;color:var(--accent);margin-left:auto">✓</span>'      : ''}
      </div>
      <div class="tool-desc">${t.desc}</div>
      <div class="tool-artifacts">${t.artifacts}</div>
    </div>`).join('');
}

function toggleArtifactTool(id) {
  _toolStates[id] = !_toolStates[id];
  renderArtifactTools();
}

function selectAllArtifactTools(val) {
  _artifactTools.forEach(t => _toolStates[t.id] = val);
  renderArtifactTools();
}

// ── Check tools ────────────────────────────────────────────────────────────
$('btn-check-tools').onclick = async () => {
  const toolsDir = $('inp-tools').value.trim();
  if (!toolsDir) { toast('Enter a tools directory first.'); return; }
  try {
    const r       = await apiFetch('/api/artifact/check-tools', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ tools_dir: toolsDir }),
    });
    const data    = await r.json();
    let found = 0, missing = 0;
    _artifactTools.forEach(t => {
      const res = data.results[t.id];
      t._found   = res?.found  || false;
      t._missing = !res?.found || false;
      if (t._found) found++; else missing++;
    });
    renderArtifactTools();
    if (missing > 0) {
      $('btn-download-tools').style.display = '';
      toast(`${found} tools found, ${missing} missing — click "Get missing tools" to download`);
    } else {
      $('btn-download-tools').style.display = 'none';
      toast(`All ${found} tools found ✓`);
    }
  } catch(e) { toast('Check failed: ' + e.message); }
};

// ── Download tools ─────────────────────────────────────────────────────────
$('btn-download-tools').onclick = () => {
  const toolsDir = $('inp-tools').value.trim();
  if (!toolsDir) { toast('Enter a tools directory first.'); return; }
  const term = $('artifact-terminal');
  term.innerHTML = '';
  term.classList.add('visible');
  $('artifact-terminal-section').style.display = '';

  fetch('/api/artifact/download-tools', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ tools_dir: toolsDir }),
  }).then(resp => {
    const reader  = resp.body.getReader();
    const decoder = new TextDecoder();
    let buf = '';
    function read() {
      reader.read().then(({ done, value }) => {
        if (done) {
          // Re-check tools after download
          $('btn-check-tools').click();
          return;
        }
        buf += decoder.decode(value, { stream: true });
        const events = buf.split('\n\n'); buf = events.pop();
        events.forEach(ev => {
          const line = ev.replace(/^data: /, '');
          if (!line) return;
          try {
            const { cls, text } = JSON.parse(line);
            if (cls !== 'complete') appendTermLine(term, cls, text);
          } catch(e) {}
        });
        read();
      });
    }
    read();
  }).catch(e => appendTermLine(term, 'error', '[!] ' + e.message));
};

// ── Run tools ──────────────────────────────────────────────────────────────
$('btn-run-tools').onclick = () => {
  if (_artifactRunning) return;
  const toolsDir  = $('inp-tools').value.trim();
  const colPath   = $('inp-collection').value.trim();
  const outPath   = $('inp-output').value.trim();
  if (!toolsDir)  { toast('Enter Zimmerman tools directory.'); return; }
  if (!colPath)   { toast('Enter collection input path.');     return; }
  if (!outPath)   { toast('Enter CSV output path.');           return; }

  const enabled = _artifactTools.filter(t => _toolStates[t.id]).map(t => t.id);
  if (!enabled.length) { toast('Enable at least one tool.'); return; }

  _artifactRunning = true;
  const term = $('artifact-terminal');
  term.innerHTML = '';
  term.classList.add('visible');
  $('artifact-terminal-section').style.display = '';
  $('btn-run-tools').disabled    = true;
  $('btn-run-tools').textContent = 'Running…';
  $('btn-stop-tools').style.display = '';

  fetch('/api/artifact/run', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({
      tools_dir:       toolsDir,
      collection_path: colPath,
      output_path:     outPath,
      enabled_tools:   enabled,
    }),
  }).then(resp => {
    const reader  = resp.body.getReader();
    const decoder = new TextDecoder();
    let buf = '';
    _artifactReader = reader;
    function read() {
      reader.read().then(({ done, value }) => {
        if (done) {
          _artifactRunning = false;
          $('btn-run-tools').disabled    = false;
          $('btn-run-tools').textContent = 'Run tools';
          $('btn-stop-tools').style.display = 'none';
          return;
        }
        buf += decoder.decode(value, { stream: true });
        const events = buf.split('\n\n'); buf = events.pop();
        events.forEach(ev => {
          const line = ev.replace(/^data: /, '');
          if (!line) return;
          try {
            const msg = JSON.parse(line);
            if (msg.cls === 'complete') {
              toast(`✓ Done — ${msg.csv_count} CSV file(s) written to output folder`);
            } else {
              appendTermLine(term, msg.cls, msg.text);
            }
          } catch(e) {}
        });
        read();
      });
    }
    read();
  }).catch(e => {
    appendTermLine(term, 'error', '[!] ' + e.message);
    _artifactRunning = false;
    $('btn-run-tools').disabled    = false;
    $('btn-run-tools').textContent = 'Run tools';
    $('btn-stop-tools').style.display = 'none';
  });
};

$('btn-stop-tools').onclick = () => {
  if (_artifactReader) { _artifactReader.cancel(); _artifactReader = null; }
  appendTermLine($('artifact-terminal'), 'warn', '[!] Stopped by user.');
  _artifactRunning = false;
  $('btn-run-tools').disabled    = false;
  $('btn-run-tools').textContent = 'Run tools';
  $('btn-stop-tools').style.display = 'none';
};


// YARA FORGE UPDATE SYSTEM
// ═══════════════════════════════════════════════════════════════════
let _forgeReleaseData = null;

const FORGE_PKG_INFO = {
  core:     { label: "Core",     desc: "~5k rules · high accuracy · low false positives · best for IR work" },
  extended: { label: "Extended", desc: "~10k rules · broader coverage · some additional false positive risk" },
  full:     { label: "Full",     desc: "~12k rules · everything available · use with caution" },
};

async function checkForgeUpdates() {
  const btn  = $('btn-forge-check');
  const area = $('forge-status-area');
  const term = $('forge-terminal');

  btn.disabled    = true;
  btn.textContent = 'Checking...';
  area.style.display = 'none';
  term.style.display = 'none';

  try {
    const r    = await apiFetch('/api/yara/forge/status');
    const data = await r.json();

    if (data.error) {
      toast('YARA Forge: ' + data.error);
      btn.disabled = false;
      btn.textContent = 'Check for updates';
      return;
    }

    _forgeReleaseData = data;

    // Warn if any package has no download URL — show what assets ARE available
    const missing = Object.entries(data.packages).filter(([,p]) => !p.download_url);
    if (missing.length && data.all_assets) {
      console.warn('YARA Forge: no URL for', missing.map(([k])=>k), '| Available assets:', data.all_assets);
      term.innerHTML = '';
      appendTermLine(term, 'warn', `[~] Available assets in this release:`);
      data.all_assets.forEach(a => appendTermLine(term, 'info', `    ${a}`));
      term.style.display = 'block';
    }

    renderForgeStatus(data);
    area.style.display = 'flex';
    area.style.flexDirection = 'column';
  } catch(e) {
    toast('Could not reach GitHub: ' + e.message);
  } finally {
    btn.disabled    = false;
    btn.textContent = 'Refresh';
  }
}

function renderForgeStatus(data) {
  const area = $('forge-status-area');

  // Release header
  const relDate = data.latest_date || '';
  const counts  = data.release_notes || {};

  area.innerHTML = `
    <div style="padding:8px 14px;background:var(--bg);border-bottom:1px solid var(--border);font-size:11px;color:var(--muted);display:flex;align-items:center;justify-content:space-between">
      <span>Latest release: <strong style="color:var(--text)">${data.latest_tag}</strong> &nbsp;·&nbsp; ${relDate}</span>
      <a href="${escHtml(data.release_url)}" target="_blank" rel="noopener" style="color:var(--accent);font-size:11px;text-decoration:none">View on GitHub ↗</a>
    </div>
    ${Object.entries(data.packages).map(([pkg, info]) => renderForgePkgCard(pkg, info, counts[pkg])).join('')}
  `;
}

function renderForgePkgCard(pkg, info, releaseCount) {
  const pkgInfo    = FORGE_PKG_INFO[pkg] || {};
  const installed  = info.installed;
  const latest     = info.available;
  const needsUpdate = info.update_ready;
  const ruleCount  = info.rule_count;

  let badge = '';
  let actionBtn = '';

  if (!installed) {
    badge     = `<span class="forge-badge not-installed">Not installed</span>`;
    actionBtn = `<button class="btn primary" style="font-size:11px;padding:4px 11px" onclick="installForge('${pkg}')">Install</button>`;
  } else if (needsUpdate) {
    badge     = `<span class="forge-badge update">Update available</span>`;
    actionBtn = `<button class="btn primary" style="font-size:11px;padding:4px 11px" onclick="installForge('${pkg}')">Update</button>`;
  } else {
    badge     = `<span class="forge-badge up-to-date">✓ Up to date</span>`;
    actionBtn = `<button class="btn" style="font-size:11px;padding:4px 11px" onclick="installForge('${pkg}')">Re-install</button>`;
  }

  const installedLine = installed
    ? `Installed: ${installed}${ruleCount ? ` &nbsp;·&nbsp; ${ruleCount.toLocaleString()} rules` : ''}`
    : 'Not installed';

  const savedPath = info.saved_path
    ? `<div style="font-size:10px;color:var(--hint);margin-top:2px;font-family:var(--font-mono)">${escHtml(info.saved_path)}</div>`
    : '';

  const releaseLine = releaseCount
    ? `${releaseCount.toLocaleString()} rules in latest release`
    : `Latest: ${latest}`;

  return `
    <div class="forge-pkg-card">
      <div>
        <div class="forge-pkg-name">${pkgInfo.label || pkg}</div>
        ${badge}
      </div>
      <div class="forge-pkg-desc">${pkgInfo.desc || ''}</div>
      <div class="forge-pkg-meta">
        <div style="margin-bottom:4px">${releaseLine}</div>
        <div style="color:var(--hint);font-size:10px">${installedLine}</div>
        ${savedPath}
      </div>
      ${actionBtn}
    </div>`;
}

async function installForge(pkg) {
  if (!_forgeReleaseData) {
    toast('Check for updates first.');
    return;
  }
  const pkgData     = _forgeReleaseData.packages[pkg];
  const downloadUrl = pkgData?.download_url;
  if (!downloadUrl) {
    const available = _forgeReleaseData.all_assets || [];
    const msg = available.length
      ? `No ${pkg} asset found. Available assets:\n${available.join('\n')}`
      : `No download URL found for ${pkg}. Check the terminal for available assets.`;
    const term = $('forge-terminal');
    if (term) {
      term.innerHTML = '';
      term.style.display = 'block';
      appendTermLine(term, 'error', `[!] Could not find a ${pkg} package asset in this release.`);
      appendTermLine(term, 'info',  `[*] Assets in this release:`);
      available.forEach(a => appendTermLine(term, 'info', `    ${a}`));
      appendTermLine(term, 'info',  `[*] Please file an issue or check back after the next weekly release.`);
    }
    toast(msg.split('\n')[0]);
    return;
  }

  const term = $('forge-terminal');
  term.innerHTML  = '';
  term.style.display = 'block';

  // Disable all install buttons during download
  document.querySelectorAll('.forge-pkg-card button').forEach(b => b.disabled = true);

  try {
    const resp = await fetch('/api/yara/forge/update', {
      method:  'POST',
      headers: {'Content-Type': 'application/json'},
      body:    JSON.stringify({ package: pkg, download_url: downloadUrl }),
    });

    if (!resp.ok) {
      const err = await resp.json().catch(() => ({error: resp.statusText}));
      appendTermLine(term, 'error', '[!] ' + (err.error || resp.statusText));
      return;
    }

    const reader  = resp.body.getReader();
    const decoder = new TextDecoder();
    let buf = '';

    async function read() {
      const { done, value } = await reader.read();
      if (done) {
        document.querySelectorAll('.forge-pkg-card button').forEach(b => b.disabled = false);
        return;
      }
      buf += decoder.decode(value, { stream: true });
      const events = buf.split('\n\n');
      buf = events.pop();
      events.forEach(ev => {
        const line = ev.replace(/^data: /, '');
        if (!line) return;
        try {
          const msg = JSON.parse(line);
          if (msg.cls === 'complete') {
            // Reload rules and refresh the forge status
            loadRules();
            checkForgeUpdates();
          } else {
            appendTermLine(term, msg.cls, msg.text);
          }
        } catch(e) {}
      });
      read();
    }
    read();
  } catch(e) {
    appendTermLine(term, 'error', '[!] Request failed: ' + e.message);
    document.querySelectorAll('.forge-pkg-card button').forEach(b => b.disabled = false);
  }
}

// ═══════════════════════════════════════════════════════════════════
// SIGMA MODULE
// ═══════════════════════════════════════════════════════════════════
let _sigmaCsvResults  = [];   // current CSV search results for export
let _hayabusaResults  = [];   // loaded hayabusa results rows
let _hayabusaCols     = [];
let _hayabusaFilter   = '';
let _searchReader     = null;
let _savedSearches    = [];

function _streamToTerminal(url, payload, terminalId, onComplete) {
  const term = $(terminalId);
  if (!term) return null;
  term.innerHTML = '';
  term.style.display = 'block';

  const ctrl = { cancelled: false };

  fetch(url, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(payload),
  }).then(resp => {
    if (!resp.ok) {
      resp.json().catch(()=>({error: resp.statusText})).then(err => {
        appendTermLine(term, 'error', '[!] ' + (err.error || resp.statusText));
      });
      return;
    }
    const reader  = resp.body.getReader();
    const decoder = new TextDecoder();
    let buf = '';
    function read() {
      reader.read().then(({ done, value }) => {
        if (done || ctrl.cancelled) {
          if (onComplete) onComplete(null);
          return;
        }
        buf += decoder.decode(value, { stream: true });
        const events = buf.split('\n\n'); buf = events.pop();
        events.forEach(ev => {
          const line = ev.replace(/^data: /, '');
          if (!line) return;
          try {
            const msg = JSON.parse(line);
            if (msg.cls === 'complete') {
              if (onComplete) onComplete(msg);
            } else {
              appendTermLine(term, msg.cls, msg.text);
            }
          } catch(e) {}
        });
        read();
      }).catch(e => {
        if (!ctrl.cancelled) appendTermLine(term, 'error', '[!] Stream error: ' + e.message);
      });
    }
    read();
  }).catch(e => appendTermLine(term, 'error', '[!] ' + e.message));

  ctrl.reader = { cancel: () => { ctrl.cancelled = true; } };
  return ctrl;
}


const _hSearchEl = $('hayabusa-results-search');
if (_hSearchEl) _hSearchEl.oninput = e => {
  _hayabusaFilter = e.target.value.toLowerCase();
  renderHayabusaResults();
};

// Priority columns to show first in Hayabusa results
const HAYABUSA_PRIORITY = ['Timestamp','Level','Channel','EventID','Computer','RuleTitle','Details','ExtraFieldInfo'];

function renderHayabusaResults() {
  let rows = _hayabusaResults;
  if (_hayabusaFilter) {
    rows = rows.filter(r => Object.values(r).some(v => String(v||'').toLowerCase().includes(_hayabusaFilter)));
  }

  const cols = [
    ...HAYABUSA_PRIORITY.filter(c => _hayabusaCols.includes(c)),
    ..._hayabusaCols.filter(c => !HAYABUSA_PRIORITY.includes(c)),
  ];

  $('hayabusa-results-count').textContent = rows.length.toLocaleString() + ' rows';
  $('hayabusa-results-thead').innerHTML = '<tr>' +
    cols.map(c => `<th style="min-width:100px">${escHtml(c)}</th>`).join('') + '</tr>';
  $('hayabusa-results-tbody').innerHTML = rows.slice(0, 500).map(r =>
    '<tr>' + cols.map(c => {
      const v = escHtml(String(r[c]||''));
      // Color-code by level
      const style = c === 'Level' ? _levelStyle(r[c]) : '';
      return `<td title="${v}" style="${style}">${v}</td>`;
    }).join('') + '</tr>'
  ).join('') + (rows.length > 500
    ? `<tr><td colspan="${cols.length}" style="text-align:center;color:var(--hint);padding:10px;font-size:11px">Showing 500 of ${rows.length.toLocaleString()} — use filter to narrow</td></tr>`
    : '');
}

function _levelStyle(level) {
  const l = (level||'').toLowerCase();
  if (l === 'critical') return 'color:#e24b4a;font-weight:600';
  if (l === 'high')     return 'color:#e24b4a';
  if (l === 'medium')   return 'color:#ba7517';
  return '';
}

// ── Hayabusa (inside Artifact Parser) ─────────────────────────────
async function checkHayabusaStatus() {
  try {
    const r    = await apiFetch('/api/sigma/hayabusa/status');
    const data = await r.json();
    const el   = $('hayabusa-status-text');
    if (!el) return;
    if (data.installed && data.has_rules) {
      el.textContent = `✓ Ready — v${data.version || '?'} · rules present`;
      el.style.color = 'var(--accent)';
    } else if (data.installed) {
      el.textContent = 'Installed — click "Update rules" to download Sigma rules';
      el.style.color = 'var(--warn)';
    } else {
      el.textContent = 'Not installed — click "Download"';
      el.style.color = 'var(--hint)';
    }
  } catch(e) { console.warn('Hayabusa status check:', e); }
}

$('btn-hayabusa-download').onclick = () => {
  const term = $('hayabusa-setup-terminal');
  term.innerHTML = ''; term.style.display = 'block';
  _streamToTerminal('/api/sigma/hayabusa/download', {}, 'hayabusa-setup-terminal', msg => {
    if (msg) { toast('Hayabusa downloaded ✓'); checkHayabusaStatus(); }
  });
};

$('btn-hayabusa-update-rules').onclick = () => {
  const term = $('hayabusa-setup-terminal');
  term.innerHTML = ''; term.style.display = 'block';
  _streamToTerminal('/api/sigma/hayabusa/update-rules', {}, 'hayabusa-setup-terminal', msg => {
    if (msg) { toast(`Rules updated — ${msg.rule_count?.toLocaleString()} rules`); checkHayabusaStatus(); }
  });
};

$('btn-hayabusa-run').onclick = () => {
  // Toggle options panel
  const opts = $('hayabusa-run-options');
  if (opts.style.display === 'none') {
    opts.style.display = 'flex';
    // Auto-fill from artifact parser paths if empty
    if (!$('hayabusa-evtx-path').value) $('hayabusa-evtx-path').value = $('inp-collection').value;
    if (!$('hayabusa-output-path').value) {
      const outBase = $('inp-output').value;
      if (outBase) $('hayabusa-output-path').value = outBase.replace(/\\/g,'/') + '/hayabusa_results.csv';
    }
    // Change button to actually run
    $('btn-hayabusa-run').textContent = '▶ Run scan';
    $('btn-hayabusa-run').onclick = startHayabusaScan;
  } else {
    startHayabusaScan();
  }
};

function startHayabusaScan() {
  const evtxPath  = $('hayabusa-evtx-path').value.trim()  || $('inp-collection').value.trim();
  const outPath   = $('hayabusa-output-path').value.trim();
  const minLevel  = $('hayabusa-min-level').value;

  if (!evtxPath) { toast('Enter EVTX path or set a collection path above.'); return; }

  const term = $('hayabusa-setup-terminal');
  term.innerHTML = ''; term.style.display = 'block';
  $('btn-hayabusa-run').disabled    = true;
  $('btn-hayabusa-stop').style.display = '';
  $('btn-hayabusa-load-results').style.display = 'none';

  const ctrl = _streamToTerminal(
    '/api/sigma/hayabusa/run',
    { evtx_path: evtxPath, output_path: outPath, min_level: minLevel, profile: 'standard' },
    'hayabusa-setup-terminal',
    msg => {
      $('btn-hayabusa-run').disabled    = false;
      $('btn-hayabusa-run').textContent = '▶ Run scan';
      $('btn-hayabusa-stop').style.display = 'none';
      if (msg?.output_path) {
        $('btn-hayabusa-load-results').style.display = '';
        $('btn-hayabusa-load-results').dataset.path  = msg.output_path;
        toast(`Hayabusa: ${msg.hit_count?.toLocaleString()} events detected`);
      }
    }
  );
  $('btn-hayabusa-stop').onclick = () => {
    if (ctrl?.reader) ctrl.reader.cancel();
    appendTermLine(term, 'warn', '[!] Stopped by user.');
    $('btn-hayabusa-run').disabled    = false;
    $('btn-hayabusa-run').textContent = '▶ Run scan';
    $('btn-hayabusa-stop').style.display = 'none';
  };
}

$('btn-hayabusa-load-results').onclick = async () => {
  const path = $('btn-hayabusa-load-results').dataset.path;
  if (!path) return;
  try {
    const r    = await apiFetch('/api/sigma/hayabusa/load-results', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ path }),
    });
    const data = await r.json();
    _hayabusaResults = data.rows || [];
    _hayabusaCols    = data.columns || [];
    _hayabusaFilter  = '';
    $('hayabusa-results-search').value = '';
    $('hayabusa-results-wrap').style.display = 'flex';
    $('hayabusa-results-label').textContent =
      `Results — ${data.total?.toLocaleString()} rows${data.total > data.showing ? ` (first ${data.showing?.toLocaleString()})` : ''}`;
    renderHayabusaResults();
  } catch(e) { toast('Could not load results: ' + e.message); }
};



$('btn-run-search').onclick = () => {
  const directory = $('search-directory').value.trim();
  const termsRaw  = $('search-terms').value;
  const terms     = termsRaw.split('\n').map(t => t.trim()).filter(Boolean);
  const mode      = document.querySelector('input[name="search-mode"]:checked')?.value || 'any';
  const useRegex  = $('search-regex').checked;

  if (!directory) { toast('Enter a directory to search.'); return; }
  if (!terms.length) { toast('Enter at least one search term.'); return; }

  // Generate a unique search ID for cancellation
  _currentSearchId = `search-${Date.now()}`;
  _sigmaCsvResults = [];

  // Reset UI
  $('btn-run-search').disabled    = true;
  $('btn-run-search').textContent = 'Searching…';
  $('btn-stop-search').style.display = '';
  $('search-results-wrap').style.display = 'none';
  $('search-progress-wrap').style.display = '';
  $('search-progress-bar').style.width = '0%';
  $('search-progress-label').textContent = 'Starting…';

  fetch('/api/sigma/csv-search/run', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
      directory, terms, mode, use_regex: useRegex,
      max_results: 5000, search_id: _currentSearchId,
    }),
  }).then(resp => {
    if (!resp.ok) {
      resp.json().catch(()=>({error: resp.statusText})).then(err => {
        toast('Search error: ' + (err.error || resp.statusText));
        resetSearchUI();
      });
      return;
    }

    const reader  = resp.body.getReader();
    const decoder = new TextDecoder();
    let buf = '';

    function read() {
      reader.read().then(({ done, value }) => {
        if (done) { resetSearchUI(); return; }
        buf += decoder.decode(value, { stream: true });
        const events = buf.split('\n\n'); buf = events.pop();
        events.forEach(ev => {
          const line = ev.replace(/^data: /, '');
          if (!line) return;
          try {
            const msg = JSON.parse(line);
            if (msg.cls === 'complete') {
              // Final results payload
              _sigmaCsvResults = msg.results || [];
              renderSearchResults(msg);
              resetSearchUI();
              $('search-progress-wrap').style.display = 'none';
            } else if (msg.cls === 'progress') {
              // Update progress bar
              const pct = msg.total ? Math.round((msg.current / msg.total) * 100) : 0;
              $('search-progress-bar').style.width = pct + '%';
              $('search-progress-label').textContent =
                `Searching file ${msg.current} of ${msg.total}: ${msg.text.replace(/^\[.*?\]\s*/,'')}`;
            } else if (msg.cls === 'match') {
              // Real-time match count update
              const count = _sigmaCsvResults.length;
              $('search-progress-label').textContent =
                `${$('search-progress-label').textContent.split('·')[0].trim()} · ${count + 1} match(es) so far`;
            }
            // info/warn/done/error lines go to progress label briefly
            else if (msg.cls === 'cmd' || msg.cls === 'info') {
              $('search-progress-label').textContent = msg.text;
            }
          } catch(e) {}
        });
        read();
      }).catch(e => {
        toast('Stream error: ' + e.message);
        resetSearchUI();
      });
    }
    read();
  }).catch(e => {
    toast('Search failed: ' + e.message);
    resetSearchUI();
  });
};

$('btn-stop-search').onclick = async () => {
  if (_currentSearchId) {
    try {
      await fetch('/api/sigma/csv-search/stop', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ search_id: _currentSearchId }),
      });
    } catch(e) {}
    _currentSearchId = null;
  }
  toast('Search stopped.');
  resetSearchUI();
};

function resetSearchUI() {
  $('btn-run-search').disabled    = false;
  $('btn-run-search').textContent = '▶ Search';
  $('btn-stop-search').style.display = 'none';
}


function renderSearchResults(data) {
  const results = data.results || [];
  $('search-results-wrap').style.display = 'flex';
  $('search-results-label').textContent = `Results`;
  $('search-results-summary').textContent =
    `${results.length.toLocaleString()} match${results.length!==1?'es':''} across ${data.files_with_hits} file${data.files_with_hits!==1?'s':''} ` +
    `(${data.files_searched} CSV${data.files_searched!==1?'s':''} searched)`;

  const trunc = $('search-truncation-note');
  if (data.truncated) {
    trunc.style.display = '';
    trunc.textContent = `⚠ Results capped at ${data.max_results.toLocaleString()} — narrow your search or use more specific terms.`;
  } else {
    trunc.style.display = 'none';
  }

  if (!results.length) {
    $('search-results-thead').innerHTML = '';
    $('search-results-tbody').innerHTML = '<tr><td colspan="4" class="empty-state">No matches found.</td></tr>';
    return;
  }

  // Fixed columns + first few data columns
  const dataCols = Object.keys(results[0]?.data || {}).slice(0, 8);
  const allCols  = ['File', 'Row', 'Matched terms', ...dataCols];

  $('search-results-thead').innerHTML = '<tr>' +
    allCols.map(c => `<th style="min-width:90px">${escHtml(c)}</th>`).join('') + '</tr>';

  $('search-results-tbody').innerHTML = results.map(r => {
    const cells = [
      `<td title="${escHtml(r.file)}" style="font-family:var(--font-mono);font-size:10px">${escHtml(r.file)}</td>`,
      `<td style="color:var(--hint)">${r.row}</td>`,
      `<td style="color:var(--accent);font-size:11px">${escHtml((r.matched_terms||[]).join(', '))}</td>`,
      ...dataCols.map(c => { const v = escHtml(String(r.data?.[c]||'')); return `<td title="${v}">${v}</td>`; }),
    ];
    return '<tr>' + cells.join('') + '</tr>';
  }).join('');
}

$('btn-export-search-results').onclick = async () => {
  if (!_sigmaCsvResults.length) { toast('No results to export.'); return; }
  try {
    const r    = await apiFetch('/api/sigma/csv-search/export', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ results: _sigmaCsvResults }),
    });
    const blob = await r.blob();
    const a    = document.createElement('a');
    a.href     = URL.createObjectURL(blob);
    a.download = 'search_results.csv';
    a.click();
  } catch(e) { toast('Export failed: ' + e.message); }
};

// ── Saved searches ──────────────────────────────────────────────────
$('btn-load-saved').onclick = () => {
  const panel = $('saved-searches-panel');
  panel.style.display = panel.style.display === 'none' ? '' : 'none';
  loadSavedSearches();
};

$('btn-save-search').onclick = async () => {
  const terms = $('search-terms').value.split('\n').map(t=>t.trim()).filter(Boolean);
  if (!terms.length) { toast('Enter search terms to save.'); return; }
  const name = prompt('Name this search:');
  if (!name) return;
  const mode     = document.querySelector('input[name="search-mode"]:checked')?.value || 'any';
  const useRegex = $('search-regex').checked;
  const dir      = $('search-directory').value.trim();
  try {
    await apiFetch('/api/sigma/csv-search/saved', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ name, terms, mode, use_regex: useRegex, directory: dir,
                             created: new Date().toISOString().split('T')[0] }),
    });
    toast(`Search "${name}" saved.`);
    loadSavedSearches();
  } catch(e) { toast('Save failed: ' + e.message); }
};

async function loadSavedSearches() {
  try {
    const r = await apiFetch('/api/sigma/csv-search/saved');
    _savedSearches = await r.json();
    renderSavedSearches();
  } catch(e) { console.warn('Could not load saved searches:', e); }
}

function renderSavedSearches() {
  const list = $('saved-searches-list');
  if (!list) return;
  if (!_savedSearches.length) {
    list.innerHTML = '<div class="empty-state" style="padding:16px 0">No saved searches yet.</div>';
    return;
  }
  list.innerHTML = _savedSearches.map(s => `
    <div style="display:flex;align-items:center;gap:10px;padding:7px 0;border-bottom:1px solid var(--border)">
      <div style="flex:1;min-width:0">
        <div style="font-size:13px;font-weight:500">${escHtml(s.name)}</div>
        <div style="font-size:11px;color:var(--muted)">${escHtml(s.terms?.join(' · '))} &nbsp;·&nbsp; ${s.mode==='all'?'AND':'OR'}${s.use_regex?' · regex':''}</div>
        ${s.created ? `<div style="font-size:10px;color:var(--hint)">${escHtml(s.created)}</div>` : ''}
      </div>
      <button class="btn" style="font-size:11px" onclick="applySavedSearch('${escHtml(s.name).replace(/'/g,"\\'")}')">Load</button>
      <button class="icon-btn" style="color:var(--danger)" onclick="deleteSavedSearch('${escHtml(s.name).replace(/'/g,"\\'")}')">🗑</button>
    </div>`).join('');
}

function applySavedSearch(name) {
  const s = _savedSearches.find(x => x.name === name);
  if (!s) return;
  $('search-terms').value    = (s.terms || []).join('\n');
  $('search-regex').checked  = s.use_regex || false;
  if (s.directory) $('search-directory').value = s.directory;
  document.querySelectorAll('input[name="search-mode"]').forEach(r => {
    r.checked = r.value === (s.mode || 'any');
  });
  $('saved-searches-panel').style.display = 'none';
  toast(`Loaded search: ${name}`);
}

async function deleteSavedSearch(name) {
  try {
    await apiFetch(`/api/sigma/csv-search/saved/${encodeURIComponent(name)}`, { method: 'DELETE' });
    loadSavedSearches();
    toast(`Deleted: ${name}`);
  } catch(e) { toast('Delete failed: ' + e.message); }
}

// ═══════════════════════════════════════════════════════════════════
// UAL MODULE
// ═══════════════════════════════════════════════════════════════════
let _ualData       = {};    // { operation: { count, columns, rows, total } }
let _ualFile       = null;  // raw File kept for export
let _ualCurrentOp  = '';
let _ualSortCol    = '', _ualSortDir = 1;
let _ualGeoMap     = {};    // { ip: "City, State, Country [ISP]" }
let _ualGeoCols    = {};    // { op: [col_name, ...] }
let _ualColWidths  = {};    // { op: { col: px } } — persists across tab switches
let _ualResizeState = null; // active column-drag state
let _vResizeState   = null; // active vertical panel-drag state
let _ualGeoCoords  = {};    // { ip: { lat, lon } } — populated after geolocate

const UAL_PRIORITY = ['CreationDate','Operation','UserId','UserIds','ClientIP',
                      'ClientIPAddress','actorIpAddress','Workload','ResultStatus',
                      'ObjectId','UserAgent','RecordType','RecordId'];

// Upload
const udz = $('ual-dropzone');
udz.ondragover = e => { e.preventDefault(); udz.classList.add('drag'); };
udz.ondragleave = () => udz.classList.remove('drag');
udz.ondrop = e => { e.preventDefault(); udz.classList.remove('drag'); handleUALFile(e.dataTransfer.files[0]); };
$('ual-file-input').onchange = e => handleUALFile(e.target.files[0]);

async function handleUALFile(file) {
  if (!file || !file.name.toLowerCase().endsWith('.csv')) {
    toast('Please select a .csv file.');
    return;
  }
  _ualFile = file;
  const fd = new FormData();
  fd.append('file', file);
  try {
    const r    = await apiFetch('/api/ual/parse', { method: 'POST', body: fd });
    const data = await r.json();
    _ualData      = data.operations;
    _ualGeoMap    = {};
    _ualGeoCols   = {};
    _ualGeoCoords = {};
    _ualColWidths = {};
    const ops     = Object.keys(_ualData);
    _ualCurrentOp = ops[0] || '';
    const totalRows = ops.reduce((s,op) => s + (_ualData[op].total || 0), 0);
    $('ual-upload-view').style.display = 'none';
    $('ual-data-view').style.display   = 'flex';
    $('btn-ual-export').style.display    = '';
    $('btn-ual-reset').style.display     = '';
    $('btn-ual-geolocate').style.display = '';
    $('ual-stats').innerHTML = `
      <div class="stat-card"><div class="stat-label">Total rows</div><div class="stat-val">${totalRows.toLocaleString()}</div></div>
      <div class="stat-card"><div class="stat-label">Operations</div><div class="stat-val">${ops.length}</div></div>
      <div class="stat-card"><div class="stat-label">Parse errors</div><div class="stat-val" style="color:${data.errors>0?'var(--danger)':'inherit'}">${data.errors}</div></div>`;
    renderUALTabs();
    renderUALTable();
    if (data.errors > 0) toast(`Parsed with ${data.errors} row error(s).`);
  } catch(e) { toast('Parse error: ' + e.message); }
}

function renderUALTabs() {
  $('ual-tabs').innerHTML = Object.keys(_ualData).map(op =>
    `<div class="tab ${op===_ualCurrentOp?'active':''}" onclick="switchUALOp('${op.replace(/\\/g,'\\\\').replace(/'/g,"\\'")}')">
      ${escHtml(op)}<span class="tab-badge">${(_ualData[op].total||0).toLocaleString()}</span>
    </div>`).join('');
}

function switchUALOp(op) {
  _ualCurrentOp = op; _ualSortCol = ''; _ualSortDir = 1;
  $('ual-search').value = '';
  renderUALTabs(); renderUALTable();
}

function _ualBuildColOrder(cols) {
  const colSet = new Set(cols);
  const used   = new Set();
  const result = [];
  function place(c) {
    if (used.has(c) || !colSet.has(c)) return;
    result.push(c); used.add(c);
    // Place any _Port sibling immediately after its IP column
    const portCol = c + '_Port';
    if (colSet.has(portCol) && !used.has(portCol)) { result.push(portCol); used.add(portCol); }
  }
  UAL_PRIORITY.forEach(place);
  cols.forEach(place);
  return result;
}

function renderUALTable() {
  const opData = _ualData[_ualCurrentOp];
  if (!opData) return;
  const baseCols = opData.columns || [];

  // Insert geo columns right after detected IP columns
  const geoCols = _ualGeoCols[_ualCurrentOp] || [];
  let orderedCols = _ualBuildColOrder(baseCols);
  if (geoCols.length) {
    const withGeo = [];
    for (const col of orderedCols) {
      withGeo.push(col);
      if (geoCols.includes(col)) withGeo.push(col + '_geo');
    }
    orderedCols = withGeo;
  }

  const sel  = $('ual-col-filter');
  const prev = sel.value;
  sel.innerHTML = '<option value="">All columns</option>' +
    orderedCols.map(c => `<option value="${escHtml(c)}" ${c===prev?'selected':''}>${escHtml(c)}</option>`).join('');

  const geoNote = geoCols.length ? ` · geo: ${geoCols.join(', ')}` : '';
  $('ual-hint').textContent = `${orderedCols.length} columns · click headers to sort${geoNote}`;
  renderUALBody(orderedCols);
}

function renderUALBody(cols) {
  const opData = _ualData[_ualCurrentOp];
  if (!opData) return;

  let rows = opData.rows || [];
  const q   = $('ual-search').value.toLowerCase().trim();
  const col = $('ual-col-filter').value;

  if (q) rows = rows.filter(r => {
    if (col) return String(r[col]||'').toLowerCase().includes(q);
    return Object.values(r).some(v => String(v||'').toLowerCase().includes(q));
  });

  if (_ualSortCol) {
    rows = [...rows].sort((a,b) =>
      String(a[_ualSortCol]||'').localeCompare(String(b[_ualSortCol]||''), undefined, {numeric:true}) * _ualSortDir);
  }

  const geoCols = _ualGeoCols[_ualCurrentOp] || [];

  $('ual-count').textContent = rows.length.toLocaleString() + ' rows';
  const _colWs = _ualColWidths[_ualCurrentOp] || {};
  $('ual-thead').innerHTML = '<tr>' + (cols||[]).map(c => {
    const w  = _colWs[c];
    const ws = w ? ` style="width:${w}px;min-width:${w}px;max-width:${w}px"` : '';
    const safeC = c.replace(/\\/g,'\\\\').replace(/'/g,"\\'");
    return `<th${ws} data-col="${escHtml(c)}" class="${_ualSortCol===c?'sorted':''}" onclick="ualSort('${safeC}')">`
      + `${escHtml(c.replace(/_geo$/,' 🌐'))}<span class="sort-arrow">${_ualSortCol===c?(_ualSortDir===1?'▲':'▼'):'⇅'}</span>`
      + `<div class="col-resize-handle" onclick="event.stopPropagation()"></div></th>`;
  }).join('') + '</tr>';
  _ualInitColWidths(cols);

  $('ual-tbody').innerHTML = rows.slice(0, 500).map(r => '<tr>' + (cols||[]).map(c => {
    let v;
    if (c.endsWith('_geo')) {
      // Geo column — look up from geo map using the corresponding IP
      const ipCol = c.slice(0, -4);
      const ip    = (r[ipCol]||'').split(':')[0];  // strip port
      v = _ualGeoMap[ip] || '';
      const style = v ? 'color:var(--accent);font-size:11px' : 'color:var(--hint)';
      return `<td title="${escHtml(v)}" style="${style}">${escHtml(v || '–')}</td>`;
    } else {
      v = escHtml(String(r[c]||''));
      return `<td title="${v}">${v}</td>`;
    }
  }).join('') + '</tr>').join('') +
  (rows.length > 500
    ? `<tr><td colspan="${(cols||[]).length}" style="text-align:center;color:var(--hint);padding:10px;font-size:11px">Showing 500 of ${rows.length.toLocaleString()} — search to narrow</td></tr>`
    : '');

  // Store cols for re-render on sort
  $('ual-tbody').dataset.cols = JSON.stringify(cols);
}

function ualSort(col) {
  if (_ualSortCol===col) _ualSortDir*=-1; else { _ualSortCol=col; _ualSortDir=1; }
  const cols = JSON.parse($('ual-tbody').dataset.cols || '[]');
  renderUALBody(cols);
}

// ── Column resize ─────────────────────────────────────────────────
function _ualInitColWidths(cols) {
  if (!cols || !cols.length) return;
  const table  = $('ual-thead').closest('table');
  const ths    = Array.from($('ual-thead').querySelectorAll('th'));
  const stored = _ualColWidths[_ualCurrentOp] || (_ualColWidths[_ualCurrentOp] = {});
  // Capture natural widths for columns not yet resized by the user
  ths.forEach((th, i) => { if (cols[i] && !stored[cols[i]]) stored[cols[i]] = Math.max(60, th.offsetWidth); });
  // Build / update colgroup so table-layout:fixed honours our widths
  let cg = table.querySelector('colgroup');
  if (!cg) { cg = document.createElement('colgroup'); table.insertBefore(cg, table.firstChild); }
  cg.innerHTML = cols.map(c => `<col style="width:${stored[c]||120}px">`).join('');
  table.style.tableLayout = 'fixed';
}

document.addEventListener('mousedown', e => {
  const handle = e.target.closest('#ual-thead .col-resize-handle');
  if (!handle) return;
  const th    = handle.closest('th');
  const table = th.closest('table');
  const cg    = table.querySelector('colgroup');
  const idx   = Array.from(th.parentElement.querySelectorAll('th')).indexOf(th);
  const colEl = cg ? cg.querySelectorAll('col')[idx] : null;
  _ualResizeState = { col: th.dataset.col, colEl, startX: e.clientX, startW: th.offsetWidth };
  handle.classList.add('active');
  document.body.classList.add('col-resizing');
  e.preventDefault();
});
document.addEventListener('mousedown', e => {
  const vHandle = e.target.closest('.v-resize-handle');
  if (!vHandle) return;
  const targetId = vHandle.dataset.target;
  const target   = $(targetId);
  if (!target) return;
  _vResizeState = { el: target, handle: vHandle, startY: e.clientY, startH: target.offsetHeight };
  vHandle.classList.add('active');
  document.body.classList.add('row-resizing');
  e.preventDefault();
});
document.addEventListener('mousemove', e => {
  if (_ualResizeState) {
    const { col, colEl, startX, startW } = _ualResizeState;
    const w = Math.max(60, startW + (e.clientX - startX));
    (_ualColWidths[_ualCurrentOp] || (_ualColWidths[_ualCurrentOp] = {}))[col] = w;
    if (colEl) colEl.style.width = w + 'px';
  }
  if (_vResizeState) {
    const { el, startY, startH } = _vResizeState;
    const newH = Math.max(60, startH + (e.clientY - startY));
    el.style.maxHeight = newH + 'px';
    el.style.height    = newH + 'px';
  }
});
document.addEventListener('mouseup', () => {
  if (_ualResizeState) {
    _ualResizeState = null;
    document.querySelectorAll('.col-resize-handle.active').forEach(h => h.classList.remove('active'));
    document.body.classList.remove('col-resizing');
  }
  if (_vResizeState) {
    _vResizeState.handle.classList.remove('active');
    _vResizeState = null;
    document.body.classList.remove('row-resizing');
  }
});

$('ual-search').oninput = () => { const cols = JSON.parse($('ual-tbody').dataset.cols||'[]'); renderUALBody(cols); };
$('ual-col-filter').onchange = () => { const cols = JSON.parse($('ual-tbody').dataset.cols||'[]'); renderUALBody(cols); };

$('btn-ual-reset').onclick = () => {
  _ualData = {}; _ualFile = null; _ualCurrentOp = ''; _ualSortCol = ''; _ualSortDir = 1;
  _ualGeoMap = {}; _ualGeoCols = {}; _ualGeoCoords = {}; _ualColWidths = {};
  $('btn-ual-travel').style.display = 'none';
  const _resetTable = $('ual-thead').closest('table');
  const _resetCg = _resetTable && _resetTable.querySelector('colgroup');
  if (_resetCg) _resetCg.remove();
  if (_resetTable) _resetTable.style.tableLayout = '';
  $('ual-data-view').style.display   = 'none';
  $('ual-upload-view').style.display = 'flex';
  $('btn-ual-export').style.display    = 'none';
  $('btn-ual-reset').style.display     = 'none';
  $('btn-ual-geolocate').style.display = 'none';
  $('ual-file-input').value = '';
};

// ── Geolocation ───────────────────────────────────────────────────
$('btn-ual-geolocate').onclick = async () => {
  const btn = $('btn-ual-geolocate');
  btn.disabled    = true;
  btn.textContent = '🌐 Looking up…';

  // Build compact operations payload (columns + first 500 rows per op for IP detection)
  const ops = {};
  for (const [op, opData] of Object.entries(_ualData)) {
    ops[op] = { columns: opData.columns || [], rows: opData.rows || [] };
  }

  $('ual-geo-progress').style.display = '';
  $('ual-geo-label').textContent = 'Detecting IP columns...';
  $('ual-geo-bar').style.width   = '0%';
  $('ual-geo-pct').textContent   = '';

  try {
    const resp = await fetch('/api/ual/geolocate', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ operations: ops }),
    });

    const reader  = resp.body.getReader();
    const decoder = new TextDecoder();
    let buf = '';

    await new Promise((resolve) => {
      function read() {
        reader.read().then(({ done, value }) => {
          if (done) { resolve(); return; }
          buf += decoder.decode(value, { stream: true });
          const events = buf.split('\n\n'); buf = events.pop();
          events.forEach(ev => {
            const line = ev.replace(/^data: /, '');
            if (!line) return;
            try {
              const msg = JSON.parse(line);
              if (msg.cls === 'complete') {
                _ualGeoMap    = msg.geo_map       || {};
                _ualGeoCols   = msg.ip_cols_by_op || {};
                _ualGeoCoords = msg.geo_coords    || {};
                // Show travel button only when UserLoggedIn operation exists
                $('btn-ual-travel').style.display = _ualData['UserLoggedIn'] ? '' : 'none';
                // Refresh current tab
                renderUALTable();
                toast(`Geolocation complete — ${Object.keys(_ualGeoMap).length.toLocaleString()} IPs resolved`);
                resolve();
              } else if (msg.cls === 'progress') {
                const pct = msg.pct || 0;
                $('ual-geo-bar').style.width = pct + '%';
                $('ual-geo-pct').textContent = pct + '%';
                $('ual-geo-label').textContent = `Batch ${msg.current} of ${msg.total}`;
              } else {
                $('ual-geo-label').textContent = msg.text;
              }
            } catch(e) {}
          });
          read();
        });
      }
      read();
    });
  } catch(e) {
    toast('Geolocation error: ' + e.message);
  } finally {
    $('ual-geo-progress').style.display = 'none';
    btn.disabled    = false;
    btn.textContent = '🌐 Geolocate IPs';
  }
};

// ── Impossible Travel Analysis ────────────────────────────────────
$('btn-ual-travel').onclick = async () => {
  if (!_ualFile) { toast('No file loaded.'); return; }
  if (!Object.keys(_ualGeoCoords).length) { toast('Run Geolocate IPs first.'); return; }

  const btn = $('btn-ual-travel');
  btn.disabled    = true;
  btn.textContent = '🚨 Analyzing…';

  try {
    const fd = new FormData();
    fd.append('file',       _ualFile);
    fd.append('geo_map',    JSON.stringify(_ualGeoMap));
    fd.append('geo_coords', JSON.stringify(_ualGeoCoords));

    const r    = await apiFetch('/api/ual/travel', { method: 'POST', body: fd });
    const data = await r.json();

    _renderTravelModal(data.flags || [], data);
    openModal('travel-modal');
  } catch(e) {
    toast('Travel analysis failed: ' + e.message);
  } finally {
    btn.disabled    = false;
    btn.textContent = '🚨 Impossible Travel';
  }
};

$('travel-modal-close').onclick = () => closeModal('travel-modal');
$('travel-modal').onclick = e => { if (e.target === $('travel-modal')) closeModal('travel-modal'); };

function _fmtHours(h) {
  if (h === 0) return 'simultaneous';
  const hh = Math.floor(h);
  const mm = Math.round((h - hh) * 60);
  if (hh > 0) return `${hh}h ${mm}m`;
  return `${mm}m`;
}

function _renderTravelModal(flags, stats = {}) {
  const { total_rows = 0, analyzed_pairs = 0, skipped_no_coords = 0, skipped_date_err = 0 } = stats;
  const parts = [];
  if (total_rows)        parts.push(`${total_rows.toLocaleString()} UserLoggedIn rows`);
  if (analyzed_pairs)    parts.push(`${analyzed_pairs.toLocaleString()} pairs analyzed`);
  if (skipped_no_coords) parts.push(`⚠ ${skipped_no_coords.toLocaleString()} skipped (no geo coords)`);
  if (skipped_date_err)  parts.push(`⚠ ${skipped_date_err.toLocaleString()} skipped (unparseable date)`);
  $('travel-summary').textContent = parts.join(' · ');

  if (!flags.length) {
    $('travel-results').innerHTML = '<div class="empty-state">No impossible travel detected.<br>All consecutive logins are within 900 km/h travel time.</div>';
    return;
  }

  // Sort by required speed descending (null speed = simultaneous = highest severity)
  flags.sort((a, b) => (b.speed_kmh ?? Infinity) - (a.speed_kmh ?? Infinity));

  $('travel-results').innerHTML = flags.map(f => {
    const spd   = f.speed_kmh ?? Infinity;
    const speed = isFinite(spd) ? `${Math.round(spd).toLocaleString()} km/h` : '∞ (simultaneous)';
    const color = spd > 3000 ? 'var(--danger)' : spd > 1500 ? '#f59e0b' : 'var(--accent)';
    const dist  = `${Math.round(f.dist_km).toLocaleString()} km`;
    const gap   = _fmtHours(f.delta_hours);
    return `<div class="travel-flag" style="border-left-color:${color}">
      <div class="travel-user">${escHtml(f.user)}</div>
      <div class="travel-row">
        <span class="travel-time">${escHtml(f.t1)} UTC</span>
        <span class="travel-ip">${escHtml(f.ip1)}</span>
        <span class="travel-loc">${escHtml(f.loc1)}</span>
      </div>
      <div class="travel-mid" style="color:${color}">
        ↕ ${gap} &nbsp;·&nbsp; ${dist} &nbsp;·&nbsp; <strong>${speed} required</strong>
      </div>
      <div class="travel-row">
        <span class="travel-time">${escHtml(f.t2)} UTC</span>
        <span class="travel-ip">${escHtml(f.ip2)}</span>
        <span class="travel-loc">${escHtml(f.loc2)}</span>
      </div>
    </div>`;
  }).join('');
}

// ── Export (UAL) ──────────────────────────────────────────────────
let _exportFmt      = 'xlsx';
let _exportSelected = {};

$('btn-ual-export').onclick = () => {
  const ops = Object.keys(_ualData);
  _exportSelected = {};
  ops.forEach(op => _exportSelected[op] = true);
  renderExportOpList();
  openModal('export-modal');
};
$('export-modal-close').onclick = $('export-cancel').onclick = () => closeModal('export-modal');
$('export-modal').onclick = e => { if (e.target===$('export-modal')) closeModal('export-modal'); };

function setExportFmt(fmt) {
  _exportFmt = fmt;
  $('fmt-xlsx').classList.toggle('active', fmt==='xlsx');
  $('fmt-csv').classList.toggle('active',  fmt==='csv');
}

function renderExportOpList() {
  const ops    = Object.keys(_ualData);
  const checked = ops.filter(op => _exportSelected[op]).length;
  $('export-sel-count').textContent  = `${checked} of ${ops.length} selected`;
  const total = ops.filter(op => _exportSelected[op]).reduce((s,op) => s + (_ualData[op].total||0), 0);
  $('export-row-count').textContent  = total.toLocaleString() + ' rows';
  $('export-op-list').innerHTML = ops.map(op => {
    const safeOp = op.replace(/\\/g,'\\\\').replace(/'/g,"\\'");
    return `<div class="op-row" onclick="toggleExportOp('${safeOp}')">
      <input type="checkbox" ${_exportSelected[op]?'checked':''} onclick="event.stopPropagation();toggleExportOp('${safeOp}')"/>
      <span class="op-row-name">${escHtml(op)}</span>
      <span class="op-row-count">${(_ualData[op].total||0).toLocaleString()}</span>
    </div>`;
  }).join('');
}

function toggleExportOp(op) { _exportSelected[op] = !_exportSelected[op]; renderExportOpList(); }
function selectAllExportOps(val) { Object.keys(_exportSelected).forEach(op => _exportSelected[op] = val); renderExportOpList(); }

$('export-confirm').onclick = async () => {
  if (!_ualFile) { toast('No file loaded.'); return; }
  const ops = Object.keys(_exportSelected).filter(op => _exportSelected[op]);
  if (!ops.length) { toast('Select at least one operation.'); return; }
  const fd = new FormData();
  fd.append('file', _ualFile);
  fd.append('format', _exportFmt);
  fd.append('operations', JSON.stringify(ops));
  // Include any geo data so the export can embed geo columns
  if (Object.keys(_ualGeoMap).length)  fd.append('geo_map',  JSON.stringify(_ualGeoMap));
  if (Object.keys(_ualGeoCols).length) fd.append('geo_cols', JSON.stringify(_ualGeoCols));
  try {
    $('export-confirm').disabled    = true;
    $('export-confirm').textContent = 'Exporting...';
    const r    = await apiFetch('/api/ual/export', { method: 'POST', body: fd });
    const blob = await r.blob();
    const cd   = r.headers.get('Content-Disposition') || '';
    const fname = cd.match(/filename=([^;]+)/)?.[1] || ('UAL_Export.' + _exportFmt);
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = fname; a.click();
    closeModal('export-modal');
    toast('Export downloaded.');
  } catch(e) { toast('Export failed: ' + e.message); }
  finally {
    $('export-confirm').disabled    = false;
    $('export-confirm').textContent = 'Download';
  }
};


loadRules();
loadArtifactTools();
loadSavedSearches();
checkHayabusaStatus();

document.addEventListener('DOMContentLoaded', () => {
  addBrowseButton('scan-path',            'folder', 'Select scan target folder');
  addBrowseButton('hayabusa-evtx-path',   'folder', 'Select EVTX folder (or single .evtx file)');
  addBrowseButton('hayabusa-output-path', 'folder', 'Select output folder for Hayabusa CSV');
  addBrowseButton('search-directory',     'folder', 'Select CSV directory to search');
});

