/* IR Toolkit — Frontend JS
   All data flows through the Flask backend at /api/*
   No fake simulation — real responses or clear errors.
*/

// ── Helpers ──────────────────────────────────────────────────────────────────
const $ = id => document.getElementById(id);

function toast(msg, duration=2800) {
  const t = $('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.remove('show'), duration);
}

function formatSize(n) {
  if (n < 1024) return n + ' B';
  if (n < 1048576) return (n/1024).toFixed(1) + ' KB';
  if (n < 1073741824) return (n/1048576).toFixed(2) + ' MB';
  return (n/1073741824).toFixed(2) + ' GB';
}

async function apiFetch(url, opts={}) {
  const resp = await fetch(url, opts);
  if (!resp.ok) {
    const body = await resp.json().catch(() => ({error: resp.statusText}));
    throw new Error(body.error || resp.statusText);
  }
  return resp;
}

// ── NAV ──────────────────────────────────────────────────────────────────────
document.querySelectorAll('.nav-item').forEach(item => {
  item.onclick = () => {
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    item.classList.add('active');
    document.querySelectorAll('.module').forEach(m => m.classList.remove('active'));
    $('mod-' + item.dataset.mod).classList.add('active');
  };
});

// ═══════════════════════════════════════════════════════════════════
// YARA MODULE
// ═══════════════════════════════════════════════════════════════════
let _rules      = [];
let _editingId  = null;
let _ruleSearch = '';
let _rulePage   = 0;
let _rulePageSize = 10;

async function loadRules() {
  try {
    const [rulesResp, infoResp, modsResp] = await Promise.all([
      apiFetch('/api/yara/rules'),
      apiFetch('/api/yara/storage-info'),
      apiFetch('/api/yara/modules'),
    ]);
    _rules = await rulesResp.json();
    const info = await infoResp.json();
    const mods = await modsResp.json();

    const rfp = $('rules-file-path');
    const ydp = $('yar-dir-path');
    if (rfp) rfp.textContent = info.rules_file;
    if (ydp) ydp.textContent = info.yar_dir;

    // Show YARA module availability
    const modBox = $('yara-modules-info');
    if (modBox) {
      const avail   = mods.available || [];
      const unavail = mods.unavailable || [];
      modBox.innerHTML = `
        <strong style="color:var(--text)">YARA modules available:</strong>
        ${avail.map(m => `<span style="font-family:var(--font-mono);font-size:10px;padding:1px 6px;border-radius:4px;background:rgba(29,158,117,0.12);color:var(--accent)">${m}</span>`).join(' ')}
        ${unavail.length ? `&nbsp; <strong style="color:var(--text)">unavailable:</strong>
        ${unavail.map(m => `<span style="font-family:var(--font-mono);font-size:10px;padding:1px 6px;border-radius:4px;background:rgba(226,75,74,0.1);color:var(--danger)">${m}</span>`).join(' ')}
        <span style="color:var(--hint);font-size:10px">&nbsp;(rules using these are skipped)</span>` : ''}`;
    }

    _rulePage = 0;
    renderRules();
  } catch(e) {
    $('rules-list').innerHTML = `<div class="empty-state">Failed to load rules: ${e.message}</div>`;
  }
}

function toggleStoragePaths() {
  const box = $('storage-paths-box');
  if (box) box.style.display = box.style.display === 'none' ? '' : 'none';
}

// Returns custom rules that match the current search term (excludes forge packages)
function _filteredRules() {
  const custom = _rules.filter(r => !r.is_forge_package);
  if (!_ruleSearch) return custom;
  const q = _ruleSearch.toLowerCase();
  return custom.filter(r =>
    r.name.toLowerCase().includes(q) ||
    r.tag.toLowerCase().includes(q)  ||
    r.body.toLowerCase().includes(q)
  );
}

function renderRules() {
  const customRules = _rules.filter(r => !r.is_forge_package);
  const forgePkgs   = _rules.filter(r => r.is_forge_package);
  const filtered    = _filteredRules();   // filters custom rules only
  const totalPages  = Math.max(1, Math.ceil(filtered.length / _rulePageSize));
  if (_rulePage >= totalPages) _rulePage = totalPages - 1;
  const pageRules   = filtered.slice(_rulePage * _rulePageSize, (_rulePage + 1) * _rulePageSize);
  const selCount    = customRules.filter(r => r.selected).length;

  const rc = $('rule-count');
  if (rc) rc.textContent = customRules.length +
    (forgePkgs.length ? ` + ${forgePkgs.length} Forge pkg${forgePkgs.length>1?'s':''}` : '');

  const list = $('rules-list');

  // ── Forge package summary cards ──
  const forgeCardsHtml = forgePkgs.map(pkg => `
    <div style="background:rgba(29,158,117,0.06);border:1px solid var(--accent);border-radius:var(--radius);padding:9px 13px;display:flex;align-items:center;gap:10px;margin-bottom:4px">
      <div style="flex:1;min-width:0">
        <div style="font-size:12px;font-weight:500;color:var(--accent)">📦 ${escHtml(pkg.name)}</div>
        <div style="font-size:11px;color:var(--muted);margin-top:2px">Compiled as a complete package · all imports and private rules work correctly</div>
        ${pkg.path ? `<div style="font-size:10px;color:var(--hint);font-family:var(--font-mono);margin-top:2px">${escHtml(pkg.path)}</div>` : ''}
      </div>
      <div style="font-size:11px;color:var(--muted);text-align:right;flex-shrink:0">
        <div style="color:var(--accent)">Always included in scans</div>
        <div style="color:var(--hint);font-size:10px">Not individually selectable</div>
      </div>
    </div>`).join('');

  // ── Toolbar ──
  const toolbarHtml = `
    <div id="rules-toolbar" style="display:flex;flex-direction:column;gap:8px;flex-shrink:0">
      <div style="display:flex;gap:8px;align-items:center">
        <input type="text" id="rule-search-input" placeholder="Search custom rules…"
               value="${escHtml(_ruleSearch)}"
               oninput="onRuleSearch(this.value)"
               style="flex:1;font-size:12px;padding:6px 10px;border:1px solid var(--border2);border-radius:var(--radius);background:var(--card);color:var(--text);font-family:var(--font-sans)"/>
        ${_ruleSearch ? `<button class="btn" onclick="onRuleSearch('')" style="flex-shrink:0">✕ Clear</button>` : ''}
        <select onchange="onPageSizeChange(this.value)"
                style="font-size:12px;padding:5px 8px;border:1px solid var(--border2);border-radius:var(--radius);background:var(--card);color:var(--text);flex-shrink:0">
          ${[10,25,50,100,250].map(n =>
            `<option value="${n}" ${n===_rulePageSize?'selected':''}>${n} per page</option>`).join('')}
        </select>
      </div>
      <div style="display:flex;gap:8px;align-items:center;font-size:12px;color:var(--muted)">
        <button class="btn" style="font-size:11px" onclick="selectAllFiltered(true)">
          Select all${_ruleSearch?' matching':''} (${filtered.length.toLocaleString()})
        </button>
        <button class="btn" style="font-size:11px" onclick="selectPageRules(true)">Select page</button>
        <button class="btn" style="font-size:11px" onclick="selectAllFiltered(false)">Deselect all</button>
        <span style="margin-left:auto;color:var(--hint)">
          ${selCount > 0 ? `<strong style="color:var(--accent)">${selCount.toLocaleString()} selected</strong> &nbsp;·&nbsp;` : ''}
          ${_ruleSearch
            ? `${filtered.length.toLocaleString()} match${filtered.length!==1?'es':''} of ${customRules.length.toLocaleString()}`
            : `${customRules.length.toLocaleString()} custom rule${customRules.length!==1?'s':''}`}
        </span>
      </div>
    </div>`;

  if (!filtered.length && !forgePkgs.length) {
    list.innerHTML = toolbarHtml +
      `<div class="empty-state">${_ruleSearch ? `No rules match "${escHtml(_ruleSearch)}"` : 'No rules yet.'}</div>`;
    return;
  }

  const cardsHtml = pageRules.filter(r => !r.is_forge_package).map(r => `
    <div class="rule-card ${r.selected?'selected':''}">
      <input type="checkbox" class="rule-check" ${r.selected?'checked':''} onchange="toggleSelect(${r.id})"/>
      <div class="rule-info">
        <div class="rule-name">${escHtml(r.name)}</div>
        <div class="rule-meta">${r.body.split('\n').length} lines</div>
        <div class="rule-tags">
          <span class="tag">${escHtml(r.tag)}</span>
          <span class="tag sev-${r.sev}">${r.sev}</span>
        </div>
      </div>
      <div class="rule-actions">
        <button class="icon-btn" title="Edit" onclick="openEditRule(${r.id})">✎</button>
        <button class="icon-btn" title="Delete" style="color:var(--danger)" onclick="deleteRule(${r.id})">🗑</button>
      </div>
    </div>`).join('');

  const paginationHtml = totalPages > 1 ? `
    <div style="display:flex;align-items:center;justify-content:center;gap:6px;padding-top:4px;flex-shrink:0">
      <button class="btn" style="font-size:11px" ${_rulePage===0?'disabled':''} onclick="goToPage(0)">«</button>
      <button class="btn" style="font-size:11px" ${_rulePage===0?'disabled':''} onclick="goToPage(${_rulePage-1})">‹</button>
      <span style="font-size:12px;color:var(--muted);padding:0 8px">
        Page ${_rulePage+1} of ${totalPages} &nbsp;·&nbsp;
        ${_rulePage*_rulePageSize+1}–${Math.min((_rulePage+1)*_rulePageSize,filtered.length)} of ${filtered.length.toLocaleString()}
      </span>
      <button class="btn" style="font-size:11px" ${_rulePage>=totalPages-1?'disabled':''} onclick="goToPage(${_rulePage+1})">›</button>
      <button class="btn" style="font-size:11px" ${_rulePage>=totalPages-1?'disabled':''} onclick="goToPage(${totalPages-1})">»</button>
    </div>` : '';

  list.innerHTML = forgeCardsHtml + toolbarHtml + cardsHtml + paginationHtml;

  const inp = $('rule-search-input');
  if (inp && _ruleSearch) { inp.focus(); inp.setSelectionRange(inp.value.length, inp.value.length); }
}


function onRuleSearch(val) {
  _ruleSearch = val;
  _rulePage   = 0;
  renderRules();
  // Keep focus in the input
  const inp = $('rule-search-input');
  if (inp) { inp.focus(); inp.setSelectionRange(inp.value.length, inp.value.length); }
}

function onPageSizeChange(val) {
  _rulePageSize = parseInt(val);
  _rulePage     = 0;
  renderRules();
}

function goToPage(n) {
  _rulePage = n;
  renderRules();
  // Scroll rules list to top
  const list = $('rules-list');
  if (list) list.scrollTop = 0;
}

function selectAllFiltered(val) {
  const filtered = _filteredRules();
  const ids = new Set(filtered.map(r => r.id));
  if (val) {
    // Select all filtered rules
    _rules.forEach(r => { if (ids.has(r.id)) r.selected = true; });
  } else {
    // Deselect all rules regardless of filter
    _rules.forEach(r => r.selected = false);
  }
  renderRules();
}

function selectPageRules(val) {
  const filtered  = _filteredRules();
  const pageRules = filtered.slice(_rulePage * _rulePageSize, (_rulePage + 1) * _rulePageSize);
  const ids = new Set(pageRules.map(r => r.id));
  _rules.forEach(r => { if (ids.has(r.id)) r.selected = val; });
  renderRules();
}

function escHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function toggleSelect(id) {
  const r = _rules.find(x => x.id === id);
  if (r) r.selected = !r.selected;
  renderRules();
}

// Add / Edit modal
$('btn-add-rule').onclick = () => {
  _editingId = null;
  $('modal-title').textContent = 'Add YARA Rule';
  ['new-rule-name','new-rule-tag','new-rule-body'].forEach(id => $(id).value = '');
  $('new-rule-sev').value = 'med';
  openModal('modal-backdrop');
};

function openEditRule(id) {
  const r = _rules.find(x => x.id === id);
  if (!r) return;
  _editingId = id;
  $('modal-title').textContent = 'Edit Rule';
  $('new-rule-name').value = r.name;
  $('new-rule-tag').value  = r.tag;
  $('new-rule-sev').value  = r.sev;
  $('new-rule-body').value = r.body;
  openModal('modal-backdrop');
}

$('modal-close').onclick = $('modal-cancel').onclick = () => closeModal('modal-backdrop');
$('modal-backdrop').onclick = e => { if (e.target === $('modal-backdrop')) closeModal('modal-backdrop'); };

$('modal-save').onclick = async () => {
  const name = $('new-rule-name').value.trim();
  const body = $('new-rule-body').value.trim();
  if (!name || !body) { toast('Name and rule body are required.'); return; }
  const payload = { name, tag: $('new-rule-tag').value.trim()||'general', sev: $('new-rule-sev').value, body };
  try {
    if (_editingId) {
      await apiFetch(`/api/yara/rules/${_editingId}`, { method:'PUT', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload) });
    } else {
      await apiFetch('/api/yara/rules', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload) });
    }
    closeModal('modal-backdrop');
    await loadRules();
    toast(_editingId ? 'Rule updated.' : 'Rule added.');
  } catch(e) { toast('Error: ' + e.message); }
};

async function deleteRule(id) {
  if (!confirm('Delete this rule?')) return;
  try {
    await apiFetch(`/api/yara/rules/${id}`, { method: 'DELETE' });
    await loadRules();
    toast('Rule deleted.');
  } catch(e) { toast('Error: ' + e.message); }
}

// Import .yar
$('btn-import').onclick = () => $('import-yar-input').click();
$('import-yar-input').onchange = async e => {
  const files = e.target.files;
  if (!files.length) return;
  const fd = new FormData();
  Array.from(files).forEach(f => fd.append('files', f));
  try {
    const r = await apiFetch('/api/yara/import', { method:'POST', body:fd });
    const data = await r.json();
    await loadRules();
    toast(`Imported ${data.imported} rule(s).`);
    if (data.errors.length) console.warn('Import errors:', data.errors);
  } catch(e) { toast('Import failed: ' + e.message); }
  $('import-yar-input').value = '';
};

// Export all rules
$('btn-export-rules').onclick = () => { window.location.href = '/api/yara/export'; };

// Scan
let _scanSource = null;

$('btn-scan').onclick = () => {
  const path = $('scan-path').value.trim();
  if (!path) { $('scan-path').focus(); return; }
  const useSelected = $('opt-selected').checked;
  const ruleIds = useSelected ? _rules.filter(r => r.selected).map(r => r.id) : [];
  if (useSelected && !ruleIds.length) { toast('No rules selected.'); return; }

  const term = $('scan-terminal');
  term.innerHTML = '';
  term.classList.add('visible');
  $('btn-scan').disabled = true;
  $('btn-stop-scan').style.display = '';

  const body = {
    path,
    recursive: $('opt-recursive').checked,
    timeout:   $('opt-timeout').checked ? 30 : 0,
    rule_ids:  ruleIds.length ? ruleIds : null,
  };

  if (_scanSource) _scanSource.close();

  // Use SSE for streaming results
  fetch('/api/yara/scan', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(body),
  }).then(resp => {
    const reader = resp.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    function read() {
      reader.read().then(({ done, value }) => {
        if (done) {
          $('btn-scan').disabled = false;
          $('btn-stop-scan').style.display = 'none';
          return;
        }
        buffer += decoder.decode(value, { stream: true });
        const events = buffer.split('\n\n');
        buffer = events.pop();
        events.forEach(ev => {
          const line = ev.replace(/^data: /, '');
          if (!line) return;
          try {
            const { cls, text } = JSON.parse(line);
            appendTermLine(term, cls, text);
          } catch(e) {}
        });
        read();
      });
    }
    read();
    _scanSource = { close: () => reader.cancel() };
  }).catch(e => {
    appendTermLine(term, 'error', '[!] Scan failed: ' + e.message);
    $('btn-scan').disabled = false;
    $('btn-stop-scan').style.display = 'none';
  });
};

$('btn-stop-scan').onclick = () => {
  if (_scanSource) { _scanSource.close(); _scanSource = null; }
  appendTermLine($('scan-terminal'), 'warn', '[!] Scan stopped by user.');
  $('btn-scan').disabled = false;
  $('btn-stop-scan').style.display = 'none';
};

function appendTermLine(container, cls, text) {
  const p = document.createElement('p');
  p.className = 't-' + cls;
  p.textContent = text;
  container.appendChild(p);
  container.scrollTop = container.scrollHeight;
}

// ═══════════════════════════════════════════════════════════════════
// FILE HASHER MODULE
// ═══════════════════════════════════════════════════════════════════
let _fileData      = null;
let _hasherFile    = null;
let _yargenRule    = '';
let _quickRule     = '';
let _selStrings    = new Set();
let _quickMode     = 'hash';
let _sizeTolPct    = 0;
let _setupLogIndex = 0;
let _setupPoller   = null;

// ── Drop / file input ─────────────────────────────────────────────
$('hasher-file-input').onchange = e => handleHasherFile(e.target.files[0]);
const hdz = $('hasher-dropzone');
hdz.ondragover = e => { e.preventDefault(); hdz.classList.add('drag'); };
hdz.ondragleave = () => hdz.classList.remove('drag');
hdz.ondrop = e => { e.preventDefault(); hdz.classList.remove('drag'); handleHasherFile(e.dataTransfer.files[0]); };

async function handleHasherFile(file) {
  if (!file) return;
  _hasherFile = file;
  _selStrings = new Set();
  _quickMode  = 'hash';
  _sizeTolPct = 0;
  _yargenRule = '';
  _quickRule  = '';

  const fd = new FormData();
  fd.append('file', file);
  try {
    const r  = await apiFetch('/api/hasher/hash', { method: 'POST', body: fd });
    _fileData = await r.json();
  } catch(e) {
    toast('Hash error: ' + e.message);
    return;
  }

  // Pre-select top 10 strings by score
  const scored = [..._fileData.strings].sort((a,b) => scoreStr(b) - scoreStr(a));
  _selStrings  = new Set(scored.slice(0, 10));

  renderHashResults();
  startYargen();
}

function scoreStr(s) {
  return s.length * 0.6 + new Set(s).size * 0.3 + (/[^a-zA-Z0-9 ]/.test(s) ? 10 : 0);
}

// ── Render full results panel ─────────────────────────────────────
function renderHashResults() {
  const d = _fileData;
  $('hasher-drop-view').style.display    = 'none';
  $('hasher-results-view').style.display = 'flex';
  $('btn-hasher-reset').style.display    = '';

  $('hasher-results-body').innerHTML = `
    <div class="section-label">File info &amp; hashes</div>
    <div class="card">
      <div class="card-header">
        <span style="font-size:13px;font-weight:500">${escHtml(d.name)}</span>
        <span style="font-size:11px;color:var(--hint)">${formatSize(d.size)}</span>
      </div>
      <div class="hash-grid">
        <div class="hash-row"><div class="hash-label">Type</div><div class="hash-value" style="color:var(--muted)">${escHtml(d.magic.label)}</div><div></div></div>
        <div class="hash-row"><div class="hash-label">Magic</div><div class="hash-value" style="font-size:10px">${escHtml(d.magic.hex.substring(0,48))}</div><div></div></div>
        ${['MD5','SHA1','SHA256','SHA512'].map(algo => {
          const key = algo.toLowerCase();
          const val = algo === 'SHA512' ? d[key].substring(0,40)+'…' : d[key];
          return `<div class="hash-row">
            <div class="hash-label">${algo}</div>
            <div class="hash-value">${escHtml(val)}</div>
            <button class="copy-btn" onclick="navigator.clipboard.writeText('${d[key]}').then(()=>toast('${algo} copied.'))">copy</button>
          </div>`;
        }).join('')}
      </div>
    </div>

    <!-- ── Strings panel ── -->
    <div class="section-label">
      Extracted strings
      <span style="font-weight:400;text-transform:none;letter-spacing:0;font-size:10px;color:var(--hint)">
        &nbsp;${d.strings.length} found · top 10 pre-selected
      </span>
    </div>
    <div class="card">
      <div class="card-header">
        <span class="card-title">Strings</span>
        <span style="font-size:10px;padding:2px 7px;background:var(--bg);border:1px solid var(--border);border-radius:10px;color:var(--hint)" id="str-sel-count">${_selStrings.size} selected</span>
        <button class="btn" style="font-size:11px;margin-left:8px" onclick="selectTopStr(15)">Top 15</button>
        <button class="btn" style="font-size:11px"                  onclick="selectTopStr(0)">None</button>
      </div>
      <div class="strings-body" id="strings-list"></div>
    </div>

    <!-- ── Quick rule panel ── -->
    <div class="section-label">Quick rule (instant, hand-picked strings)</div>
    <div style="display:flex;gap:6px;align-items:center;margin-bottom:8px;flex-wrap:wrap">
      <button class="mode-tab active" id="qmode-hash"    onclick="setQuickMode('hash')">Hash match</button>
      <button class="mode-tab"        id="qmode-strings" onclick="setQuickMode('strings')">String match</button>
      <button class="mode-tab"        id="qmode-or"      onclick="setQuickMode('or')">Hash OR strings</button>
      <div style="margin-left:auto;display:flex;align-items:center;gap:8px">
        <span style="font-size:11px;color:var(--muted)">Size tolerance</span>
        <input type="range" id="size-tol" min="0" max="50" step="5" value="0"
               style="width:80px;accent-color:var(--accent)" oninput="updateSizeTol(this.value)"/>
        <span style="font-family:var(--font-mono);font-size:11px;min-width:36px" id="tol-label">exact</span>
      </div>
    </div>
    <div class="card">
      <div class="card-header">
        <span class="card-title">Quick rule — editable</span>
        <div style="display:flex;gap:6px">
          <button class="btn" onclick="navigator.clipboard.writeText($('quick-rule-preview').textContent).then(()=>toast('Rule copied.'))">Copy</button>
          <button class="btn primary" onclick="addQuickRuleToLib()">Add to YARA lib</button>
        </div>
      </div>
      <div class="yara-preview" id="quick-rule-preview" contenteditable="true" spellcheck="false"></div>
    </div>

    <!-- ── yarGen panel ── -->
    <div class="section-label">yarGen rule (goodware-filtered, deeper analysis)</div>
    <div class="terminal visible" id="yargen-run-terminal" style="max-height:180px"></div>
    <div id="yargen-rule-section" style="display:none;flex-direction:column;gap:10px">
      <div class="card">
        <div class="card-header">
          <span class="card-title">yarGen rule — editable</span>
          <div style="display:flex;gap:6px">
            <button class="btn" onclick="navigator.clipboard.writeText($('yargen-rule-preview').textContent).then(()=>toast('Rule copied.'))">Copy</button>
            <button class="btn primary" onclick="addYargenRuleToLib()">Add to YARA lib</button>
          </div>
        </div>
        <div class="yara-preview" id="yargen-rule-preview" contenteditable="true" spellcheck="false"></div>
      </div>
    </div>
  `;

  renderStringsList();
  fetchQuickRule();
}

// ── Strings panel ─────────────────────────────────────────────────
function renderStringsList() {
  const scored = [..._fileData.strings].sort((a,b) => scoreStr(b) - scoreStr(a));
  $('strings-list').innerHTML = scored.map((s,i) => `
    <div class="string-item" onclick="toggleStr(${i})">
      <input type="checkbox" class="string-check" ${_selStrings.has(s)?'checked':''} onchange="toggleStr(${i})" onclick="event.stopPropagation()"/>
      <span class="string-val">${escHtml(s)}</span>
      <span class="string-len">${s.length}c</span>
    </div>`).join('');
  updateSelCount();
}

function toggleStr(i) {
  const scored = [..._fileData.strings].sort((a,b) => scoreStr(b) - scoreStr(a));
  const s = scored[i];
  if (_selStrings.has(s)) _selStrings.delete(s); else _selStrings.add(s);
  updateSelCount();
  const checks = document.querySelectorAll('.string-check');
  if (checks[i]) checks[i].checked = _selStrings.has(s);
  fetchQuickRule();
}

function selectTopStr(n) {
  const scored = [..._fileData.strings].sort((a,b) => scoreStr(b) - scoreStr(a));
  _selStrings  = new Set(scored.slice(0, n));
  renderStringsList();
  fetchQuickRule();
}

function updateSelCount() {
  const el = $('str-sel-count');
  if (el) el.textContent = _selStrings.size + ' selected';
}

// ── Quick rule generation ─────────────────────────────────────────
function setQuickMode(mode) {
  _quickMode = mode;
  ['hash','strings','or'].forEach(m => {
    const el = $('qmode-' + m);
    if (el) el.classList.toggle('active', m === mode);
  });
  fetchQuickRule();
}

function updateSizeTol(val) {
  _sizeTolPct = parseInt(val);
  const el = $('tol-label');
  if (el) el.textContent = _sizeTolPct === 0 ? 'exact' : '±' + _sizeTolPct + '%';
  fetchQuickRule();
}

async function fetchQuickRule() {
  if (!_fileData) return;
  const payload = {
    name:          _fileData.name,
    sha256:        _fileData.sha256,
    md5:           _fileData.md5,
    size:          _fileData.size,
    magic_label:   _fileData.magic.label,
    mode:          _quickMode,
    tolerance_pct: _sizeTolPct,
    strings:       [..._selStrings],
  };
  try {
    const r    = await apiFetch('/api/hasher/quick-rule', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(payload),
    });
    const data = await r.json();
    _quickRule = data.rule;
    const el = $('quick-rule-preview');
    if (el) el.textContent = data.rule;
  } catch(e) { console.warn('Quick rule error:', e); }
}

async function addQuickRuleToLib() {
  const preview  = $('quick-rule-preview');
  const ruleText = preview ? preview.textContent : _quickRule;
  if (!ruleText) { toast('No rule to add.'); return; }
  const match = ruleText.match(/rule\s+(\w+)/);
  const name  = match ? match[1] : (_fileData?.name?.replace(/[^a-zA-Z0-9_]/g,'_') || 'quick_rule');
  try {
    await apiFetch('/api/yara/rules', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ name, tag: 'quick-rule', sev: 'med', body: ruleText }),
    });
    await loadRules();
    toast('Quick rule added to YARA library.');
    document.querySelector('[data-mod="yara"]').click();
  } catch(e) { toast('Error: ' + e.message); }
}

// ── yarGen orchestration ──────────────────────────────────────────
async function startYargen() {
  try {
    const r    = await apiFetch('/api/hasher/setup-status');
    const data = await r.json();
    updateSetupIndicator(data.state);

    if (data.state === 'running') {
      $('hasher-setup-status-box').style.display = '';
      _setupLogIndex = 0;
      appendSetupLines(data.log);
      _setupLogIndex = data.log_total;
      pollSetupUntilReady();
    } else if (data.state === 'ready') {
      runYargen();
    } else if (data.state === 'failed') {
      const term = $('yargen-run-terminal');
      if (term) appendTermLine(term, 'error', '[!] yarGen setup failed. Check server logs and restart the app.');
    } else {
      setTimeout(startYargen, 1500);
    }
  } catch(e) { console.warn('Setup status check failed:', e); }
}

function pollSetupUntilReady() {
  if (_setupPoller) clearInterval(_setupPoller);
  _setupPoller = setInterval(async () => {
    try {
      const r    = await apiFetch(`/api/hasher/setup-status?since=${_setupLogIndex}`);
      const data = await r.json();
      appendSetupLines(data.log);
      _setupLogIndex = data.log_total;
      updateSetupIndicator(data.state);
      if (data.state === 'ready') {
        clearInterval(_setupPoller);
        $('hasher-setup-status-box').style.display = 'none';
        runYargen();
      } else if (data.state === 'failed') {
        clearInterval(_setupPoller);
        const term = $('yargen-run-terminal');
        if (term) appendTermLine(term, 'error', '[!] yarGen setup failed. Check server logs and restart the app.');
      }
    } catch(e) {}
  }, 1500);
}

function appendSetupLines(lines) {
  const term = $('setup-terminal');
  if (!term) return;
  lines.forEach(({cls, text}) => appendTermLine(term, cls, text));
}

function updateSetupIndicator(state) {
  const spinner = $('yargen-spinner');
  const label   = $('yargen-setup-label');
  if (!label) return;
  if (state === 'running') {
    if (spinner) spinner.style.display = '';
    label.textContent = 'Setting up yarGen...';
    label.style.color = 'var(--muted)';
  } else if (state === 'ready') {
    if (spinner) spinner.style.display = 'none';
    label.textContent = 'yarGen ready';
    label.style.color = 'var(--accent)';
  } else if (state === 'failed') {
    if (spinner) spinner.style.display = 'none';
    label.textContent = 'yarGen setup failed';
    label.style.color = 'var(--danger)';
  } else {
    if (spinner) spinner.style.display = '';
    label.textContent = 'Checking yarGen...';
  }
}

async function runYargen() {
  if (!_hasherFile) return;
  const term = $('yargen-run-terminal');
  if (!term) return;

  const fd = new FormData();
  fd.append('file', _hasherFile);

  try {
    const resp = await fetch('/api/hasher/yargen/run', { method: 'POST', body: fd });
    if (!resp.ok) {
      const err = await resp.json().catch(() => ({error: resp.statusText}));
      appendTermLine(term, 'error', '[!] ' + (err.error || resp.statusText));
      return;
    }

    const reader  = resp.body.getReader();
    const decoder = new TextDecoder();
    let buf = '';

    async function read() {
      const { done, value } = await reader.read();
      if (done) return;
      buf += decoder.decode(value, { stream: true });
      const events = buf.split('\n\n');
      buf = events.pop();
      events.forEach(ev => {
        const line = ev.replace(/^data: /, '');
        if (!line) return;
        try {
          const { cls, text } = JSON.parse(line);
          if (cls === 'rule') {
            _yargenRule = text;
            const section = $('yargen-rule-section');
            const preview = $('yargen-rule-preview');
            if (section) section.style.display = 'flex';
            if (preview) preview.textContent = text;
          } else {
            appendTermLine(term, cls, text);
          }
        } catch(e) {}
      });
      read();
    }
    read();
  } catch(e) {
    appendTermLine(term, 'error', '[!] Request failed: ' + e.message);
  }
}

async function addYargenRuleToLib() {
  const preview  = $('yargen-rule-preview');
  const ruleText = preview ? preview.textContent : _yargenRule;
  if (!ruleText) { toast('No yarGen rule ready yet.'); return; }
  const match = ruleText.match(/rule\s+(\w+)/);
  const name  = match ? match[1] : (_fileData?.name?.replace(/[^a-zA-Z0-9_]/g,'_') || 'yargen_rule');
  try {
    await apiFetch('/api/yara/rules', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ name, tag: 'yargen', sev: 'med', body: ruleText }),
    });
    await loadRules();
    toast('yarGen rule added to YARA library.');
    document.querySelector('[data-mod="yara"]').click();
  } catch(e) { toast('Error: ' + e.message); }
}

$('btn-hasher-reset').onclick = () => {
  _fileData = null; _hasherFile = null; _yargenRule = ''; _quickRule = '';
  _selStrings = new Set(); _quickMode = 'hash'; _sizeTolPct = 0;
  if (_setupPoller) { clearInterval(_setupPoller); _setupPoller = null; }
  $('hasher-results-view').style.display     = 'none';
  $('hasher-drop-view').style.display        = 'flex';
  $('hasher-setup-status-box').style.display = 'none';
  $('btn-hasher-reset').style.display        = 'none';
  const label = $('yargen-setup-label');
  if (label) label.textContent = '';
  const spinner = $('yargen-spinner');
  if (spinner) spinner.style.display = 'none';
  $('hasher-file-input').value = '';
};

// Poll setup status on page load so the header indicator is always accurate
(async () => {
  try {
    const r    = await apiFetch('/api/hasher/setup-status');
    const data = await r.json();
    updateSetupIndicator(data.state);
    if (data.state === 'running') {
      _setupPoller = setInterval(async () => {
        try {
          const r2 = await apiFetch('/api/hasher/setup-status');
          const d2 = await r2.json();
          updateSetupIndicator(d2.state);
          if (d2.state !== 'running') { clearInterval(_setupPoller); _setupPoller = null; }
        } catch(e) {}
      }, 2000);
    }
  } catch(e) {}
})();


// ═══════════════════════════════════════════════════════════════════
// ARTIFACT PARSER MODULE
// ═══════════════════════════════════════════════════════════════════
let _artifactTools = [];
let _toolStates = {};

async function loadArtifactTools() {
  try {
    const r = await apiFetch('/api/artifact/tools');
    _artifactTools = await r.json();
    _artifactTools.forEach(t => { _toolStates[t.id] = t.default_on; });
    renderToolGrid();
  } catch(e) { console.error('Failed to load tools:', e); }
}

function renderToolGrid() {
  const enabled = _artifactTools.filter(t => _toolStates[t.id]).length;
  $('tool-count-label').textContent = `${enabled} of ${_artifactTools.length} enabled`;
  $('tool-grid').innerHTML = _artifactTools.map(t => `
    <div class="tool-card ${_toolStates[t.id]?'enabled':''}" onclick="toggleArtifactTool('${t.id}')">
      <div class="tool-card-header">
        <input type="checkbox" class="tool-toggle" ${_toolStates[t.id]?'checked':''} onclick="event.stopPropagation();toggleArtifactTool('${t.id}')"/>
        <span class="tool-name">${t.name}</span>
      </div>
      <div class="tool-desc">${t.desc}</div>
      <div class="tool-artifacts">${t.artifacts}</div>
    </div>`).join('');
  updateScriptPreview();
}

function toggleArtifactTool(id) {
  _toolStates[id] = !_toolStates[id];
  renderToolGrid();
}

function selectAllArtifactTools(val) {
  _artifactTools.forEach(t => _toolStates[t.id] = val);
  renderToolGrid();
}

$('btn-check-tools').onclick = async () => {
  const toolsDir = $('inp-tools').value.trim();
  if (!toolsDir) { toast('Enter a tools directory first.'); return; }
  try {
    const r = await apiFetch('/api/artifact/check-tools', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ tools_dir: toolsDir }),
    });
    const results = await r.json();
    let found = 0, missing = 0;
    _artifactTools.forEach(t => {
      const res = results[t.id];
      const card = $('tool-grid').children[_artifactTools.indexOf(t)];
      if (card) {
        if (res && res.found) { card.classList.remove('missing'); found++; }
        else { card.classList.add('missing'); missing++; }
      }
    });
    toast(`Tools check: ${found} found, ${missing} missing.`);
  } catch(e) { toast('Check failed: ' + e.message); }
};

$('btn-gen-script').onclick = async () => {
  const enabled = _artifactTools.filter(t => _toolStates[t.id]).map(t => t.id);
  if (!enabled.length) { toast('Enable at least one tool.'); return; }
  const payload = {
    collection_path: $('inp-collection').value.trim() || 'C:\\Cases\\Collection',
    output_path:     $('inp-output').value.trim()     || 'C:\\Cases\\Parsed',
    tools_dir:       $('inp-tools').value.trim()      || 'C:\\Tools\\ZimmermanTools',
    enabled_tools:   enabled,
  };
  try {
    const r = await apiFetch('/api/artifact/generate-script', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify(payload),
    });
    const blob = await r.blob();
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'parse_artifacts.ps1';
    a.click();
    toast('Script downloaded.');
  } catch(e) { toast('Error: ' + e.message); }
};

$('btn-copy-script').onclick = () => {
  const txt = $('script-preview').textContent;
  navigator.clipboard.writeText(txt).then(() => toast('Script copied.'));
};

async function updateScriptPreview() {
  const enabled = _artifactTools.filter(t => _toolStates[t.id]).map(t => t.id);
  if (!enabled.length) { $('script-preview').textContent = '# No tools enabled.'; return; }
  const payload = {
    collection_path: $('inp-collection').value.trim() || 'C:\\Cases\\Collection',
    output_path:     $('inp-output').value.trim()     || 'C:\\Cases\\Parsed',
    tools_dir:       $('inp-tools').value.trim()      || 'C:\\Tools\\ZimmermanTools',
    enabled_tools:   enabled,
  };
  try {
    const r = await apiFetch('/api/artifact/generate-script', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify(payload),
    });
    $('script-preview').textContent = await r.text();
  } catch(e) { $('script-preview').textContent = '# Error generating script: ' + e.message; }
}

['inp-collection','inp-output','inp-tools'].forEach(id => {
  $(id).addEventListener('input', updateScriptPreview);
});

// ═══════════════════════════════════════════════════════════════════
// UAL MODULE
// ═══════════════════════════════════════════════════════════════════
let _ualData = {};       // { operation: { count, columns, rows, total } }
let _ualFile = null;     // keep the raw File for export
let _ualCurrentOp = '';
let _ualSortCol = '', _ualSortDir = 1;

// Upload
const udz = $('ual-dropzone');
udz.ondragover = e => { e.preventDefault(); udz.classList.add('drag'); };
udz.ondragleave = () => udz.classList.remove('drag');
udz.ondrop = e => { e.preventDefault(); udz.classList.remove('drag'); handleUALFile(e.dataTransfer.files[0]); };
$('ual-file-input').onchange = e => handleUALFile(e.target.files[0]);

async function handleUALFile(file) {
  if (!file) return;
  if (!file.name.toLowerCase().endsWith('.csv')) { toast('Please select a .csv file.'); return; }
  _ualFile = file;
  const fd = new FormData();
  fd.append('file', file);
  try {
    const r = await apiFetch('/api/ual/parse', { method:'POST', body:fd });
    const data = await r.json();
    _ualData = data.operations;
    const ops = Object.keys(_ualData);
    _ualCurrentOp = ops[0] || '';
    const totalRows = ops.reduce((s,op) => s + _ualData[op].total, 0);
    $('ual-upload-view').style.display = 'none';
    $('ual-data-view').style.display = 'flex';
    $('btn-ual-export').style.display = '';
    $('btn-ual-reset').style.display = '';
    $('ual-stats').innerHTML = `
      <div class="stat-card"><div class="stat-label">Total rows</div><div class="stat-val">${totalRows.toLocaleString()}</div></div>
      <div class="stat-card"><div class="stat-label">Operations</div><div class="stat-val">${ops.length}</div></div>
      <div class="stat-card"><div class="stat-label">Parse errors</div><div class="stat-val" style="color:${data.errors>0?'var(--danger)':'inherit'}">${data.errors}</div></div>`;
    renderUALTabs();
    renderUALTable();
    if (data.errors > 0) toast(`Parsed with ${data.errors} row error(s).`);
  } catch(e) { toast('Parse error: ' + e.message); }
}

function renderUALTabs() {
  $('ual-tabs').innerHTML = Object.keys(_ualData).map(op =>
    `<div class="tab ${op===_ualCurrentOp?'active':''}" onclick="switchUALOp('${escHtml(op)}')">
      ${escHtml(op)}<span class="tab-badge">${_ualData[op].total.toLocaleString()}</span>
    </div>`).join('');
}

function switchUALOp(op) {
  _ualCurrentOp = op; _ualSortCol = ''; _ualSortDir = 1;
  $('ual-search').value = '';
  renderUALTabs(); renderUALTable();
}

const UAL_PRIORITY = ['CreationDate','Operation','UserId','UserIds','ClientIP','ClientIPAddress','Workload','ResultStatus','ObjectId','UserAgent','RecordType','RecordId'];

function renderUALTable() {
  const opData = _ualData[_ualCurrentOp];
  if (!opData) return;
  const allKeys = new Set();
  opData.rows.forEach(r => Object.keys(r).forEach(k => allKeys.add(k)));
  const cols = [
    ...UAL_PRIORITY.filter(c => allKeys.has(c)),
    ...[...allKeys].filter(c => !UAL_PRIORITY.includes(c)).sort()
  ];

  const sel = $('ual-col-filter');
  const prev = sel.value;
  sel.innerHTML = '<option value="">All columns</option>' +
    cols.map(c => `<option value="${escHtml(c)}" ${c===prev?'selected':''}>${escHtml(c)}</option>`).join('');

  $('ual-hint').textContent = `${cols.length} columns · ${opData.total > 500 ? `showing first 500 of ${opData.total.toLocaleString()} rows (server-side export gets all)` : opData.total+' rows'} · click headers to sort`;
  renderUALBody(cols);
}

function renderUALBody(cols) {
  const opData = _ualData[_ualCurrentOp];
  if (!opData) return;
  let rows = [...opData.rows];
  const q = $('ual-search').value.toLowerCase().trim();
  const col = $('ual-col-filter').value;
  if (q) rows = rows.filter(r => col ? String(r[col]||'').toLowerCase().includes(q) : Object.values(r).some(v => String(v||'').toLowerCase().includes(q)));
  if (_ualSortCol) rows.sort((a,b) => String(a[_ualSortCol]||'').localeCompare(String(b[_ualSortCol]||''),undefined,{numeric:true}) * _ualSortDir);

  $('ual-count').textContent = rows.length.toLocaleString() + ' rows';
  $('ual-thead').innerHTML = '<tr>' + cols.map(c =>
    `<th class="${_ualSortCol===c?'sorted':''}" onclick="ualSort('${c.replace(/'/g,"\\'")}')">
      ${escHtml(c)}<span class="sort-arrow">${_ualSortCol===c?(_ualSortDir===1?'▲':'▼'):'⇅'}</span>
    </th>`).join('') + '</tr>';
  $('ual-tbody').innerHTML = rows.slice(0,500).map(r =>
    '<tr>' + cols.map(c => { const v = escHtml(String(r[c]||'')); return `<td title="${v}">${v}</td>`; }).join('') + '</tr>'
  ).join('');

  // Store cols for sort re-render
  $('ual-tbody').dataset.cols = JSON.stringify(cols);
}

function ualSort(col) {
  if (_ualSortCol===col) _ualSortDir*=-1; else { _ualSortCol=col; _ualSortDir=1; }
  const cols = JSON.parse($('ual-tbody').dataset.cols || '[]');
  renderUALBody(cols);
}

$('ual-search').oninput = () => { const cols = JSON.parse($('ual-tbody').dataset.cols||'[]'); renderUALBody(cols); };
$('ual-col-filter').onchange = () => { const cols = JSON.parse($('ual-tbody').dataset.cols||'[]'); renderUALBody(cols); };

$('btn-ual-reset').onclick = () => {
  _ualData = {}; _ualFile = null; _ualCurrentOp = ''; _ualSortCol = ''; _ualSortDir = 1;
  $('ual-data-view').style.display = 'none';
  $('ual-upload-view').style.display = 'flex';
  $('btn-ual-export').style.display = 'none';
  $('btn-ual-reset').style.display = 'none';
  $('ual-file-input').value = '';
};

// Export
let _exportFmt = 'xlsx';
let _exportSelected = {};

$('btn-ual-export').onclick = () => {
  const ops = Object.keys(_ualData);
  _exportSelected = {};
  ops.forEach(op => _exportSelected[op] = true);
  renderExportOpList();
  openModal('export-modal');
};
$('export-modal-close').onclick = $('export-cancel').onclick = () => closeModal('export-modal');
$('export-modal').onclick = e => { if (e.target===$('export-modal')) closeModal('export-modal'); };

function setExportFmt(fmt) {
  _exportFmt = fmt;
  $('fmt-xlsx').classList.toggle('active', fmt==='xlsx');
  $('fmt-csv').classList.toggle('active',  fmt==='csv');
}

function renderExportOpList() {
  const ops = Object.keys(_ualData);
  const checked = ops.filter(op => _exportSelected[op]).length;
  $('export-sel-count').textContent = `${checked} of ${ops.length} selected`;
  const total = ops.filter(op => _exportSelected[op]).reduce((s,op) => s + _ualData[op].total, 0);
  $('export-row-count').textContent = total.toLocaleString() + ' rows';
  $('export-op-list').innerHTML = ops.map(op => `
    <div class="op-row" onclick="toggleExportOp('${escHtml(op)}')">
      <input type="checkbox" ${_exportSelected[op]?'checked':''} onclick="event.stopPropagation();toggleExportOp('${escHtml(op)}')"/>
      <span class="op-row-name">${escHtml(op)}</span>
      <span class="op-row-count">${_ualData[op].total.toLocaleString()}</span>
    </div>`).join('');
}

function toggleExportOp(op) {
  _exportSelected[op] = !_exportSelected[op];
  renderExportOpList();
}

function selectAllExportOps(val) {
  Object.keys(_exportSelected).forEach(op => _exportSelected[op] = val);
  renderExportOpList();
}

$('export-confirm').onclick = async () => {
  if (!_ualFile) { toast('No file loaded.'); return; }
  const ops = Object.keys(_exportSelected).filter(op => _exportSelected[op]);
  if (!ops.length) { toast('Select at least one operation.'); return; }

  const fd = new FormData();
  fd.append('file', _ualFile);
  fd.append('format', _exportFmt);
  fd.append('operations', JSON.stringify(ops));

  try {
    $('export-confirm').disabled = true;
    $('export-confirm').textContent = 'Exporting...';
    const r = await apiFetch('/api/ual/export', { method:'POST', body:fd });
    const blob = await r.blob();
    const cd = r.headers.get('Content-Disposition') || '';
    const fname = cd.match(/filename=([^;]+)/)?.[1] || ('UAL_Export.' + _exportFmt);
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = fname;
    a.click();
    closeModal('export-modal');
    toast('Export downloaded.');
  } catch(e) { toast('Export failed: ' + e.message); }
  finally {
    $('export-confirm').disabled = false;
    $('export-confirm').textContent = 'Download';
  }
};

// ── Modal helpers ─────────────────────────────────────────────────────────────
function openModal(id)  { $(id).classList.add('open'); }
function closeModal(id) { $(id).classList.remove('open'); }

// ═══════════════════════════════════════════════════════════════════
// YARA FORGE UPDATE SYSTEM
// ═══════════════════════════════════════════════════════════════════
let _forgeReleaseData = null;

const FORGE_PKG_INFO = {
  core:     { label: "Core",     desc: "~5k rules · high accuracy · low false positives · best for IR work" },
  extended: { label: "Extended", desc: "~10k rules · broader coverage · some additional false positive risk" },
  full:     { label: "Full",     desc: "~12k rules · everything available · use with caution" },
};

async function checkForgeUpdates() {
  const btn  = $('btn-forge-check');
  const area = $('forge-status-area');
  const term = $('forge-terminal');

  btn.disabled    = true;
  btn.textContent = 'Checking...';
  area.style.display = 'none';
  term.style.display = 'none';

  try {
    const r    = await apiFetch('/api/yara/forge/status');
    const data = await r.json();

    if (data.error) {
      toast('YARA Forge: ' + data.error);
      btn.disabled = false;
      btn.textContent = 'Check for updates';
      return;
    }

    _forgeReleaseData = data;

    // Warn if any package has no download URL — show what assets ARE available
    const missing = Object.entries(data.packages).filter(([,p]) => !p.download_url);
    if (missing.length && data.all_assets) {
      console.warn('YARA Forge: no URL for', missing.map(([k])=>k), '| Available assets:', data.all_assets);
      term.innerHTML = '';
      appendTermLine(term, 'warn', `[~] Available assets in this release:`);
      data.all_assets.forEach(a => appendTermLine(term, 'info', `    ${a}`));
      term.style.display = 'block';
    }

    renderForgeStatus(data);
    area.style.display = 'flex';
    area.style.flexDirection = 'column';
  } catch(e) {
    toast('Could not reach GitHub: ' + e.message);
  } finally {
    btn.disabled    = false;
    btn.textContent = 'Refresh';
  }
}

function renderForgeStatus(data) {
  const area = $('forge-status-area');

  // Release header
  const relDate = data.latest_date || '';
  const counts  = data.release_notes || {};

  area.innerHTML = `
    <div style="padding:8px 14px;background:var(--bg);border-bottom:1px solid var(--border);font-size:11px;color:var(--muted);display:flex;align-items:center;justify-content:space-between">
      <span>Latest release: <strong style="color:var(--text)">${data.latest_tag}</strong> &nbsp;·&nbsp; ${relDate}</span>
      <a href="${escHtml(data.release_url)}" target="_blank" rel="noopener" style="color:var(--accent);font-size:11px;text-decoration:none">View on GitHub ↗</a>
    </div>
    ${Object.entries(data.packages).map(([pkg, info]) => renderForgePkgCard(pkg, info, counts[pkg])).join('')}
  `;
}

function renderForgePkgCard(pkg, info, releaseCount) {
  const pkgInfo    = FORGE_PKG_INFO[pkg] || {};
  const installed  = info.installed;
  const latest     = info.available;
  const needsUpdate = info.update_ready;
  const ruleCount  = info.rule_count;

  let badge = '';
  let actionBtn = '';

  if (!installed) {
    badge     = `<span class="forge-badge not-installed">Not installed</span>`;
    actionBtn = `<button class="btn primary" style="font-size:11px;padding:4px 11px" onclick="installForge('${pkg}')">Install</button>`;
  } else if (needsUpdate) {
    badge     = `<span class="forge-badge update">Update available</span>`;
    actionBtn = `<button class="btn primary" style="font-size:11px;padding:4px 11px" onclick="installForge('${pkg}')">Update</button>`;
  } else {
    badge     = `<span class="forge-badge up-to-date">✓ Up to date</span>`;
    actionBtn = `<button class="btn" style="font-size:11px;padding:4px 11px" onclick="installForge('${pkg}')">Re-install</button>`;
  }

  const installedLine = installed
    ? `Installed: ${installed}${ruleCount ? ` &nbsp;·&nbsp; ${ruleCount.toLocaleString()} rules` : ''}`
    : 'Not installed';

  const savedPath = info.saved_path
    ? `<div style="font-size:10px;color:var(--hint);margin-top:2px;font-family:var(--font-mono)">${escHtml(info.saved_path)}</div>`
    : '';

  const releaseLine = releaseCount
    ? `${releaseCount.toLocaleString()} rules in latest release`
    : `Latest: ${latest}`;

  return `
    <div class="forge-pkg-card">
      <div>
        <div class="forge-pkg-name">${pkgInfo.label || pkg}</div>
        ${badge}
      </div>
      <div class="forge-pkg-desc">${pkgInfo.desc || ''}</div>
      <div class="forge-pkg-meta">
        <div style="margin-bottom:4px">${releaseLine}</div>
        <div style="color:var(--hint);font-size:10px">${installedLine}</div>
        ${savedPath}
      </div>
      ${actionBtn}
    </div>`;
}

async function installForge(pkg) {
  if (!_forgeReleaseData) {
    toast('Check for updates first.');
    return;
  }
  const pkgData     = _forgeReleaseData.packages[pkg];
  const downloadUrl = pkgData?.download_url;
  if (!downloadUrl) {
    const available = _forgeReleaseData.all_assets || [];
    const msg = available.length
      ? `No ${pkg} asset found. Available assets:\n${available.join('\n')}`
      : `No download URL found for ${pkg}. Check the terminal for available assets.`;
    const term = $('forge-terminal');
    if (term) {
      term.innerHTML = '';
      term.style.display = 'block';
      appendTermLine(term, 'error', `[!] Could not find a ${pkg} package asset in this release.`);
      appendTermLine(term, 'info',  `[*] Assets in this release:`);
      available.forEach(a => appendTermLine(term, 'info', `    ${a}`));
      appendTermLine(term, 'info',  `[*] Please file an issue or check back after the next weekly release.`);
    }
    toast(msg.split('\n')[0]);
    return;
  }

  const term = $('forge-terminal');
  term.innerHTML  = '';
  term.style.display = 'block';

  // Disable all install buttons during download
  document.querySelectorAll('.forge-pkg-card button').forEach(b => b.disabled = true);

  try {
    const resp = await fetch('/api/yara/forge/update', {
      method:  'POST',
      headers: {'Content-Type': 'application/json'},
      body:    JSON.stringify({ package: pkg, download_url: downloadUrl }),
    });

    if (!resp.ok) {
      const err = await resp.json().catch(() => ({error: resp.statusText}));
      appendTermLine(term, 'error', '[!] ' + (err.error || resp.statusText));
      return;
    }

    const reader  = resp.body.getReader();
    const decoder = new TextDecoder();
    let buf = '';

    async function read() {
      const { done, value } = await reader.read();
      if (done) {
        document.querySelectorAll('.forge-pkg-card button').forEach(b => b.disabled = false);
        return;
      }
      buf += decoder.decode(value, { stream: true });
      const events = buf.split('\n\n');
      buf = events.pop();
      events.forEach(ev => {
        const line = ev.replace(/^data: /, '');
        if (!line) return;
        try {
          const msg = JSON.parse(line);
          if (msg.cls === 'complete') {
            // Reload rules and refresh the forge status
            loadRules();
            checkForgeUpdates();
          } else {
            appendTermLine(term, msg.cls, msg.text);
          }
        } catch(e) {}
      });
      read();
    }
    read();
  } catch(e) {
    appendTermLine(term, 'error', '[!] Request failed: ' + e.message);
    document.querySelectorAll('.forge-pkg-card button').forEach(b => b.disabled = false);
  }
}

// ── Init ──────────────────────────────────────────────────────────────────────
loadRules();
loadArtifactTools();
