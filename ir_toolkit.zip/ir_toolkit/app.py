"""
IR Toolkit — Flask backend
Run: python app.py
Then open: http://localhost:5000
"""

from flask import Flask, render_template, request, jsonify, send_file
import os, sys

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 500 * 1024 * 1024  # 500 MB upload limit

# ── Route: main UI ──────────────────────────────────────────────────────────
@app.route("/")
def index():
    return render_template("index.html")

# ── Register module blueprints ──────────────────────────────────────────────
from modules.yara_module   import yara_bp
from modules.hasher_module import hasher_bp
from modules.ual_module    import ual_bp
from modules.artifact_module import artifact_bp

app.register_blueprint(yara_bp,     url_prefix="/api/yara")
app.register_blueprint(hasher_bp,   url_prefix="/api/hasher")
app.register_blueprint(ual_bp,      url_prefix="/api/ual")
app.register_blueprint(artifact_bp, url_prefix="/api/artifact")

# ── Health check ────────────────────────────────────────────────────────────
@app.route("/api/health")
def health():
    return jsonify({"status": "ok", "version": "1.0.0"})

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))

    # Warn if yara-python is missing key modules
    try:
        import yara
        _key_modules = {"pe", "elf", "math", "hash"}
        _missing = []
        for mod in _key_modules:
            probe = f'import "{mod}"\nrule probe{{condition: true}}'
            try:
                yara.compile(source=probe)
            except Exception:
                _missing.append(mod)
        if _missing:
            print(f"\n  ⚠  WARNING: yara-python is missing modules: {', '.join(sorted(_missing))}")
            print(f"     Rules using these modules will be skipped during scans.")
            print(f"     Run  python setup.py  to attempt a fix.\n")
        else:
            print(f"\n  ✓  yara-python modules OK: pe, elf, math, hash and more available\n")
    except ImportError:
        print("\n  ⚠  WARNING: yara-python not installed. Run python setup.py\n")

    print(f"  IR Toolkit running at http://localhost:{port}\n")
    app.run(host="127.0.0.1", port=port, debug=False)
