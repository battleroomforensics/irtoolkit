"""
UAL Module — M365 Unified Audit Log Parser
Ports your original Python script to a Flask endpoint.
- Parses CSV with AuditData JSON column
- Flattens nested JSON
- Groups by Operation
- Exports to XLSX (one sheet per operation) or CSV
"""

import csv, json, io, re
from datetime import datetime
from flask import Blueprint, request, jsonify, send_file, Response
import pandas as pd

ual_bp = Blueprint("ual", __name__)

# ── Parse ─────────────────────────────────────────────────────────────────────
@ual_bp.route("/parse", methods=["POST"])
def parse():
    if "file" not in request.files:
        return jsonify({"error": "no file uploaded"}), 400

    f = request.files["file"]
    if not f.filename.lower().endswith(".csv"):
        return jsonify({"error": "expected a .csv file"}), 400

    try:
        content = f.read().decode("utf-8-sig", errors="replace")
        rows_by_op, parsed, errors = _parse_ual_csv(content)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    # Build summary for the frontend
    summary = {
        "parsed": parsed,
        "errors": errors,
        "operations": {
            op: {
                "count": len(rows),
                "columns": list(rows[0].keys()) if rows else [],
                # Send first 500 rows per operation to keep response manageable
                "rows": rows[:500],
                "total": len(rows),
            }
            for op, rows in rows_by_op.items()
        }
    }
    return jsonify(summary)

# ── Export ─────────────────────────────────────────────────────────────────────
@ual_bp.route("/export", methods=["POST"])
def export():
    """
    POST body:
      file        — the original UAL CSV (multipart)
      format      — 'xlsx' or 'csv'
      operations  — JSON list of operation names to include (all if omitted)
    """
    if "file" not in request.files:
        return jsonify({"error": "no file uploaded"}), 400

    f       = request.files["file"]
    fmt     = request.form.get("format", "xlsx")
    ops_raw = request.form.get("operations", "")
    wanted_ops = json.loads(ops_raw) if ops_raw else None

    content = f.read().decode("utf-8-sig", errors="replace")
    rows_by_op, _, _ = _parse_ual_csv(content)

    if wanted_ops:
        rows_by_op = {op: rows for op, rows in rows_by_op.items() if op in wanted_ops}

    if fmt == "xlsx":
        buf = io.BytesIO()
        with pd.ExcelWriter(buf, engine="openpyxl") as writer:
            for op, rows in rows_by_op.items():
                if not rows:
                    continue
                df = pd.DataFrame(rows)
                safe_name = re.sub(r'[\\/*?:\[\]]', '', op)[:31] or "Sheet1"
                df.to_excel(writer, sheet_name=safe_name, index=False)
        buf.seek(0)
        return send_file(buf, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                         as_attachment=True, download_name="UAL_Export.xlsx")
    else:
        # Flat CSV — merge all operations
        all_rows = []
        for rows in rows_by_op.values():
            all_rows.extend(rows)
        if not all_rows:
            return jsonify({"error": "no data"}), 400
        cols = list(all_rows[0].keys())
        buf = io.StringIO()
        writer = csv.DictWriter(buf, fieldnames=cols, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(all_rows)
        return Response(buf.getvalue(), mimetype="text/csv",
                        headers={"Content-Disposition": "attachment; filename=UAL_Export.csv"})

# ── Core parser (your original logic) ────────────────────────────────────────
def _flatten_json(obj, prefix=""):
    flat = {}
    for key, value in obj.items():
        full_key = f"{prefix}{key}"
        if isinstance(value, dict):
            flat.update(_flatten_json(value, full_key + "."))
        elif isinstance(value, list):
            for i, item in enumerate(value):
                if isinstance(item, dict):
                    flat.update(_flatten_json(item, f"{full_key}[{i}]."))
                else:
                    flat[f"{full_key}[{i}]"] = item
        else:
            flat[full_key] = value
    return flat

def _parse_ual_csv(content):
    rows_by_op = {}
    parsed = 0
    errors = 0

    reader = csv.DictReader(io.StringIO(content))

    # Find AuditData column case-insensitively
    fieldnames = reader.fieldnames or []
    audit_col = next((f for f in fieldnames if f.strip().lower() == "auditdata"), None)
    if not audit_col:
        raise ValueError("No AuditData column found. Is this a valid M365 UAL export?")

    for row in reader:
        try:
            # Flatten AuditData JSON into the row
            audit_raw = row.get(audit_col, "").strip()
            if audit_raw:
                try:
                    audit_obj = json.loads(audit_raw)
                    flat = _flatten_json(audit_obj)
                    row.update(flat)
                except json.JSONDecodeError:
                    errors += 1

            # Remove the raw blob — it's been expanded
            row.pop("AuditData", None)
            row.pop("auditdata", None)

            # Reformat CreationDate
            if row.get("CreationDate"):
                try:
                    row["CreationDate"] = row["CreationDate"].split(".")[0].replace("T", " ")
                except Exception:
                    pass

            operation = row.get("Operation", "Unknown")
            if operation not in rows_by_op:
                rows_by_op[operation] = []
            rows_by_op[operation].append(dict(row))
            parsed += 1

        except Exception:
            errors += 1

    return rows_by_op, parsed, errors
