"""
Artifact Parser Module
- Validates that Zimmerman tool binaries exist at the specified path
- Generates the PowerShell parsing script
- Returns tool availability status
"""

import os, json, subprocess, platform
from flask import Blueprint, request, jsonify, Response
from datetime import date

artifact_bp = Blueprint("artifact", __name__)

# ── Full Zimmerman tool definitions ──────────────────────────────────────────
TOOLS = [
    {
        "id": "mftecmd", "name": "MFTECmd", "default_on": True,
        "desc": "NTFS MFT, USN Journal ($J), $Boot, $SDS",
        "artifacts": "$MFT, $J, $Boot, $SDS",
        "exe": "MFTECmd.exe",
        "commands": lambda col, out, bin_dir: [
            "# MFTECmd — NTFS file system artifacts",
            f'$mft = Get-ChildItem -Path "{col}" -Filter \'$MFT\' -Recurse -Force -EA SilentlyContinue | Select-Object -First 1',
            f'if ($mft) {{ & "{bin_dir}\\MFTECmd.exe" -f $mft.FullName --csv "{out}" --csvf MFTECmd_MFT.csv }}',
            f'else {{ Write-Warning "MFTECmd: $MFT not found" }}',
            f'$usn = Get-ChildItem -Path "{col}" -Filter \'$J\' -Recurse -Force -EA SilentlyContinue | Select-Object -First 1',
            f'if ($usn) {{ & "{bin_dir}\\MFTECmd.exe" -f $usn.FullName --csv "{out}" --csvf MFTECmd_UsnJrnl.csv }}',
        ],
    },
    {
        "id": "evtxecmd", "name": "EvtxECmd", "default_on": True,
        "desc": "Windows Event Logs (.evtx) with event maps",
        "artifacts": "*.evtx",
        "exe": os.path.join("EvtxECmd", "EvtxECmd.exe"),
        "commands": lambda col, out, bin_dir: [
            "# EvtxECmd — Windows Event Logs",
            "# Run EvtxECmd.exe --sync before first use to pull latest event maps",
            f'$evtxDir = Get-ChildItem -Path "{col}" -Directory -Recurse -Force -EA SilentlyContinue | Where-Object {{ $_.Name -eq "Logs" }} | Select-Object -First 1',
            f'if ($evtxDir) {{ & "{bin_dir}\\EvtxECmd\\EvtxECmd.exe" -d $evtxDir.FullName --csv "{out}" --csvf EvtxECmd_Events.csv }}',
            f'else {{',
            f'  $evtx = Get-ChildItem -Path "{col}" -Filter "*.evtx" -Recurse -Force -EA SilentlyContinue | Select-Object -First 1',
            f'  if ($evtx) {{ & "{bin_dir}\\EvtxECmd\\EvtxECmd.exe" -d $evtx.DirectoryName --csv "{out}" --csvf EvtxECmd_Events.csv }}',
            f'  else {{ Write-Warning "EvtxECmd: No .evtx files found" }}',
            f'}}',
        ],
    },
    {
        "id": "lecmd", "name": "LECmd", "default_on": True,
        "desc": "LNK shortcut files",
        "artifacts": "*.lnk",
        "exe": "LECmd.exe",
        "commands": lambda col, out, bin_dir: [
            "# LECmd — LNK files",
            f'& "{bin_dir}\\LECmd.exe" -d "{col}" -q --csv "{out}" --csvf LECmd_LNK.csv',
        ],
    },
    {
        "id": "jlecmd", "name": "JLECmd", "default_on": True,
        "desc": "Jump Lists (automatic & custom destinations)",
        "artifacts": "*.automaticDest-ms, *.customDest-ms",
        "exe": "JLECmd.exe",
        "commands": lambda col, out, bin_dir: [
            "# JLECmd — Jump Lists",
            f'& "{bin_dir}\\JLECmd.exe" -d "{col}" -q --csv "{out}" --csvf JLECmd_JumpLists.csv',
        ],
    },
    {
        "id": "pecmd", "name": "PECmd", "default_on": True,
        "desc": "Prefetch files — program execution evidence",
        "artifacts": "*.pf (Prefetch folder)",
        "exe": "PECmd.exe",
        "commands": lambda col, out, bin_dir: [
            "# PECmd — Prefetch",
            f'$pfDir = Get-ChildItem -Path "{col}" -Directory -Recurse -Force -EA SilentlyContinue | Where-Object {{ $_.Name -eq "Prefetch" }} | Select-Object -First 1',
            f'if ($pfDir) {{ & "{bin_dir}\\PECmd.exe" -d $pfDir.FullName -q --csv "{out}" --csvf PECmd_Prefetch.csv }}',
            f'else {{ Write-Warning "PECmd: Prefetch directory not found" }}',
        ],
    },
    {
        "id": "sbecmd", "name": "SBECmd", "default_on": True,
        "desc": "Shell Bags — folder access & navigation history",
        "artifacts": "NTUSER.DAT, UsrClass.dat",
        "exe": "SBECmd.exe",
        "commands": lambda col, out, bin_dir: [
            "# SBECmd — Shell Bags",
            f'& "{bin_dir}\\SBECmd.exe" -d "{col}" --csv "{out}" --csvf SBECmd_ShellBags.csv',
        ],
    },
    {
        "id": "srumecmd", "name": "SrumECmd", "default_on": True,
        "desc": "SRUM — network, CPU, app resource usage",
        "artifacts": "SRUDB.dat, SOFTWARE hive",
        "exe": "SrumECmd.exe",
        "commands": lambda col, out, bin_dir: [
            "# SrumECmd — System Resource Usage Monitor",
            f'$srum = Get-ChildItem -Path "{col}" -Filter "SRUDB.dat" -Recurse -Force -EA SilentlyContinue | Select-Object -First 1',
            f'$sw   = Get-ChildItem -Path "{col}" -Filter "SOFTWARE" -Recurse -Force -EA SilentlyContinue | Where-Object {{ !$_.PSIsContainer }} | Select-Object -First 1',
            f'if ($srum -and $sw) {{ & "{bin_dir}\\SrumECmd.exe" -f $srum.FullName -r $sw.FullName --csv "{out}" }}',
            f'elseif ($srum) {{ & "{bin_dir}\\SrumECmd.exe" -f $srum.FullName --csv "{out}" }}',
            f'else {{ Write-Warning "SrumECmd: SRUDB.dat not found" }}',
        ],
    },
    {
        "id": "recmd", "name": "RECmd", "default_on": False,
        "desc": "Registry hives with batch scripts",
        "artifacts": "SAM, SYSTEM, SOFTWARE, SECURITY, NTUSER.DAT",
        "exe": "RECmd.exe",
        "commands": lambda col, out, bin_dir: [
            "# RECmd — Registry hives",
            f'$batchDir = "{bin_dir}\\RECmd\\BatchExamples"',
            f'$hives = @("SAM","SYSTEM","SOFTWARE","SECURITY","NTUSER.DAT","UsrClass.dat")',
            f'Get-ChildItem -Path "{col}" -Recurse -Force -EA SilentlyContinue | Where-Object {{ $hives -contains $_.Name -and !$_.PSIsContainer }} | ForEach-Object {{',
            f'  & "{bin_dir}\\RECmd.exe" -f $_.FullName --bn "$batchDir\\Kroll_Batch.reb" --csv "{out}"',
            f'}}',
        ],
    },
    {
        "id": "appcompat", "name": "AppCompatCacheParser", "default_on": False,
        "desc": "Shimcache — program execution from SYSTEM hive",
        "artifacts": "SYSTEM (registry hive)",
        "exe": "AppCompatCacheParser.exe",
        "commands": lambda col, out, bin_dir: [
            "# AppCompatCacheParser — Shimcache",
            f'$sys = Get-ChildItem -Path "{col}" -Filter "SYSTEM" -Recurse -Force -EA SilentlyContinue | Where-Object {{ !$_.PSIsContainer }} | Select-Object -First 1',
            f'if ($sys) {{ & "{bin_dir}\\AppCompatCacheParser.exe" -f $sys.FullName --csv "{out}" --csvf AppCompat_Shimcache.csv }}',
            f'else {{ Write-Warning "AppCompatCacheParser: SYSTEM hive not found" }}',
        ],
    },
    {
        "id": "amcache", "name": "AmcacheParser", "default_on": False,
        "desc": "Amcache.hve — file execution & installation history",
        "artifacts": "Amcache.hve",
        "exe": "AmcacheParser.exe",
        "commands": lambda col, out, bin_dir: [
            "# AmcacheParser",
            f'$amc = Get-ChildItem -Path "{col}" -Filter "Amcache.hve" -Recurse -Force -EA SilentlyContinue | Select-Object -First 1',
            f'if ($amc) {{ & "{bin_dir}\\AmcacheParser.exe" -f $amc.FullName --csv "{out}" --csvf AmcacheParser.csv }}',
            f'else {{ Write-Warning "AmcacheParser: Amcache.hve not found" }}',
        ],
    },
    {
        "id": "rbcmd", "name": "RBCmd", "default_on": False,
        "desc": "Recycle Bin $I metadata files",
        "artifacts": "$I* (Recycle Bin)",
        "exe": "RBCmd.exe",
        "commands": lambda col, out, bin_dir: [
            "# RBCmd — Recycle Bin",
            f'& "{bin_dir}\\RBCmd.exe" -d "{col}" -q --csv "{out}" --csvf RBCmd_RecycleBin.csv',
        ],
    },
    {
        "id": "recentfilecache", "name": "RecentFileCacheParser", "default_on": False,
        "desc": "RecentFileCache.bcf — legacy execution (pre-Win8)",
        "artifacts": "RecentFileCache.bcf",
        "exe": "RecentFileCacheParser.exe",
        "commands": lambda col, out, bin_dir: [
            "# RecentFileCacheParser",
            f'$rfc = Get-ChildItem -Path "{col}" -Filter "RecentFileCache.bcf" -Recurse -Force -EA SilentlyContinue | Select-Object -First 1',
            f'if ($rfc) {{ & "{bin_dir}\\RecentFileCacheParser.exe" -f $rfc.FullName --csv "{out}" --csvf RecentFileCache.csv }}',
            f'else {{ Write-Warning "RecentFileCacheParser: file not found" }}',
        ],
    },
    {
        "id": "sqlecmd", "name": "SQLECmd", "default_on": False,
        "desc": "SQLite databases — browser history, ESE DBs (run --sync first)",
        "artifacts": "*.db, *.sqlite, *.db3",
        "exe": os.path.join("SQLECmd", "SQLECmd.exe"),
        "commands": lambda col, out, bin_dir: [
            "# SQLECmd — SQLite databases",
            "# Run SQLECmd.exe --sync before first use to pull latest maps",
            f'& "{bin_dir}\\SQLECmd\\SQLECmd.exe" -d "{col}" --csv "{out}"',
        ],
    },
    {
        "id": "wxtcmd", "name": "WxTCmd", "default_on": False,
        "desc": "Windows 10/11 Timeline (ActivitiesCache.db)",
        "artifacts": "ActivitiesCache.db",
        "exe": "WxTCmd.exe",
        "commands": lambda col, out, bin_dir: [
            "# WxTCmd — Windows Timeline",
            f'$wxt = Get-ChildItem -Path "{col}" -Filter "ActivitiesCache.db" -Recurse -Force -EA SilentlyContinue | Select-Object -First 1',
            f'if ($wxt) {{ & "{bin_dir}\\WxTCmd.exe" -f $wxt.FullName --csv "{out}" }}',
            f'else {{ Write-Warning "WxTCmd: ActivitiesCache.db not found" }}',
        ],
    },
    {
        "id": "bstrings", "name": "bstrings", "default_on": False,
        "desc": "String search across files — regex, IP/email/hash patterns",
        "artifacts": "any file",
        "exe": "bstrings.exe",
        "commands": lambda col, out, bin_dir: [
            "# bstrings — string search (may be slow on large collections)",
            f'& "{bin_dir}\\bstrings.exe" -d "{col}" --csv "{out}"',
        ],
    },
]

# ── Tool list ─────────────────────────────────────────────────────────────────
@artifact_bp.route("/tools", methods=["GET"])
def get_tools():
    """Return tool definitions (without lambda commands, those are server-side only)."""
    return jsonify([
        {k: v for k, v in t.items() if k != "commands"}
        for t in TOOLS
    ])

# ── Check tool availability ───────────────────────────────────────────────────
@artifact_bp.route("/check-tools", methods=["POST"])
def check_tools():
    """
    POST body: { "tools_dir": "C:\\Tools\\ZimmermanTools" }
    Returns which tool executables exist at that path.
    """
    data = request.json or {}
    tools_dir = data.get("tools_dir", "").strip()

    if not tools_dir:
        return jsonify({"error": "tools_dir required"}), 400

    results = {}
    for t in TOOLS:
        exe_path = os.path.join(tools_dir, t["exe"])
        results[t["id"]] = {
            "found": os.path.isfile(exe_path),
            "path":  exe_path,
        }
    return jsonify(results)

# ── Generate script ───────────────────────────────────────────────────────────
@artifact_bp.route("/generate-script", methods=["POST"])
def generate_script():
    """
    POST body:
      collection_path — input folder from CyLR/collection
      output_path     — where CSVs will be written
      tools_dir       — Zimmerman tools directory
      enabled_tools   — list of tool IDs to include
    Returns the .ps1 script as plain text.
    """
    data = request.json or {}
    col       = data.get("collection_path", "C:\\Cases\\Collection")
    out       = data.get("output_path",     "C:\\Cases\\Parsed")
    bin_dir   = data.get("tools_dir",       "C:\\Tools\\ZimmermanTools")
    enabled   = set(data.get("enabled_tools", [t["id"] for t in TOOLS if t["default_on"]]))

    today = date.today().isoformat()
    lines = [
        f"# IR Toolkit — Artifact Parser Script",
        f"# Generated: {today}",
        f"# Collection: {col}",
        f"# Output:     {out}",
        f"# Tools:      {bin_dir}",
        f"#",
        f"# Prerequisites:",
        f"#   Install tools: .\\Get-ZimmermanTools.ps1 -Dest \"{bin_dir}\"",
        f"#   Sync maps:     {bin_dir}\\EvtxECmd\\EvtxECmd.exe --sync",
        f"#                  {bin_dir}\\SQLECmd\\SQLECmd.exe --sync",
        f"",
        f"$ErrorActionPreference = \"Continue\"",
        f"New-Item -ItemType Directory -Force -Path \"{out}\" | Out-Null",
        f"Write-Host \"[*] Starting artifact parsing — $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')\" -ForegroundColor Cyan",
        f"",
    ]

    active_tools = [t for t in TOOLS if t["id"] in enabled]
    for t in active_tools:
        tool_cmds = t["commands"](col, out, bin_dir)
        lines.extend(tool_cmds)
        lines.append(f'Write-Host "[+] {t["name"]} complete" -ForegroundColor Green')
        lines.append("")

    lines.append(f'Write-Host "[*] All done. CSVs written to: {out}" -ForegroundColor Cyan')

    script = "\n".join(lines)
    return Response(script, mimetype="text/plain",
                    headers={"Content-Disposition": "attachment; filename=parse_artifacts.ps1"})
