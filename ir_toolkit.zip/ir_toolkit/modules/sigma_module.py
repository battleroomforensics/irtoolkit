"""
Sigma Module
  Tab 1 — Hayabusa: auto-download binary, update rules, run csv-timeline against .evtx files
  Tab 2 — CSV Search: regex/keyword search across Zimmerman CSV output, saved searches
"""

import os, json, re, csv, io, sys, zipfile, subprocess, threading, urllib.request, glob
from flask import Blueprint, request, jsonify, Response, send_file

sigma_bp = Blueprint("sigma", __name__)

BASE_DIR          = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR          = os.path.join(BASE_DIR, "data")
SIGMA_DIR         = os.path.join(DATA_DIR, "sigma")
HAYABUSA_DIR      = os.path.join(SIGMA_DIR, "hayabusa")
SAVED_SEARCHES_FILE = os.path.join(SIGMA_DIR, "saved_searches.json")

GITHUB_API        = "https://api.github.com/repos/Yamato-Security/hayabusa/releases/latest"

def _ensure_dirs():
    os.makedirs(SIGMA_DIR,    exist_ok=True)
    os.makedirs(HAYABUSA_DIR, exist_ok=True)

def _hayabusa_exe():
    """Return the path to the Hayabusa executable if it exists."""
    _ensure_dirs()
    for fname in os.listdir(HAYABUSA_DIR):
        if fname.endswith(".exe") or (not fname.endswith(".zip") and os.access(os.path.join(HAYABUSA_DIR, fname), os.X_OK)):
            if "hayabusa" in fname.lower():
                return os.path.join(HAYABUSA_DIR, fname)
    return None

def _github_get(url):
    req = urllib.request.Request(url, headers={"User-Agent": "IR-Toolkit/1.0"})
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode())

# ═══════════════════════════════════════════════════════════════════
# HAYABUSA — STATUS, DOWNLOAD, UPDATE, RUN
# ═══════════════════════════════════════════════════════════════════

@sigma_bp.route("/hayabusa/status", methods=["GET"])
def hayabusa_status():
    exe = _hayabusa_exe()
    rules_dir = os.path.join(HAYABUSA_DIR, "rules")
    has_rules = os.path.isdir(rules_dir) and bool(os.listdir(rules_dir))

    version = None
    if exe:
        try:
            result = subprocess.run([exe, "--version"], capture_output=True, text=True, timeout=5)
            m = re.search(r'(\d+\.\d+\.\d+)', result.stdout + result.stderr)
            if m:
                version = m.group(1)
        except Exception:
            pass

    return jsonify({
        "installed":   bool(exe),
        "exe_path":    exe or "",
        "has_rules":   has_rules,
        "ready":       bool(exe),
        "version":     version,
        "hayabusa_dir": HAYABUSA_DIR,
    })

@sigma_bp.route("/hayabusa/download", methods=["POST"])
def hayabusa_download():
    """Download latest Hayabusa release for the current platform. Streams SSE."""
    def generate():
        def emit(cls, text):
            return f"data: {json.dumps({'cls': cls, 'text': text})}\n\n"

        _ensure_dirs()

        # ── Get latest release from GitHub ──────────────────────────────────
        yield emit("cmd", "[*] Checking latest Hayabusa release...")
        try:
            release = _github_get(GITHUB_API)
        except Exception as e:
            yield emit("error", f"[!] Could not reach GitHub API: {e}")
            return

        tag     = release.get("tag_name", "")
        version = tag.lstrip("v")
        assets  = {a["name"]: a["browser_download_url"] for a in release.get("assets", [])}
        yield emit("info", f"[*] Latest version: {tag}")

        # ── Pick the right asset for this platform ───────────────────────────
        if sys.platform == "win32":
            # Prefer the standard (non-live-response) build
            asset_name = next(
                (n for n in assets if f"{version}-win-x64.zip" in n and "live" not in n.lower()),
                next((n for n in assets if "win-x64" in n and n.endswith(".zip")), None)
            )
        elif sys.platform == "darwin":
            asset_name = next(
                (n for n in assets if "mac" in n.lower() and n.endswith(".zip")), None)
        else:
            asset_name = next(
                (n for n in assets if "linux-x64" in n.lower() and n.endswith(".zip")), None)

        if not asset_name:
            yield emit("error", f"[!] No suitable asset found for {sys.platform}. Available: {list(assets.keys())[:6]}")
            return

        download_url = assets[asset_name]
        yield emit("info",  f"[*] Asset: {asset_name}")
        yield emit("cmd",   "[*] Downloading...")

        # ── Download ZIP ─────────────────────────────────────────────────────
        try:
            req = urllib.request.Request(
                download_url,
                headers={"User-Agent": "IR-Toolkit/1.0", "Accept": "application/octet-stream"}
            )
            with urllib.request.urlopen(req, timeout=180) as resp:
                zip_bytes = resp.read()
        except Exception as e:
            yield emit("error", f"[!] Download failed: {e}")
            return

        size_mb = len(zip_bytes) / 1048576
        yield emit("info", f"[+] Downloaded {size_mb:.1f} MB")

        if zip_bytes[:4] != b"PK\x03\x04":
            yield emit("error", "[!] Downloaded file is not a valid ZIP.")
            return

        # ── Extract to HAYABUSA_DIR ──────────────────────────────────────────
        yield emit("cmd", f"[*] Extracting to {HAYABUSA_DIR}...")
        try:
            with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
                names = zf.namelist()
                yield emit("info", f"[*] ZIP contains {len(names)} files")
                for member in names:
                    # Extract preserving structure but rooted at HAYABUSA_DIR
                    dest = os.path.join(HAYABUSA_DIR, member)
                    if member.endswith("/"):
                        os.makedirs(dest, exist_ok=True)
                    else:
                        os.makedirs(os.path.dirname(dest), exist_ok=True)
                        with open(dest, "wb") as f:
                            f.write(zf.read(member))
                        # Mark executable on Unix
                        if not sys.platform == "win32" and ("hayabusa" in member.lower()) and not member.endswith(".zip"):
                            os.chmod(dest, 0o755)
        except Exception as e:
            yield emit("error", f"[!] Extraction failed: {e}")
            return

        exe = _hayabusa_exe()
        if exe:
            yield emit("done", f"[✓] Hayabusa installed: {exe}")
            yield emit("info", "[*] Run 'Update rules' to download the latest Sigma rules.")
        else:
            yield emit("warn", "[~] Extraction complete but executable not found — check the directory.")

        yield f"data: {json.dumps({'cls': 'complete', 'version': version})}\n\n"

    return Response(generate(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

@sigma_bp.route("/hayabusa/update-rules", methods=["POST"])
def hayabusa_update_rules():
    """Run hayabusa update-rules to pull latest Sigma rules. Streams SSE."""
    def generate():
        def emit(cls, text):
            return f"data: {json.dumps({'cls': cls, 'text': text})}\n\n"

        exe = _hayabusa_exe()
        if not exe:
            yield emit("error", "[!] Hayabusa not installed. Download it first.")
            return

        yield emit("cmd", "[*] Updating Hayabusa rules from GitHub...")
        yield emit("info", "[*] This downloads the latest hayabusa-rules repository...")

        try:
            proc = subprocess.Popen(
                [exe, "update-rules"],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                cwd=HAYABUSA_DIR,
            )
            for line in proc.stdout:
                line = line.rstrip()
                if not line:
                    continue
                cls = "done"  if any(w in line.lower() for w in ["success", "complete", "updated", "downloaded"]) else \
                      "warn"  if any(w in line.lower() for w in ["warn", "error", "fail"]) else \
                      "info"
                yield emit(cls, line)
            proc.wait(timeout=300)
        except subprocess.TimeoutExpired:
            yield emit("error", "[!] Timed out after 5 minutes.")
            return
        except Exception as e:
            yield emit("error", f"[!] Error: {e}")
            return

        rules_dir = os.path.join(HAYABUSA_DIR, "rules")
        rule_count = sum(1 for _ in glob.glob(os.path.join(rules_dir, "**", "*.yml"), recursive=True))
        yield emit("done", f"[✓] Rules updated — {rule_count:,} .yml files in rules/")
        yield f"data: {json.dumps({'cls': 'complete', 'rule_count': rule_count})}\n\n"

    return Response(generate(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

@sigma_bp.route("/hayabusa/run", methods=["POST"])
def hayabusa_run():
    """
    Run hayabusa csv-timeline. Streams SSE output.
    POST body:
      evtx_path    — path to .evtx file or directory
      output_path  — where to write the output CSV
      min_level    — informational | low | medium | high | critical
      profile      — standard | verbose | all-field-info
      start_time   — optional ISO string
      end_time     — optional ISO string
    """
    data        = request.json or {}
    evtx_path   = data.get("evtx_path",   "").strip()
    output_path = data.get("output_path",  "").strip()
    min_level   = data.get("min_level",    "medium")
    profile     = data.get("profile",      "standard")
    start_time  = data.get("start_time",   "").strip()
    end_time    = data.get("end_time",     "").strip()

    if not evtx_path:
        return jsonify({"error": "evtx_path required"}), 400
    if not os.path.exists(evtx_path):
        return jsonify({"error": f"Path not found: {evtx_path}"}), 404

    exe = _hayabusa_exe()
    if not exe:
        return jsonify({"error": "Hayabusa not installed"}), 400

    if not output_path:
        output_path = os.path.join(SIGMA_DIR, "hayabusa_results.csv")

    def generate():
        def emit(cls, text):
            return f"data: {json.dumps({'cls': cls, 'text': text})}\n\n"

        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

        # Build command
        input_flag = "-d" if os.path.isdir(evtx_path) else "-f"
        cmd = [
            exe, "csv-timeline",
            input_flag, evtx_path,
            "-o", output_path,
            "--min-level", min_level,
            "--profile", profile,
            "--no-wizard",           # non-interactive
            "--quiet",               # suppress progress bar (we stream stdout)
        ]
        if start_time: cmd += ["--timeline-start", start_time]
        if end_time:   cmd += ["--timeline-end",   end_time]

        yield emit("info", f"[*] Input:    {evtx_path}")
        yield emit("info", f"[*] Output:   {output_path}")
        yield emit("info", f"[*] Level:    {min_level}+")
        yield emit("info", f"[*] Profile:  {profile}")
        yield emit("cmd",  f"[>] {' '.join(cmd)}")

        try:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                cwd=HAYABUSA_DIR,
            )
            for line in proc.stdout:
                line = line.rstrip()
                if not line:
                    continue
                cls = "match" if any(w in line.lower() for w in ["detect", "alert", "hit", "critical", "high"]) else \
                      "done"  if any(w in line.lower() for w in ["finish", "complete", "total", "written"]) else \
                      "warn"  if "error" in line.lower() or "warn" in line.lower() else \
                      "info"
                yield emit(cls, line)
            proc.wait(timeout=3600)
        except subprocess.TimeoutExpired:
            yield emit("warn", "[~] Timed out after 1 hour.")
            proc.kill()
        except Exception as e:
            yield emit("error", f"[!] Error: {e}")
            return

        # Count results
        hit_count = 0
        if os.path.isfile(output_path):
            try:
                with open(output_path, encoding="utf-8-sig", errors="replace") as f:
                    hit_count = max(0, sum(1 for _ in f) - 1)
            except Exception:
                pass

        yield emit("done",  f"[✓] Scan complete — {hit_count:,} events in output")
        yield emit("done",  f"[✓] Results: {output_path}")
        yield f"data: {json.dumps({'cls': 'complete', 'output_path': output_path, 'hit_count': hit_count})}\n\n"

    return Response(generate(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

@sigma_bp.route("/hayabusa/load-results", methods=["POST"])
def hayabusa_load_results():
    """
    Load a Hayabusa CSV result file and return rows for display.
    POST body: { "path": "..." }
    Returns first 2000 rows + column list.
    """
    data = request.json or {}
    path = data.get("path", "").strip()
    if not path or not os.path.isfile(path):
        return jsonify({"error": f"File not found: {path}"}), 404

    try:
        rows = []
        with open(path, encoding="utf-8-sig", errors="replace") as f:
            reader = csv.DictReader(f)
            cols   = reader.fieldnames or []
            for i, row in enumerate(reader):
                if i >= 2000:
                    break
                rows.append(dict(row))
        total = sum(1 for _ in open(path, encoding="utf-8-sig", errors="replace")) - 1
        return jsonify({"columns": cols, "rows": rows, "total": total, "showing": len(rows)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ═══════════════════════════════════════════════════════════════════
# CSV SEARCH — keyword/regex across Zimmerman CSV output
# ═══════════════════════════════════════════════════════════════════

@sigma_bp.route("/csv-search/run", methods=["POST"])
def csv_search_run():
    """
    Search across all CSV files in a directory.
    POST body:
      directory   — path to search
      terms       — list of search strings
      mode        — 'any' (OR) | 'all' (AND)
      use_regex   — bool
      max_results — int (default 2000)
    Returns matched rows with source file, row number, and full row data.
    """
    data        = request.json or {}
    directory   = data.get("directory",   "").strip()
    terms       = data.get("terms",       [])
    mode        = data.get("mode",        "any")    # 'any' = OR, 'all' = AND
    use_regex   = bool(data.get("use_regex", False))
    max_results = int(data.get("max_results", 2000))

    if not directory:
        return jsonify({"error": "directory required"}), 400
    if not os.path.isdir(directory):
        return jsonify({"error": f"Directory not found: {directory}"}), 404
    if not terms:
        return jsonify({"error": "at least one search term required"}), 400

    # Compile patterns
    try:
        if use_regex:
            patterns = [re.compile(t, re.IGNORECASE) for t in terms if t.strip()]
        else:
            patterns = [re.compile(re.escape(t), re.IGNORECASE) for t in terms if t.strip()]
    except re.error as e:
        return jsonify({"error": f"Invalid regex: {e}"}), 400

    csv_files = sorted(glob.glob(os.path.join(directory, "**", "*.csv"), recursive=True))
    if not csv_files:
        return jsonify({"files_searched": 0, "results": [], "total_matches": 0,
                        "message": "No CSV files found in directory."})

    results    = []
    files_hit  = set()
    truncated  = False

    for fpath in csv_files:
        fname = os.path.relpath(fpath, directory)
        try:
            with open(fpath, encoding="utf-8-sig", errors="replace") as f:
                reader = csv.DictReader(f)
                if not reader.fieldnames:
                    continue
                for row_num, row in enumerate(reader, start=2):
                    # Combine all cell values into one searchable string
                    row_text = " ".join(str(v) for v in row.values())

                    if mode == "all":
                        matched = all(p.search(row_text) for p in patterns)
                    else:
                        matched = any(p.search(row_text) for p in patterns)

                    if matched:
                        # Highlight which terms matched
                        matched_terms = [t for t, p in zip(terms, patterns) if p.search(row_text)]
                        results.append({
                            "file":          fname,
                            "row":           row_num,
                            "matched_terms": matched_terms,
                            "data":          dict(row),
                        })
                        files_hit.add(fname)

                        if len(results) >= max_results:
                            truncated = True
                            break

        except Exception:
            continue  # skip unreadable files

        if truncated:
            break

    return jsonify({
        "files_searched":  len(csv_files),
        "files_with_hits": len(files_hit),
        "total_matches":   len(results),
        "truncated":       truncated,
        "max_results":     max_results,
        "results":         results,
    })

@sigma_bp.route("/csv-search/export", methods=["POST"])
def csv_search_export():
    """Export search results as a CSV file."""
    data    = request.json or {}
    results = data.get("results", [])
    if not results:
        return jsonify({"error": "no results to export"}), 400

    buf = io.StringIO()
    # Collect all column names across all results
    all_cols = ["file", "row", "matched_terms"]
    seen_data_cols = []
    for r in results:
        for k in r.get("data", {}).keys():
            if k not in seen_data_cols:
                seen_data_cols.append(k)
    all_cols += seen_data_cols

    writer = csv.DictWriter(buf, fieldnames=all_cols, extrasaction="ignore")
    writer.writeheader()
    for r in results:
        flat = {
            "file":          r["file"],
            "row":           r["row"],
            "matched_terms": ", ".join(r.get("matched_terms", [])),
        }
        flat.update(r.get("data", {}))
        writer.writerow(flat)

    return Response(
        buf.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=search_results.csv"},
    )

# ═══════════════════════════════════════════════════════════════════
# SAVED SEARCHES
# ═══════════════════════════════════════════════════════════════════

def _load_saved_searches():
    if os.path.isfile(SAVED_SEARCHES_FILE):
        try:
            return json.load(open(SAVED_SEARCHES_FILE, encoding="utf-8"))
        except Exception:
            pass
    return []

def _save_saved_searches(searches):
    os.makedirs(SIGMA_DIR, exist_ok=True)
    with open(SAVED_SEARCHES_FILE, "w", encoding="utf-8") as f:
        json.dump(searches, f, indent=2)

@sigma_bp.route("/csv-search/saved", methods=["GET"])
def get_saved_searches():
    return jsonify(_load_saved_searches())

@sigma_bp.route("/csv-search/saved", methods=["POST"])
def save_search():
    data = request.json or {}
    if not data.get("name"):
        return jsonify({"error": "name required"}), 400
    searches = _load_saved_searches()
    # Replace if name exists
    searches = [s for s in searches if s.get("name") != data["name"]]
    searches.append({
        "name":       data["name"],
        "terms":      data.get("terms", []),
        "mode":       data.get("mode", "any"),
        "use_regex":  data.get("use_regex", False),
        "directory":  data.get("directory", ""),
        "created":    data.get("created", ""),
    })
    _save_saved_searches(searches)
    return jsonify({"saved": data["name"]})

@sigma_bp.route("/csv-search/saved/<name>", methods=["DELETE"])
def delete_saved_search(name):
    searches = _load_saved_searches()
    searches = [s for s in searches if s.get("name") != name]
    _save_saved_searches(searches)
    return jsonify({"deleted": name})
