"""
Sigma Module
  - Hayabusa: download, update rules, run csv-timeline (Windows path-safe)
  - CSV Search: streaming SSE with progress, stop support, saved searches
"""

import os, json, re, csv, io, sys, zipfile, subprocess, threading, urllib.request, glob
from flask import Blueprint, request, jsonify, Response

sigma_bp = Blueprint("sigma", __name__)

BASE_DIR            = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR            = os.path.join(BASE_DIR, "data")
SIGMA_DIR           = os.path.join(DATA_DIR, "sigma")
HAYABUSA_DIR        = os.path.join(SIGMA_DIR, "hayabusa")
SAVED_SEARCHES_FILE = os.path.join(SIGMA_DIR, "saved_searches.json")
GITHUB_API          = "https://api.github.com/repos/Yamato-Security/hayabusa/releases/latest"

# Active search cancellation flags: search_id -> threading.Event
_search_cancel = {}
_search_lock   = threading.Lock()

def _ensure_dirs():
    os.makedirs(SIGMA_DIR,    exist_ok=True)
    os.makedirs(HAYABUSA_DIR, exist_ok=True)

def _hayabusa_exe():
    """Return the absolute path to the Hayabusa executable if found."""
    _ensure_dirs()
    candidates = []
    for root, dirs, files in os.walk(HAYABUSA_DIR):
        for fname in files:
            if "hayabusa" in fname.lower():
                fpath = os.path.join(root, fname)
                if fname.endswith(".exe") or os.access(fpath, os.X_OK):
                    candidates.append(fpath)
    # Prefer non-live-response exe, and prefer shorter paths (root level)
    candidates.sort(key=lambda p: (len(p), "live" in p.lower()))
    return candidates[0] if candidates else None

def _github_get(url):
    req = urllib.request.Request(url, headers={"User-Agent": "IR-Toolkit/1.0"})
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode())

# ═══════════════════════════════════════════════════════════════════
# HAYABUSA
# ═══════════════════════════════════════════════════════════════════

@sigma_bp.route("/hayabusa/status", methods=["GET"])
def hayabusa_status():
    exe       = _hayabusa_exe()
    rules_dir = os.path.join(HAYABUSA_DIR, "rules")
    has_rules = os.path.isdir(rules_dir) and bool(os.listdir(rules_dir))

    version = None
    if exe:
        try:
            # On Windows use shell=False with absolute path — no cwd needed
            result = subprocess.run(
                [exe, "--version"],
                capture_output=True, text=True, timeout=8
            )
            m = re.search(r'(\d+\.\d+\.\d+)', result.stdout + result.stderr)
            if m:
                version = m.group(1)
        except Exception:
            pass

    return jsonify({
        "installed":    bool(exe),
        "exe_path":     exe or "",
        "has_rules":    has_rules,
        "ready":        bool(exe),
        "version":      version,
        "hayabusa_dir": HAYABUSA_DIR,
    })

@sigma_bp.route("/hayabusa/download", methods=["POST"])
def hayabusa_download():
    """Download latest Hayabusa release. Streams SSE."""
    def generate():
        def emit(cls, text):
            return f"data: {json.dumps({'cls': cls, 'text': text})}\n\n"

        _ensure_dirs()
        yield emit("cmd", "[*] Checking latest Hayabusa release on GitHub...")

        try:
            release = _github_get(GITHUB_API)
        except Exception as e:
            yield emit("error", f"[!] Could not reach GitHub API: {e}")
            return

        tag     = release.get("tag_name", "")
        version = tag.lstrip("v")
        assets  = {a["name"]: a["browser_download_url"] for a in release.get("assets", [])}
        yield emit("info", f"[*] Latest version: {tag}")
        yield emit("info", f"[*] Available assets: {', '.join(list(assets.keys())[:5])}{'...' if len(assets)>5 else ''}")

        # Pick asset for platform — prefer non-live-response build
        if sys.platform == "win32":
            asset_name = next(
                (n for n in assets if f"{version}-win-x64.zip" in n and "live" not in n.lower()),
                next((n for n in assets if "win-x64" in n and n.endswith(".zip") and "live" not in n.lower()), None)
            )
        elif sys.platform == "darwin":
            asset_name = next((n for n in assets if "mac" in n.lower() and n.endswith(".zip")), None)
        else:
            asset_name = next((n for n in assets if "linux-x64" in n.lower() and n.endswith(".zip")), None)

        if not asset_name:
            yield emit("error", f"[!] No asset found for {sys.platform}. Available: {list(assets.keys())}")
            return

        download_url = assets[asset_name]
        yield emit("info", f"[*] Downloading: {asset_name}")

        try:
            req = urllib.request.Request(
                download_url,
                headers={"User-Agent": "IR-Toolkit/1.0", "Accept": "application/octet-stream"}
            )
            with urllib.request.urlopen(req, timeout=300) as resp:
                zip_bytes = resp.read()
        except Exception as e:
            yield emit("error", f"[!] Download failed: {e}")
            return

        size_mb = len(zip_bytes) / 1048576
        yield emit("info", f"[+] Downloaded {size_mb:.1f} MB")

        if zip_bytes[:4] != b"PK\x03\x04":
            yield emit("error", "[!] Downloaded file is not a valid ZIP.")
            return

        yield emit("cmd", f"[*] Extracting to {HAYABUSA_DIR}...")
        try:
            with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
                for member in zf.namelist():
                    dest = os.path.join(HAYABUSA_DIR, member)
                    if member.endswith("/"):
                        os.makedirs(dest, exist_ok=True)
                    else:
                        os.makedirs(os.path.dirname(dest), exist_ok=True)
                        with open(dest, "wb") as f:
                            f.write(zf.read(member))
                        if sys.platform != "win32" and "hayabusa" in member.lower():
                            os.chmod(dest, 0o755)
        except Exception as e:
            yield emit("error", f"[!] Extraction failed: {e}")
            return

        exe = _hayabusa_exe()
        if exe:
            yield emit("done", f"[✓] Hayabusa installed: {exe}")
            yield emit("info", "[*] Click 'Update rules' to download the latest Sigma rules.")
        else:
            yield emit("warn", "[~] Extracted but executable not found — check the hayabusa directory.")

        yield f"data: {json.dumps({'cls': 'complete', 'version': version})}\n\n"

    return Response(generate(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

@sigma_bp.route("/hayabusa/update-rules", methods=["POST"])
def hayabusa_update_rules():
    """Run hayabusa update-rules. Streams SSE."""
    def generate():
        def emit(cls, text):
            return f"data: {json.dumps({'cls': cls, 'text': text})}\n\n"

        exe = _hayabusa_exe()
        if not exe:
            yield emit("error", "[!] Hayabusa not installed. Download it first.")
            return

        yield emit("cmd", "[*] Updating Hayabusa rules...")

        try:
            proc = subprocess.Popen(
                [exe, "update-rules"],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                # No cwd — use absolute exe path, let it manage its own paths
            )
            for line in proc.stdout:
                line = line.rstrip()
                if not line:
                    continue
                cls = "done" if any(w in line.lower() for w in ["success","complete","updated","downloaded"]) else \
                      "warn" if any(w in line.lower() for w in ["warn","error","fail"]) else "info"
                yield emit(cls, line)
            proc.wait(timeout=300)
        except subprocess.TimeoutExpired:
            yield emit("error", "[!] Timed out after 5 minutes.")
            return
        except Exception as e:
            yield emit("error", f"[!] Error: {e}")
            return

        rules_dir  = os.path.join(HAYABUSA_DIR, "rules")
        rule_count = sum(1 for _ in glob.glob(os.path.join(rules_dir, "**", "*.yml"), recursive=True))
        yield emit("done", f"[✓] Rules updated — {rule_count:,} rules")
        yield f"data: {json.dumps({'cls': 'complete', 'rule_count': rule_count})}\n\n"

    return Response(generate(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

@sigma_bp.route("/hayabusa/run", methods=["POST"])
def hayabusa_run():
    """
    Run hayabusa csv-timeline. Streams SSE.
    Key fix: pass paths as individual list elements to subprocess —
    never use shell=True or join into a string. This avoids the Windows
    'C:' path splitting error entirely.
    """
    data        = request.json or {}
    evtx_path   = data.get("evtx_path",   "").strip()
    output_path = data.get("output_path",  "").strip()
    min_level   = data.get("min_level",    "medium")
    profile     = data.get("profile",      "standard")
    start_time  = data.get("start_time",   "").strip()
    end_time    = data.get("end_time",     "").strip()

    if not evtx_path:
        return jsonify({"error": "evtx_path required"}), 400
    if not os.path.exists(evtx_path):
        return jsonify({"error": f"Path not found: {evtx_path}"}), 404

    exe = _hayabusa_exe()
    if not exe:
        return jsonify({"error": "Hayabusa not installed. Use the Artifact Parser to download it."}), 400

    if not output_path:
        output_path = os.path.join(SIGMA_DIR, "hayabusa_results.csv")

    def generate():
        def emit(cls, text):
            return f"data: {json.dumps({'cls': cls, 'text': text})}\n\n"

        out_dir = os.path.dirname(os.path.abspath(output_path))
        os.makedirs(out_dir, exist_ok=True)

        # Use absolute paths throughout — critical on Windows
        abs_exe    = os.path.abspath(exe)
        abs_evtx   = os.path.abspath(evtx_path)
        abs_output = os.path.abspath(output_path)

        input_flag = "-d" if os.path.isdir(abs_evtx) else "-f"

        # Build command as a list — subprocess handles quoting correctly
        # Do NOT use shell=True or ' '.join() — that's what caused "C" error
        cmd = [
            abs_exe, "csv-timeline",
            input_flag, abs_evtx,
            "-o", abs_output,
            "--min-level", min_level,
            "--profile", profile,
            "--no-wizard",
            "--no-color",       # strip ANSI codes from terminal output
        ]
        if start_time: cmd += ["--timeline-start", start_time]
        if end_time:   cmd += ["--timeline-end",   end_time]

        yield emit("info", f"[*] Input:   {abs_evtx}")
        yield emit("info", f"[*] Output:  {abs_output}")
        yield emit("info", f"[*] Level:   {min_level}+  |  Profile: {profile}")
        yield emit("cmd",  f"[>] {abs_exe} csv-timeline {input_flag} \"{abs_evtx}\" -o \"{abs_output}\" --min-level {min_level}")

        try:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                # No cwd, no shell — safest on Windows
            )
            for line in proc.stdout:
                line = line.rstrip()
                if not line:
                    continue
                # Strip any remaining ANSI escape codes
                line = re.sub(r'\x1b\[[0-9;]*m', '', line)
                cls = "match" if any(w in line.lower() for w in ["detect","critical","high","alert"]) else \
                      "done"  if any(w in line.lower() for w in ["finish","complete","total","written","saved"]) else \
                      "warn"  if any(w in line.lower() for w in ["error","warn","fail"]) else \
                      "info"
                yield emit(cls, line)
            proc.wait(timeout=3600)
        except subprocess.TimeoutExpired:
            yield emit("warn", "[~] Timed out after 1 hour.")
            proc.kill()
        except Exception as e:
            yield emit("error", f"[!] Error running Hayabusa: {e}")
            return

        hit_count = 0
        if os.path.isfile(abs_output):
            try:
                with open(abs_output, encoding="utf-8-sig", errors="replace") as f:
                    hit_count = max(0, sum(1 for _ in f) - 1)
            except Exception:
                pass

        yield emit("done", f"[✓] Scan complete — {hit_count:,} events")
        yield emit("done", f"[✓] Results: {abs_output}")
        yield f"data: {json.dumps({'cls': 'complete', 'output_path': abs_output, 'hit_count': hit_count})}\n\n"

    return Response(generate(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

@sigma_bp.route("/hayabusa/load-results", methods=["POST"])
def hayabusa_load_results():
    data = request.json or {}
    path = data.get("path", "").strip()
    if not path or not os.path.isfile(path):
        return jsonify({"error": f"File not found: {path}"}), 404
    try:
        rows = []
        with open(path, encoding="utf-8-sig", errors="replace") as f:
            reader = csv.DictReader(f)
            cols   = list(reader.fieldnames or [])
            for i, row in enumerate(reader):
                if i >= 2000: break
                rows.append(dict(row))
        total = sum(1 for _ in open(path, encoding="utf-8-sig", errors="replace")) - 1
        return jsonify({"columns": cols, "rows": rows, "total": total, "showing": len(rows)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ═══════════════════════════════════════════════════════════════════
# CSV SEARCH — streaming SSE with progress and stop support
# ═══════════════════════════════════════════════════════════════════

@sigma_bp.route("/csv-search/run", methods=["POST"])
def csv_search_run():
    """
    Search CSV files — streams SSE progress events so the UI stays responsive.
    Supports cancellation via the /csv-search/stop endpoint.
    POST body:
      directory   — path to search (recursive)
      terms       — list of search strings
      mode        — 'any' (OR) | 'all' (AND)
      use_regex   — bool
      max_results — int (default 5000)
      search_id   — client-generated ID used to cancel this search
    """
    data        = request.json or {}
    directory   = data.get("directory",   "").strip()
    terms       = data.get("terms",       [])
    mode        = data.get("mode",        "any")
    use_regex   = bool(data.get("use_regex", False))
    max_results = int(data.get("max_results", 5000))
    search_id   = data.get("search_id",  "default")

    if not directory:
        return jsonify({"error": "directory required"}), 400
    if not os.path.isdir(directory):
        return jsonify({"error": f"Directory not found: {directory}"}), 404
    if not terms:
        return jsonify({"error": "at least one search term required"}), 400

    try:
        if use_regex:
            patterns = [re.compile(t, re.IGNORECASE) for t in terms if t.strip()]
        else:
            patterns = [re.compile(re.escape(t), re.IGNORECASE) for t in terms if t.strip()]
        active_terms = [t for t in terms if t.strip()]
    except re.error as e:
        return jsonify({"error": f"Invalid regex: {e}"}), 400

    # Register cancellation event
    cancel_event = threading.Event()
    with _search_lock:
        _search_cancel[search_id] = cancel_event

    def generate():
        def emit(cls, text, **extra):
            payload = {"cls": cls, "text": text, **extra}
            return f"data: {json.dumps(payload)}\n\n"

        try:
            csv_files = sorted(
                glob.glob(os.path.join(directory, "**", "*.csv"), recursive=True)
            )

            if not csv_files:
                yield emit("warn", "[~] No CSV files found in directory.")
                yield f"data: {json.dumps({'cls': 'complete', 'results': [], 'files_searched': 0, 'total_matches': 0})}\n\n"
                return

            yield emit("info",  f"[*] Directory: {directory}")
            yield emit("info",  f"[*] Found {len(csv_files)} CSV file(s) to search")
            yield emit("info",  f"[*] Terms: {' | '.join(active_terms)}")
            yield emit("info",  f"[*] Mode: {'ANY (OR)' if mode == 'any' else 'ALL (AND)'}  |  {'Regex' if use_regex else 'Plain text'}")
            yield emit("cmd",   "[*] Searching...")

            results   = []
            files_hit = set()
            truncated = False

            for file_idx, fpath in enumerate(csv_files):
                if cancel_event.is_set():
                    yield emit("warn", "[!] Search cancelled by user.")
                    break

                fname = os.path.relpath(fpath, directory)

                # Progress update
                yield emit("progress", f"[{file_idx+1}/{len(csv_files)}] {fname}",
                           current=file_idx+1, total=len(csv_files))

                try:
                    with open(fpath, encoding="utf-8-sig", errors="replace") as f:
                        reader = csv.DictReader(f)
                        if not reader.fieldnames:
                            continue
                        for row_num, row in enumerate(reader, start=2):
                            if cancel_event.is_set():
                                break

                            row_text = " ".join(str(v) for v in row.values() if v)

                            if mode == "all":
                                matched = all(p.search(row_text) for p in patterns)
                            else:
                                matched = any(p.search(row_text) for p in patterns)

                            if matched:
                                matched_terms = [t for t, p in zip(active_terms, patterns) if p.search(row_text)]
                                results.append({
                                    "file":          fname,
                                    "row":           row_num,
                                    "matched_terms": matched_terms,
                                    "data":          dict(row),
                                })
                                files_hit.add(fname)

                                # Emit a match event for every hit so UI updates in real-time
                                yield emit("match", f"[HIT] {fname}:{row_num} — {', '.join(matched_terms)}")

                                if len(results) >= max_results:
                                    truncated = True
                                    break

                except Exception as ex:
                    yield emit("warn", f"[~] Could not read {fname}: {ex}")
                    continue

                if truncated:
                    yield emit("warn", f"[~] Result cap ({max_results:,}) reached — stopping early. Narrow your search.")
                    break

            # Final summary
            yield emit("done", f"[✓] Search complete — {len(results):,} match(es) across {len(files_hit)} file(s)")
            yield f"data: {json.dumps({'cls': 'complete', 'results': results, 'files_searched': len(csv_files), 'files_with_hits': len(files_hit), 'total_matches': len(results), 'truncated': truncated, 'cancelled': cancel_event.is_set()})}\n\n"

        finally:
            with _search_lock:
                _search_cancel.pop(search_id, None)

    return Response(generate(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

@sigma_bp.route("/csv-search/stop", methods=["POST"])
def csv_search_stop():
    """Cancel a running search by search_id."""
    search_id = (request.json or {}).get("search_id", "default")
    with _search_lock:
        event = _search_cancel.get(search_id)
    if event:
        event.set()
        return jsonify({"stopped": True})
    return jsonify({"stopped": False, "message": "No active search with that ID"})

@sigma_bp.route("/csv-search/export", methods=["POST"])
def csv_search_export():
    data    = request.json or {}
    results = data.get("results", [])
    if not results:
        return jsonify({"error": "no results to export"}), 400

    buf          = io.StringIO()
    data_cols    = []
    for r in results:
        for k in r.get("data", {}).keys():
            if k not in data_cols:
                data_cols.append(k)
    all_cols = ["file", "row", "matched_terms"] + data_cols

    writer = csv.DictWriter(buf, fieldnames=all_cols, extrasaction="ignore")
    writer.writeheader()
    for r in results:
        flat = {"file": r["file"], "row": r["row"],
                "matched_terms": ", ".join(r.get("matched_terms", []))}
        flat.update(r.get("data", {}))
        writer.writerow(flat)

    return Response(buf.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=search_results.csv"})

# ═══════════════════════════════════════════════════════════════════
# SAVED SEARCHES
# ═══════════════════════════════════════════════════════════════════

def _load_saved_searches():
    if os.path.isfile(SAVED_SEARCHES_FILE):
        try:
            return json.load(open(SAVED_SEARCHES_FILE, encoding="utf-8"))
        except Exception:
            pass
    return []

def _save_saved_searches(searches):
    os.makedirs(SIGMA_DIR, exist_ok=True)
    with open(SAVED_SEARCHES_FILE, "w", encoding="utf-8") as f:
        json.dump(searches, f, indent=2)

@sigma_bp.route("/csv-search/saved", methods=["GET"])
def get_saved_searches():
    return jsonify(_load_saved_searches())

@sigma_bp.route("/csv-search/saved", methods=["POST"])
def save_search():
    data = request.json or {}
    if not data.get("name"):
        return jsonify({"error": "name required"}), 400
    searches = [s for s in _load_saved_searches() if s.get("name") != data["name"]]
    searches.append({
        "name":      data["name"],
        "terms":     data.get("terms", []),
        "mode":      data.get("mode", "any"),
        "use_regex": data.get("use_regex", False),
        "directory": data.get("directory", ""),
        "created":   data.get("created", ""),
    })
    _save_saved_searches(searches)
    return jsonify({"saved": data["name"]})

@sigma_bp.route("/csv-search/saved/<name>", methods=["DELETE"])
def delete_saved_search(name):
    searches = [s for s in _load_saved_searches() if s.get("name") != name]
    _save_saved_searches(searches)
    return jsonify({"deleted": name})
