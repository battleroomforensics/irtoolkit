"""
YARA Module — two-tier rule storage

TIER 1 — Custom rules (data/rules.json)
  Hand-crafted or yarGen-generated rules stored as individual records.
  Compiled one at a time; each gets its needed imports prepended.

TIER 2 — Forge packages (data/yar/yara-forge-*.yar)
  Downloaded from YARA Forge as complete .yar files.
  Compiled as a SINGLE FILE — exactly how YARA Forge intends.
  Private rule dependencies, shared imports, cross-rule references all work.

Scans compile both tiers and merge matches.
"""

import os, json, re, threading
from flask import Blueprint, request, jsonify, Response

yara_bp   = Blueprint("yara", __name__)
BASE_DIR  = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR  = os.path.join(BASE_DIR, "data")
RULES_FILE = os.path.join(DATA_DIR, "rules.json")
YAR_DIR   = os.path.join(DATA_DIR, "yar")

_rules    = []   # custom rules
_next_id  = 1
_lock     = threading.Lock()

FORGE_PREFIX = "yara-forge-"   # files matching this are Forge packages

# ── Known real yara-python modules ────────────────────────────────────────────
KNOWN_YARA_MODULES = {"pe", "elf", "math", "hash", "dotnet", "macho", "cuckoo", "magic", "time"}
_IMPORT_RE = re.compile(r'^\s*import\s+"(\w+)"', re.MULTILINE)

# ── Persistence ───────────────────────────────────────────────────────────────
def _ensure_dirs():
    os.makedirs(DATA_DIR, exist_ok=True)
    os.makedirs(YAR_DIR,  exist_ok=True)

def _save():
    _ensure_dirs()
    with open(RULES_FILE, "w", encoding="utf-8") as f:
        json.dump({"next_id": _next_id, "rules": _rules}, f, indent=2)

def _get_forge_files():
    """Return full paths of all YARA Forge package files in data/yar/."""
    try:
        return [
            os.path.join(YAR_DIR, f)
            for f in sorted(os.listdir(YAR_DIR))
            if f.startswith(FORGE_PREFIX) and f.lower().endswith((".yar", ".yara"))
        ]
    except Exception:
        return []

def _load():
    global _rules, _next_id
    _ensure_dirs()
    loaded = []

    if os.path.isfile(RULES_FILE):
        try:
            data     = json.load(open(RULES_FILE, encoding="utf-8"))
            _rules   = data.get("rules", [])
            _next_id = data.get("next_id", max((r["id"] for r in _rules), default=0) + 1)
            loaded.append(f"rules.json ({len(_rules)} rules)")
        except Exception as e:
            print(f"[YARA] Warning: could not load rules.json: {e}")
            _rules, _next_id = [], 1

    # Import any .yar files in YAR_DIR that aren't Forge packages
    # (Forge packages are used directly; non-Forge .yar files are still parsed into records)
    existing_bodies = {r["body"].strip() for r in _rules}
    yar_imported = 0
    for fname in sorted(os.listdir(YAR_DIR)):
        if not fname.lower().endswith((".yar", ".yara")):
            continue
        if fname.startswith(FORGE_PREFIX):
            continue   # handled separately at compile time
        fpath = os.path.join(YAR_DIR, fname)
        try:
            text = open(fpath, encoding="utf-8", errors="replace").read()
            for rule in _parse_yar_text(text):
                if rule["body"].strip() not in existing_bodies:
                    rule["id"]   = _next_id
                    _next_id    += 1
                    _rules.append(rule)
                    existing_bodies.add(rule["body"].strip())
                    yar_imported += 1
        except Exception as e:
            print(f"[YARA] Warning: could not import {fname}: {e}")

    if yar_imported:
        loaded.append(f"data/yar/ ({yar_imported} rules)")
        _save()

    if not _rules:
        defaults = [
            {"name": "Detect_Mimikatz",       "tag": "credential-access", "sev": "high",
             "body": 'rule Detect_Mimikatz {\n  strings:\n    $s1 = "sekurlsa" ascii\n    $s2 = "lsadump" ascii\n  condition:\n    any of them\n}'},
            {"name": "Suspicious_PS_Download", "tag": "execution",         "sev": "high",
             "body": 'rule Suspicious_PS_Download {\n  strings:\n    $s1 = "DownloadString" ascii\n    $s2 = "-EncodedCommand" ascii\n  condition:\n    any of them\n}'},
            {"name": "Ransomware_Extension",   "tag": "impact",            "sev": "med",
             "body": 'rule Ransomware_Extension {\n  strings:\n    $e1 = ".locked" ascii\n    $e2 = ".encrypted" ascii\n  condition:\n    any of them\n}'},
        ]
        for d in defaults:
            d["id"]   = _next_id
            _next_id += 1
            _rules.append(d)
        _save()
        loaded.append("defaults")

    # Report Forge packages present
    forge_files = _get_forge_files()
    if forge_files:
        loaded.append(f"Forge packages: {[os.path.basename(f) for f in forge_files]}")

    print(f"[YARA] Loaded: {', '.join(loaded)}")
    print(f"[YARA] Custom rules: {len(_rules)}  |  Storage: {RULES_FILE}")

_load()

# ── YARA module availability ───────────────────────────────────────────────────
_yara_modules_cache = None

def _get_available_yara_modules():
    global _yara_modules_cache
    if _yara_modules_cache is not None:
        return _yara_modules_cache
    try:
        import yara
    except ImportError:
        _yara_modules_cache = set()
        return _yara_modules_cache
    probes = {
        "pe":     'import "pe"\nrule p{condition: pe.is_pe}',
        "elf":    'import "elf"\nrule p{condition: elf.type==elf.ET_EXEC}',
        "math":   'import "math"\nrule p{condition: math.entropy(0,filesize)>0}',
        "hash":   'import "hash"\nrule p{condition: hash.sha256(0,filesize)!=""}',
        "dotnet": 'import "dotnet"\nrule p{condition: dotnet.is_dotnet}',
        "macho":  'import "macho"\nrule p{condition: macho.magic==0xFEEDFACE}',
        "cuckoo": 'import "cuckoo"\nrule p{condition: cuckoo.network.http_get(/./)}',
        "magic":  'import "magic"\nrule p{condition: magic.type() contains "text"}',
        "time":   'import "time"\nrule p{condition: time.now()>0}',
    }
    available = set()
    for mod, probe in probes.items():
        try:
            yara.compile(source=probe)
            available.add(mod)
        except Exception:
            pass
    _yara_modules_cache = available
    print(f"[YARA] Available modules: {sorted(available)}")
    return available

# ── Custom rule compilation (individual records) ───────────────────────────────
_MOD_PAT       = '|'.join(sorted(KNOWN_YARA_MODULES))
_MODULE_USE_RE = re.compile(rf'\b({_MOD_PAT})\s*[\.\(]')

def _imports_needed(body):
    explicit = set(_IMPORT_RE.findall(body)) & KNOWN_YARA_MODULES
    implicit = set(_MODULE_USE_RE.findall(body))
    return explicit | implicit

def _with_imports(body, modules):
    if not modules:
        return body
    clean  = re.sub(r'^\s*import\s+"[^"]+"\s*\n?', '', body, flags=re.MULTILINE)
    header = "\n".join(f'import "{m}"' for m in sorted(modules))
    return header + "\n" + clean

def _compile_custom_rules(rule_ids=None):
    """
    Compile custom rules (from rules.json) individually.
    Each rule gets its needed import statements prepended.
    Returns (compiled, used_rules, skipped).
    """
    import yara

    with _lock:
        targets = _rules if not rule_ids else [r for r in _rules if r["id"] in rule_ids]
    if not targets:
        return None, [], []

    available = _get_available_yara_modules()
    good, skipped = [], []

    for rule in targets:
        needed   = _imports_needed(rule["body"])
        bad_mods = []
        for mod in _IMPORT_RE.findall(rule["body"]):
            if mod not in KNOWN_YARA_MODULES or mod not in available:
                bad_mods.append(mod)
        for mod in needed:
            if mod not in available and mod not in bad_mods:
                bad_mods.append(mod)
        if bad_mods:
            skipped.append({"name": rule["name"], "reason": f"requires: {', '.join(sorted(bad_mods))}"})
            continue
        source = _with_imports(rule["body"], needed)
        try:
            yara.compile(source=source)
            good.append((rule, needed))
        except Exception as e:
            skipped.append({"name": rule["name"], "reason": f"syntax: {str(e)[:100]}"})

    if not good:
        return None, [], skipped

    sources  = {rule["name"]: _with_imports(rule["body"], needed) for rule, needed in good}
    compiled = yara.compile(sources=sources)
    return compiled, [r for r, _ in good], skipped

def _compile_forge_files(forge_paths):
    """
    Compile YARA Forge package files as whole files — the only correct way.
    Each file is compiled with yara.compile(filepath=...) so all imports,
    private rules, and cross-rule references work exactly as intended.
    Returns list of (compiled_rules, filepath, rule_count).
    """
    import yara
    results = []
    for fpath in forge_paths:
        try:
            compiled = yara.compile(filepath=fpath)
            # Count rules by doing a dummy match — yara-python doesn't expose rule count directly
            # so we just track the file name
            results.append((compiled, fpath, os.path.basename(fpath)))
        except Exception as e:
            print(f"[YARA] Warning: could not compile {os.path.basename(fpath)}: {e}")
    return results

# ── Main compile entry point ───────────────────────────────────────────────────
def _compile_rules(rule_ids=None):
    """
    Compile all applicable rules:
      - Custom rules (rules.json) compiled individually with import injection
      - Forge packages compiled as whole files
    Returns (list_of_compiled_objects, used_rule_names, skipped_list).
    Each compiled object in the list is a yara.Rules instance.
    """
    try:
        import yara
    except ImportError:
        raise RuntimeError("yara-python not installed. Run: python setup.py")

    compiled_list = []
    all_used      = []
    all_skipped   = []

    # ── Custom rules ────────────────────────────────────────────────────────
    # If rule_ids specified, only include custom rules whose ids match
    custom_ids = None
    if rule_ids is not None:
        rule_id_set = set(rule_ids)
        with _lock:
            custom_ids = [r["id"] for r in _rules if r["id"] in rule_id_set]

    compiled_custom, used_custom, skipped_custom = _compile_custom_rules(custom_ids)
    if compiled_custom:
        compiled_list.append(compiled_custom)
        all_used.extend([r["name"] for r in used_custom])
    all_skipped.extend(skipped_custom)

    # ── Forge packages (only when scanning all rules, not a specific selection) ──
    if rule_ids is None:
        forge_paths = _get_forge_files()
        if forge_paths:
            forge_results = _compile_forge_files(forge_paths)
            for compiled, fpath, fname in forge_results:
                compiled_list.append(compiled)
                all_used.append(f"[{fname}]")

    if not compiled_list:
        if all_skipped:
            raise ValueError(f"All {len(all_skipped)} rules failed to compile.")
        raise ValueError("No rules to compile.")

    return compiled_list, all_used, all_skipped

# ── Scan ───────────────────────────────────────────────────────────────────────
@yara_bp.route("/scan", methods=["POST"])
def scan():
    data        = request.json or {}
    target_path = data.get("path", "").strip()
    recursive   = bool(data.get("recursive", True))
    timeout_sec = int(data.get("timeout", 0))
    rule_ids    = data.get("rule_ids") or None

    if not target_path:
        return jsonify({"error": "path required"}), 400
    if not os.path.exists(target_path):
        return jsonify({"error": f"Path not found: {target_path}"}), 404

    def generate():
        def emit(cls, text):
            return f"data: {json.dumps({'cls': cls, 'text': text})}\n\n"

        try:
            compiled_list, used_names, skipped = _compile_rules(rule_ids)
        except Exception as e:
            yield emit("error", f"[!] Failed to compile rules: {e}")
            yield emit("done",  "[!] Scan aborted.")
            return

        # Summarise what was loaded
        custom_count = sum(1 for n in used_names if not n.startswith("["))
        forge_names  = [n for n in used_names if n.startswith("[")]
        yield emit("info", f"[*] Target: {target_path}")
        if custom_count:
            yield emit("info", f"[*] Custom rules: {custom_count}")
        for fn in forge_names:
            yield emit("info", f"[*] Forge package: {fn}")
        if skipped:
            yield emit("warn",
                f"[~] Skipped {len(skipped)} custom rule(s) (module unavailable or syntax error)")
            for s in skipped[:5]:
                yield emit("warn", f"    {s['name']}: {s['reason']}")
            if len(skipped) > 5:
                yield emit("warn", f"    ... and {len(skipped)-5} more")
        yield emit("info", f"[*] Recursive: {recursive}")
        if timeout_sec:
            yield emit("info", f"[*] Timeout: {timeout_sec}s per file")
        yield emit("cmd", "[*] Starting scan...")

        # Build file list
        if os.path.isfile(target_path):
            files_to_scan = [target_path]
        elif recursive:
            files_to_scan = [
                os.path.join(root, fname)
                for root, _, files in os.walk(target_path)
                for fname in files
            ]
        else:
            files_to_scan = [
                os.path.join(target_path, f)
                for f in os.listdir(target_path)
                if os.path.isfile(os.path.join(target_path, f))
            ]

        yield emit("info", f"[*] Files to scan: {len(files_to_scan)}")

        match_count = error_count = scanned = 0

        for fpath in files_to_scan:
            scanned += 1
            for compiled in compiled_list:
                try:
                    kwargs = {"filepath": fpath}
                    if timeout_sec:
                        kwargs["timeout"] = timeout_sec
                    matches = compiled.match(**kwargs)
                    for m in matches:
                        match_count += 1
                        yield emit("match", f"[MATCH] {m.rule}  {fpath}")
                except Exception as e:
                    err = str(e)
                    error_count += 1
                    if "timeout" in err.lower():
                        yield emit("warn", f"[TIMEOUT] {fpath}")
                    elif "permission" not in err.lower():
                        yield emit("warn", f"[ERROR] {fpath}: {err[:80]}")
                    break  # don't repeat same file error for each compiled object

            if scanned % 50 == 0:
                yield emit("info", f"[*] Progress: {scanned}/{len(files_to_scan)} files...")

        yield emit("info",  f"[*] Scan complete — {scanned} files scanned")
        yield emit("done",  f"[+] {match_count} match(es) found, {error_count} error(s)")

    return Response(generate(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

# ── CRUD ───────────────────────────────────────────────────────────────────────
@yara_bp.route("/rules", methods=["GET"])
def get_rules():
    forge_files = _get_forge_files()
    forge_info  = [
        {
            "id":     f"forge:{os.path.basename(fp)}",
            "name":   os.path.basename(fp).replace(".yar","").replace(FORGE_PREFIX,"Forge: "),
            "tag":    "forge",
            "sev":    "med",
            "body":   "",
            "source": f"forge:{os.path.basename(fp)}",
            "is_forge_package": True,
            "path":   fp,
        }
        for fp in forge_files
    ]
    return jsonify(_rules + forge_info)

@yara_bp.route("/rules", methods=["POST"])
def add_rule():
    global _next_id
    data = request.json
    if not data.get("name") or not data.get("body"):
        return jsonify({"error": "name and body required"}), 400
    with _lock:
        rule = {
            "id":   _next_id,
            "name": data["name"].strip(),
            "tag":  data.get("tag", "general").strip(),
            "sev":  data.get("sev", "med"),
            "body": data["body"].strip(),
        }
        _rules.append(rule)
        _next_id += 1
        _save()
    return jsonify(rule), 201

@yara_bp.route("/rules/<int:rule_id>", methods=["PUT"])
def update_rule(rule_id):
    data = request.json
    with _lock:
        rule = next((r for r in _rules if r["id"] == rule_id), None)
        if not rule:
            return jsonify({"error": "not found"}), 404
        for field in ("name", "tag", "sev", "body"):
            if field in data:
                rule[field] = data[field]
        _save()
    return jsonify(rule)

@yara_bp.route("/rules/<int:rule_id>", methods=["DELETE"])
def delete_rule(rule_id):
    global _rules
    with _lock:
        before = len(_rules)
        _rules = [r for r in _rules if r["id"] != rule_id]
        if len(_rules) == before:
            return jsonify({"error": "not found"}), 404
        _save()
    return jsonify({"deleted": rule_id})

# ── Import .yar files ──────────────────────────────────────────────────────────
@yara_bp.route("/import", methods=["POST"])
def import_yar():
    global _next_id
    files = request.files.getlist("files")
    if not files:
        return jsonify({"error": "no files uploaded"}), 400
    imported, errors = [], []
    with _lock:
        existing_bodies = {r["body"].strip() for r in _rules}
        for f in files:
            try:
                text   = f.read().decode("utf-8", errors="replace")
                parsed = _parse_yar_text(text)
                for rule in parsed:
                    if rule["body"].strip() in existing_bodies:
                        continue
                    rule["id"]   = _next_id
                    _next_id    += 1
                    _rules.append(rule)
                    existing_bodies.add(rule["body"].strip())
                    imported.append(rule)
            except Exception as e:
                errors.append({"file": f.filename, "error": str(e)})
        if imported:
            _save()
    return jsonify({"imported": len(imported), "rules": imported, "errors": errors})

def _parse_yar_text(text):
    """Parse individual rule blocks from a .yar file for custom rule storage."""
    found   = []
    pattern = re.compile(r'(?:^|\n)\s*(?:private\s+)?rule\s+(\w+)\s*(?::[^{]*)?\{', re.MULTILINE)
    file_imports = set(re.findall(r'^\s*import\s+"(\w+)"', text, re.MULTILINE))

    for m in pattern.finditer(text):
        name        = m.group(1)
        brace_start = text.index('{', m.start())
        depth = 0; i = brace_start; n = len(text)
        while i < n:
            ch = text[i]
            if ch == '"':
                i += 1
                while i < n:
                    if text[i] == '\\': i += 2; continue
                    if text[i] == '"': break
                    i += 1
            elif ch == '{': depth += 1
            elif ch == '}':
                depth -= 1
                if depth == 0: break
            i += 1
        body = text[m.start() if text[m.start()] != '\n' else m.start()+1 : i+1].strip()
        if not body:
            continue
        body_imports   = set(re.findall(r'^\s*import\s+"(\w+)"', body, re.MULTILINE))
        needed_imports = file_imports - body_imports
        if needed_imports:
            header = "\n".join(f'import "{imp}"' for imp in sorted(needed_imports))
            body   = header + "\n" + body
        sev = "med"
        if re.search(r'severity\s*=\s*"high"', body, re.I): sev = "high"
        elif re.search(r'severity\s*=\s*"low"', body, re.I): sev = "low"
        tag = "imported"
        tm  = re.search(r'(?:category|type|tag)\s*=\s*"([^"]+)"', body, re.I)
        if tm: tag = tm.group(1)
        found.append({"name": name, "tag": tag, "sev": sev, "body": body})
    return found

# ── Storage info & module info ─────────────────────────────────────────────────
@yara_bp.route("/storage-info", methods=["GET"])
def storage_info():
    forge_files = _get_forge_files()
    return jsonify({
        "rules_file":   RULES_FILE,
        "yar_dir":      YAR_DIR,
        "rule_count":   len(_rules),
        "forge_files":  [os.path.basename(f) for f in forge_files],
    })

@yara_bp.route("/modules", methods=["GET"])
def yara_modules():
    available = _get_available_yara_modules()
    all_known = list(KNOWN_YARA_MODULES)
    return jsonify({
        "available":   sorted(available),
        "unavailable": sorted(set(all_known) - available),
        "note": "Forge packages are compiled as whole files and use all modules automatically."
    })

# ── Export ─────────────────────────────────────────────────────────────────────
@yara_bp.route("/export", methods=["GET"])
def export_rules():
    with _lock:
        content = "\n\n".join(r["body"] for r in _rules)
    return Response(content, mimetype="text/plain",
                    headers={"Content-Disposition": "attachment; filename=ir_toolkit_rules.yar"})

# ═══════════════════════════════════════════════════════════════════════════════
# YARA FORGE UPDATE SYSTEM
# ═══════════════════════════════════════════════════════════════════════════════
import urllib.request, urllib.error, zipfile, io

FORGE_API       = "https://api.github.com/repos/YARAHQ/yara-forge/releases/latest"
FORGE_META_FILE = os.path.join(DATA_DIR, "yara_forge_meta.json")

FORGE_PKG_KEYWORDS = {
    "core":     ["core"],
    "extended": ["extended"],
    "full":     ["full"],
}
FORGE_YAR_KEYWORDS = {"core": "core", "extended": "extended", "full": "full"}

def _load_forge_meta():
    if os.path.isfile(FORGE_META_FILE):
        try:
            return json.load(open(FORGE_META_FILE))
        except Exception:
            pass
    return {}

def _save_forge_meta(meta):
    _ensure_dirs()
    with open(FORGE_META_FILE, "w") as f:
        json.dump(meta, f, indent=2)

def _github_get(url):
    req = urllib.request.Request(url, headers={"User-Agent": "IR-Toolkit/1.0"})
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode())

def _find_asset(assets_dict, pkg):
    keywords = FORGE_PKG_KEYWORDS.get(pkg, [pkg])
    candidates = [
        (name, url) for name, url in assets_dict.items()
        if any(kw in name.lower() for kw in keywords) and name.lower().endswith(".zip")
    ]
    if not candidates:
        candidates = [
            (name, url) for name, url in assets_dict.items()
            if any(kw in name.lower() for kw in keywords)
        ]
    return candidates[0] if candidates else (None, None)

@yara_bp.route("/forge/status", methods=["GET"])
def forge_status():
    try:
        release = _github_get(FORGE_API)
    except Exception as e:
        return jsonify({"error": f"Could not reach GitHub API: {e}"}), 503

    latest_tag  = release.get("tag_name", "")
    latest_date = release.get("published_at", "")[:10]
    assets      = {a["name"]: a["browser_download_url"] for a in release.get("assets", [])}
    print(f"[YARA Forge] Release: {latest_tag}  |  Assets: {list(assets.keys())}")

    meta      = _load_forge_meta()
    installed = meta.get("installed", {})
    packages  = {}
    for pkg in ("core", "extended", "full"):
        fname, url = _find_asset(assets, pkg)
        saved_path = os.path.join(YAR_DIR, f"{FORGE_PREFIX}{pkg}.yar")
        packages[pkg] = {
            "available":      latest_tag,
            "available_date": latest_date,
            "installed":      installed.get(pkg),
            "update_ready":   installed.get(pkg) != latest_tag,
            "download_url":   url or "",
            "asset_name":     fname or "",
            "rule_count":     meta.get("rule_counts", {}).get(pkg),
            "saved_path":     saved_path if os.path.isfile(saved_path) else "",
        }

    return jsonify({
        "latest_tag":    latest_tag,
        "latest_date":   latest_date,
        "packages":      packages,
        "release_url":   release.get("html_url", ""),
        "release_notes": _parse_forge_counts(release.get("body", "")),
        "all_assets":    list(assets.keys()),
    })

def _parse_forge_counts(body):
    counts = {}
    for pkg in ("core", "extended", "full"):
        m = re.search(rf'\|\s*{pkg}\s*\|\s*(\d+)', body, re.IGNORECASE)
        if m:
            counts[pkg] = int(m.group(1))
    return counts

@yara_bp.route("/forge/update", methods=["POST"])
def forge_update():
    """
    Download a YARA Forge package ZIP, extract the .yar file, save it to
    data/yar/yara-forge-{package}.yar  and verify it compiles cleanly.
    The file is compiled as a whole unit — no rule splitting at all.
    """
    data         = request.json or {}
    package      = data.get("package", "core")
    download_url = data.get("download_url", "")
    if not download_url:
        return jsonify({"error": "download_url required"}), 400

    def generate():
        def emit(cls, text):
            return f"data: {json.dumps({'cls': cls, 'text': text})}\n\n"

        import re as _re

        yield emit("info", f"[*] Package: YARA Forge — {package}")
        yield emit("info", f"[*] URL: {download_url}")
        yield emit("cmd",  "[*] Downloading...")

        try:
            req = urllib.request.Request(download_url,
                      headers={"User-Agent": "IR-Toolkit/1.0", "Accept": "application/octet-stream"})
            with urllib.request.urlopen(req, timeout=180) as resp:
                final_url    = resp.geturl()
                content_type = resp.headers.get("Content-Type", "")
                zip_bytes    = resp.read()
        except Exception as e:
            yield emit("error", f"[!] Download failed: {e}")
            return

        size_mb = len(zip_bytes) / 1048576
        yield emit("info", f"[+] Downloaded {size_mb:.1f} MB  (Content-Type: {content_type})")

        if size_mb < 0.5:
            yield emit("warn", f"[~] File is only {size_mb:.2f} MB — may be wrong content")
            preview = zip_bytes[:200].decode("utf-8", errors="replace").replace("\n", " ")
            yield emit("warn", f"[~] Preview: {preview}")

        if b"<!DOCTYPE" in zip_bytes[:100] or b"<html" in zip_bytes[:200].lower():
            yield emit("error", "[!] Got HTML instead of a ZIP. Try clicking 'Refresh' to get a fresh URL.")
            return

        if zip_bytes[:4] != b"PK\x03\x04":
            yield emit("error", f"[!] Not a valid ZIP (magic: {zip_bytes[:4].hex()})")
            yield emit("info",  "[*] Content: " + zip_bytes[:200].decode("utf-8", errors="replace")[:200])
            return

        # Extract .yar from ZIP
        yar_keyword = FORGE_YAR_KEYWORDS.get(package, package)
        try:
            with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
                names = zf.namelist()
                yield emit("info", f"[*] ZIP contents: {', '.join(names)}")
                yar_match = next(
                    (n for n in names if yar_keyword in n.lower() and n.lower().endswith(".yar")),
                    next((n for n in names if n.lower().endswith(".yar")), None)
                )
                if not yar_match:
                    yield emit("error", f"[!] No .yar file found in ZIP")
                    return
                yield emit("info", f"[*] Extracting: {yar_match}")
                yar_bytes = zf.read(yar_match)
                yar_text  = yar_bytes.decode("utf-8", errors="replace")
        except zipfile.BadZipFile:
            yield emit("error", "[!] Not a valid ZIP archive.")
            return
        except Exception as e:
            yield emit("error", f"[!] Extraction failed: {e}")
            return

        yield emit("info", f"[+] Extracted {yar_match} ({len(yar_bytes)//1024:,} KB)")

        # Save to data/yar/
        _ensure_dirs()
        save_path = os.path.join(YAR_DIR, f"{FORGE_PREFIX}{package}.yar")
        try:
            with open(save_path, "w", encoding="utf-8") as f:
                f.write(yar_text)
            yield emit("info", f"[+] Saved to: {save_path}")
        except Exception as e:
            yield emit("error", f"[!] Could not save file: {e}")
            return

        # Verify it compiles as a whole file
        yield emit("cmd", "[*] Verifying package compiles correctly...")
        try:
            import yara
            compiled = yara.compile(filepath=save_path)
            yield emit("done", f"[✓] Package compiled successfully")
        except Exception as e:
            yield emit("warn", f"[~] Compilation warning: {e}")
            yield emit("info", "[*] File saved — will attempt to use at scan time")

        # Count rules in the file (rough count from pattern matches)
        rule_count = len(re.findall(r'^\s*(?:private\s+)?rule\s+\w+', yar_text, re.MULTILINE))
        yield emit("info", f"[*] Package contains ~{rule_count:,} rules")

        # Persist metadata
        url_tag = _re.search(r'/download/(\w+)/', download_url)
        tag_match = _re.search(r'Creation Date:\s*(\S+)', yar_text)
        release_tag = (url_tag.group(1) if url_tag else
                       tag_match.group(1) if tag_match else "unknown")

        meta = _load_forge_meta()
        meta.setdefault("installed",   {})[package] = release_tag
        meta.setdefault("rule_counts", {})[package] = rule_count
        meta.setdefault("saved_paths", {})[package] = save_path
        _save_forge_meta(meta)

        yield emit("done", f"[✓] YARA Forge {package} ({release_tag}) ready — {rule_count:,} rules")
        yield emit("done", f"[✓] File saved to: {save_path}")
        yield f"data: {json.dumps({'cls':'complete','package':package,'tag':release_tag,'count':rule_count})}\n\n"

    return Response(generate(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
