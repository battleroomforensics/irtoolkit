"""
Artifact Parser Module
- Checks which Zimmerman tools are present in the specified directory
- Downloads missing tools via Get-ZimmermanTools.ps1 (PowerShell, Windows)
- Runs tools directly via subprocess — no script download needed
- Streams live output back to the UI via SSE
"""

import os, json, subprocess, sys, threading, re, tempfile, shutil, urllib.request
from flask import Blueprint, request, jsonify, Response
from datetime import date

artifact_bp = Blueprint("artifact", __name__)

# ── Tool definitions ───────────────────────────────────────────────────────────
# Each tool has:
#   exe       — relative path under the tools dir
#   default   — whether enabled by default
#   finder    — function(collection_path) -> list of artifact paths to process
#   runner    — function(exe_path, artifact_path, output_dir) -> list of cmd args
TOOLS = [
    {
        "id": "mftecmd", "name": "MFTECmd", "default_on": True,
        "desc": "NTFS MFT, USN Journal ($J), $Boot, $SDS",
        "artifacts": "$MFT, $J, $Boot, $SDS",
        "exe": "MFTECmd.exe",
        "multi_artifact": True,
        "artifact_patterns": [
            {"filter": "$MFT",   "flag": "-f", "csvf": "MFTECmd_MFT.csv"},
            {"filter": "$J",     "flag": "-f", "csvf": "MFTECmd_UsnJrnl.csv"},
            {"filter": "$Boot",  "flag": "-f", "csvf": "MFTECmd_Boot.csv"},
            {"filter": "$SDS",   "flag": "-f", "csvf": "MFTECmd_SDS.csv"},
        ],
    },
    {
        "id": "evtxecmd", "name": "EvtxECmd", "default_on": True,
        "desc": "Windows Event Logs (.evtx)",
        "artifacts": "*.evtx",
        "exe": os.path.join("EvtxECmd", "EvtxECmd.exe"),
        "dir_mode": True,   # runs against a directory
        "dir_names": ["Logs", "EventLogs"],
        "ext": ".evtx",
        "csvf": "EvtxECmd_Events.csv",
    },
    {
        "id": "lecmd", "name": "LECmd", "default_on": True,
        "desc": "LNK shortcut files",
        "artifacts": "*.lnk",
        "exe": "LECmd.exe",
        "dir_mode": True,
        "ext": ".lnk",
        "csvf": "LECmd_LNK.csv",
    },
    {
        "id": "jlecmd", "name": "JLECmd", "default_on": True,
        "desc": "Jump Lists",
        "artifacts": "*.automaticDestinations-ms",
        "exe": "JLECmd.exe",
        "dir_mode": True,
        "ext": ".automaticDestinations-ms",
        "csvf": "JLECmd_JumpLists.csv",
    },
    {
        "id": "pecmd", "name": "PECmd", "default_on": True,
        "desc": "Prefetch files",
        "artifacts": "*.pf",
        "exe": "PECmd.exe",
        "dir_mode": True,
        "dir_names": ["Prefetch"],
        "ext": ".pf",
        "csvf": "PECmd_Prefetch.csv",
    },
    {
        "id": "sbecmd", "name": "SBECmd", "default_on": True,
        "desc": "Shell Bags (folder access history)",
        "artifacts": "NTUSER.DAT, UsrClass.dat",
        "exe": "SBECmd.exe",
        "dir_mode": True,
        "csvf": "SBECmd_ShellBags.csv",
    },
    {
        "id": "srumecmd", "name": "SrumECmd", "default_on": True,
        "desc": "SRUM — network, CPU, app resource usage",
        "artifacts": "SRUDB.dat",
        "exe": "SrumECmd.exe",
        "single_file": True,
        "file_names": ["SRUDB.dat"],
        "csvf": "SrumECmd",
    },
    {
        "id": "recmd", "name": "RECmd", "default_on": False,
        "desc": "Registry hives (SAM, SYSTEM, SOFTWARE, NTUSER.DAT)",
        "artifacts": "SAM, SYSTEM, SOFTWARE, SECURITY, NTUSER.DAT",
        "exe": "RECmd.exe",
        "registry_mode": True,
        "hive_names": ["SAM", "SYSTEM", "SOFTWARE", "SECURITY", "NTUSER.DAT", "UsrClass.dat"],
    },
    {
        "id": "appcompat", "name": "AppCompatCacheParser", "default_on": False,
        "desc": "Shimcache (from SYSTEM hive)",
        "artifacts": "SYSTEM hive",
        "exe": "AppCompatCacheParser.exe",
        "single_file": True,
        "file_names": ["SYSTEM"],
        "csvf": "AppCompat_Shimcache.csv",
    },
    {
        "id": "amcache", "name": "AmcacheParser", "default_on": False,
        "desc": "Amcache.hve (file execution history)",
        "artifacts": "Amcache.hve",
        "exe": "AmcacheParser.exe",
        "single_file": True,
        "file_names": ["Amcache.hve"],
        "csvf": "AmcacheParser.csv",
    },
    {
        "id": "rbcmd", "name": "RBCmd", "default_on": False,
        "desc": "Recycle Bin $I metadata",
        "artifacts": "$I* files",
        "exe": "RBCmd.exe",
        "dir_mode": True,
        "prefix": "$I",
        "csvf": "RBCmd_RecycleBin.csv",
    },
    {
        "id": "recentfilecache", "name": "RecentFileCacheParser", "default_on": False,
        "desc": "RecentFileCache.bcf (legacy, pre-Win8)",
        "artifacts": "RecentFileCache.bcf",
        "exe": "RecentFileCacheParser.exe",
        "single_file": True,
        "file_names": ["RecentFileCache.bcf"],
        "csvf": "RecentFileCache.csv",
    },
    {
        "id": "sqlecmd", "name": "SQLECmd", "default_on": False,
        "desc": "SQLite databases (browser history, ESE, etc.)",
        "artifacts": "*.db, *.sqlite",
        "exe": os.path.join("SQLECmd", "SQLECmd.exe"),
        "dir_mode": True,
        "csvf": "SQLECmd",
    },
    {
        "id": "wxtcmd", "name": "WxTCmd", "default_on": False,
        "desc": "Windows 10/11 Timeline (ActivitiesCache.db)",
        "artifacts": "ActivitiesCache.db",
        "exe": "WxTCmd.exe",
        "single_file": True,
        "file_names": ["ActivitiesCache.db"],
        "csvf": "WxTCmd",
    },
    {
        "id": "bstrings", "name": "bstrings", "default_on": False,
        "desc": "String search across files",
        "artifacts": "any file",
        "exe": "bstrings.exe",
        "dir_mode": True,
        "csvf": "bstrings",
    },
]

TOOL_MAP = {t["id"]: t for t in TOOLS}

# ── Tool list endpoint ────────────────────────────────────────────────────────
@artifact_bp.route("/tools", methods=["GET"])
def get_tools():
    return jsonify([{k: v for k, v in t.items()
                     if k not in ("finder", "runner")} for t in TOOLS])

# ── Check which tools exist at the given directory ────────────────────────────
@artifact_bp.route("/check-tools", methods=["POST"])
def check_tools():
    data      = request.json or {}
    tools_dir = data.get("tools_dir", "").strip()
    if not tools_dir:
        return jsonify({"error": "tools_dir required"}), 400

    results = {}
    for t in TOOLS:
        exe_path = os.path.join(tools_dir, t["exe"])
        results[t["id"]] = {
            "found":    os.path.isfile(exe_path),
            "path":     exe_path,
            "exe":      t["exe"],
        }
    return jsonify({
        "results":    results,
        "tools_dir":  tools_dir,
        "all_found":  all(v["found"] for v in results.values()),
        "any_missing": any(not v["found"] for v in results.values()),
    })

# ── Auto-download Zimmerman tools ─────────────────────────────────────────────
@artifact_bp.route("/download-tools", methods=["POST"])
def download_tools():
    """
    Download Zimmerman tools using Get-ZimmermanTools.ps1 from GitHub.
    Streams SSE progress. Works on Windows (PowerShell) only.
    POST body: { "tools_dir": "C:\\Tools\\ZimmermanTools" }
    """
    data      = request.json or {}
    tools_dir = data.get("tools_dir", "").strip()
    if not tools_dir:
        return jsonify({"error": "tools_dir required"}), 400

    def generate():
        def emit(cls, text):
            return f"data: {json.dumps({'cls': cls, 'text': text})}\n\n"

        if sys.platform != "win32":
            yield emit("error", "[!] Tool auto-download requires Windows (uses PowerShell).")
            yield emit("info",  "[*] On Linux/Mac: install YARA tools manually or use Wine.")
            return

        os.makedirs(tools_dir, exist_ok=True)
        yield emit("info",  f"[*] Tools directory: {tools_dir}")

        # Download Get-ZimmermanTools.ps1
        script_url  = "https://raw.githubusercontent.com/EricZimmerman/Get-ZimmermanTools/master/Get-ZimmermanTools.ps1"
        script_path = os.path.join(tools_dir, "Get-ZimmermanTools.ps1")

        yield emit("cmd", "[*] Downloading Get-ZimmermanTools.ps1...")
        try:
            req = urllib.request.Request(script_url, headers={"User-Agent": "IR-Toolkit/1.0"})
            with urllib.request.urlopen(req, timeout=30) as resp:
                script_content = resp.read()
            with open(script_path, "wb") as f:
                f.write(script_content)
            yield emit("info", f"[+] Script saved to: {script_path}")
        except Exception as e:
            yield emit("error", f"[!] Failed to download script: {e}")
            return

        # Run it via PowerShell
        yield emit("cmd", f"[*] Running Get-ZimmermanTools.ps1 -Dest \"{tools_dir}\" ...")
        yield emit("info", "[*] This may take several minutes depending on your connection...")

        cmd = [
            "powershell.exe",
            "-ExecutionPolicy", "Bypass",
            "-File", script_path,
            "-Dest", tools_dir,
        ]

        try:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                cwd=tools_dir,
            )
            for line in proc.stdout:
                line = line.rstrip()
                if not line:
                    continue
                cls = "done"  if "complete" in line.lower() or "success" in line.lower() else \
                      "error" if "error"    in line.lower() or "fail"    in line.lower() else \
                      "warn"  if "warn"     in line.lower() or "skip"    in line.lower() else \
                      "info"
                yield emit(cls, line)
            proc.wait(timeout=600)
        except subprocess.TimeoutExpired:
            yield emit("error", "[!] Download timed out after 10 minutes.")
            return
        except Exception as e:
            yield emit("error", f"[!] Error running PowerShell: {e}")
            return

        # Re-check what's present
        found = [t["name"] for t in TOOLS if os.path.isfile(os.path.join(tools_dir, t["exe"]))]
        missing = [t["name"] for t in TOOLS if not os.path.isfile(os.path.join(tools_dir, t["exe"]))]

        yield emit("done", f"[✓] Tools available: {len(found)}")
        if missing:
            yield emit("warn", f"[~] Still missing: {', '.join(missing)}")
        yield f"data: {json.dumps({'cls': 'complete', 'found': found, 'missing': missing})}\n\n"

    return Response(generate(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

# ── Run tools directly ─────────────────────────────────────────────────────────
@artifact_bp.route("/run", methods=["POST"])
def run_tools():
    """
    Run selected Zimmerman tools against the collection path.
    Streams SSE progress with live tool output.
    POST body:
      tools_dir       — where Zimmerman tools are installed
      collection_path — input folder from CyLR/collection
      output_path     — where to write CSV output
      enabled_tools   — list of tool IDs to run (all enabled by default)
    """
    data            = request.json or {}
    tools_dir       = data.get("tools_dir", "").strip()
    collection_path = data.get("collection_path", "").strip()
    output_path     = data.get("output_path", "").strip()
    enabled_ids     = data.get("enabled_tools") or [t["id"] for t in TOOLS if t["default_on"]]

    if not tools_dir:
        return jsonify({"error": "tools_dir required"}), 400
    if not collection_path:
        return jsonify({"error": "collection_path required"}), 400
    if not output_path:
        return jsonify({"error": "output_path required"}), 400

    if not os.path.isdir(collection_path):
        return jsonify({"error": f"Collection path not found: {collection_path}"}), 400

    def generate():
        def emit(cls, text):
            return f"data: {json.dumps({'cls': cls, 'text': text})}\n\n"

        os.makedirs(output_path, exist_ok=True)
        yield emit("info",  f"[*] Collection: {collection_path}")
        yield emit("info",  f"[*] Output:     {output_path}")
        yield emit("info",  f"[*] Tools:      {tools_dir}")
        yield emit("info",  f"[*] Running {len(enabled_ids)} tool(s)...")
        yield emit("cmd",   "[*] Starting artifact parsing...")

        total_csvs = 0

        for tool_id in enabled_ids:
            tool = TOOL_MAP.get(tool_id)
            if not tool:
                continue

            exe_path = os.path.join(tools_dir, tool["exe"])
            if not os.path.isfile(exe_path):
                yield emit("warn", f"[~] {tool['name']}: not found at {exe_path} — skipping")
                continue

            yield emit("info", f"\n[*] ── {tool['name']} ──")

            # Build and run commands for this tool
            cmds = _build_commands(tool, exe_path, collection_path, output_path)
            if not cmds:
                yield emit("warn", f"[~] {tool['name']}: no matching artifacts found in {collection_path}")
                continue

            for cmd, label in cmds:
                yield emit("cmd", f"[>] {' '.join(cmd)}")
                try:
                    proc = subprocess.Popen(
                        cmd,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT,
                        text=True,
                        cwd=tools_dir,
                    )
                    for line in proc.stdout:
                        line = line.rstrip()
                        if not line:
                            continue
                        cls = "match" if "match" in line.lower() or "found" in line.lower() else \
                              "warn"  if "error" in line.lower() or "warn"  in line.lower() else \
                              "done"  if "written" in line.lower() or "processed" in line.lower() or "complete" in line.lower() else \
                              "info"
                        yield emit(cls, f"  {line}")
                    proc.wait(timeout=300)
                    if proc.returncode not in (0, 1):
                        yield emit("warn", f"  [~] Exited with code {proc.returncode}")
                except subprocess.TimeoutExpired:
                    yield emit("warn", f"  [~] {tool['name']} timed out (5 min)")
                    proc.kill()
                except Exception as e:
                    yield emit("error", f"  [!] Error running {tool['name']}: {e}")

            yield emit("done", f"[+] {tool['name']} complete")

        # Count output CSVs
        try:
            csvs = [f for f in os.listdir(output_path) if f.lower().endswith(".csv")]
            total_csvs = len(csvs)
        except Exception:
            pass

        yield emit("done",  f"\n[✓] Parsing complete — {total_csvs} CSV file(s) written to:")
        yield emit("done",  f"    {output_path}")
        yield f"data: {json.dumps({'cls': 'complete', 'output_path': output_path, 'csv_count': total_csvs})}\n\n"

    return Response(generate(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

def _find_files(root, names=None, ext=None, prefix=None, recursive=True):
    """Walk root and find files matching name list, extension, or prefix."""
    matches = []
    walk = os.walk(root) if recursive else [(root, [], os.listdir(root))]
    for dirpath, dirs, files in walk:
        for fname in files:
            fpath = os.path.join(dirpath, fname)
            if names and fname in names:
                matches.append(fpath)
            elif ext and fname.lower().endswith(ext.lower()):
                matches.append(fpath)
            elif prefix and fname.startswith(prefix):
                matches.append(fpath)
    return matches

def _find_dirs(root, names, recursive=True):
    """Find directories with given names under root."""
    matches = []
    walk = os.walk(root) if recursive else [(root, os.listdir(root), [])]
    for dirpath, dirs, files in walk:
        for d in dirs:
            if d in names:
                matches.append(os.path.join(dirpath, d))
    return matches

def _build_commands(tool, exe_path, collection_path, output_path):
    """
    Build the subprocess command list(s) for a tool.
    Returns list of (cmd_list, label) tuples.
    """
    cmds = []

    # ── MFTECmd — multiple individual files ────────────────────────────────
    if tool.get("multi_artifact"):
        for pattern in tool["artifact_patterns"]:
            found = _find_files(collection_path, names=[pattern["filter"]])
            for fpath in found:
                cmd = [exe_path, "-f", fpath, "--csv", output_path, "--csvf", pattern["csvf"]]
                cmds.append((cmd, f"{tool['name']} → {os.path.basename(fpath)}"))
        return cmds

    # ── SrumECmd — needs SRUDB.dat + optional SOFTWARE hive ───────────────
    if tool["id"] == "srumecmd":
        srum_files = _find_files(collection_path, names=["SRUDB.dat"])
        if not srum_files:
            return []
        sw_files = _find_files(collection_path, names=["SOFTWARE"])
        sw_files = [f for f in sw_files if not os.path.isdir(f)]
        for srum in srum_files:
            cmd = [exe_path, "-f", srum, "--csv", output_path]
            if sw_files:
                cmd += ["-r", sw_files[0]]
            cmds.append((cmd, f"SrumECmd → {os.path.basename(srum)}"))
        return cmds

    # ── RECmd — registry hives ─────────────────────────────────────────────
    if tool.get("registry_mode"):
        hive_names = tool.get("hive_names", [])
        hive_files = _find_files(collection_path, names=hive_names)
        hive_files = [f for f in hive_files if not os.path.isdir(f)]
        # Try to find batch scripts
        batch_dir  = os.path.join(os.path.dirname(exe_path), "BatchExamples")
        batch_file = None
        if os.path.isdir(batch_dir):
            for fname in os.listdir(batch_dir):
                if fname.lower().endswith(".reb"):
                    batch_file = os.path.join(batch_dir, fname)
                    break
        for hive in hive_files:
            cmd = [exe_path, "-f", hive, "--csv", output_path]
            if batch_file:
                cmd += ["--bn", batch_file]
            cmds.append((cmd, f"RECmd → {os.path.basename(hive)}"))
        return cmds

    # ── Single file mode ────────────────────────────────────────────────────
    if tool.get("single_file"):
        file_names = tool.get("file_names", [])
        found      = _find_files(collection_path, names=file_names)
        found      = [f for f in found if not os.path.isdir(f)]
        for fpath in found:
            cmd = [exe_path, "-f", fpath, "--csv", output_path]
            if tool.get("csvf"):
                cmd += ["--csvf", tool["csvf"]]
            cmds.append((cmd, f"{tool['name']} → {os.path.basename(fpath)}"))
        return cmds

    # ── Directory mode ──────────────────────────────────────────────────────
    if tool.get("dir_mode"):
        # First try to find named subdirectories
        dir_names = tool.get("dir_names", [])
        target_dirs = []
        if dir_names:
            target_dirs = _find_dirs(collection_path, dir_names)
        # If no named dirs found, or no dir_names specified, use collection root
        if not target_dirs:
            # Check if any relevant files exist anywhere in the collection
            ext    = tool.get("ext")
            prefix = tool.get("prefix")
            if ext or prefix:
                found_files = _find_files(collection_path, ext=ext, prefix=prefix)
                if not found_files:
                    return []
                # Use the directories that contain these files
                dirs_with_files = list({os.path.dirname(f) for f in found_files})
                target_dirs = dirs_with_files
            else:
                target_dirs = [collection_path]

        seen = set()
        for d in target_dirs:
            if d in seen:
                continue
            seen.add(d)
            cmd = [exe_path, "-d", d, "-q", "--csv", output_path]
            if tool.get("csvf"):
                cmd += ["--csvf", tool["csvf"]]
            cmds.append((cmd, f"{tool['name']} → {d}"))
        return cmds

    return []
