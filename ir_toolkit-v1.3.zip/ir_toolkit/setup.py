"""
IR Toolkit — Setup / Dependency Validator
Run this ONCE before starting the app for the first time:

    python setup.py

It will:
  1. Install all requirements from requirements.txt
  2. Validate that yara-python has the key modules (pe, elf, math, hash, dotnet)
  3. If any are missing, attempt to reinstall yara-python with full module support
  4. Print a clear summary so you know what's available before running app.py
"""

import sys, subprocess, importlib

def run(cmd, **kwargs):
    print(f"  > {' '.join(cmd)}")
    return subprocess.run(cmd, **kwargs)

def pip_install(*packages, extra_flags=None):
    cmd = [sys.executable, "-m", "pip", "install", "--upgrade"] + list(packages)
    if extra_flags:
        cmd += extra_flags
    run(cmd)

REQUIRED_MODULES = {
    "pe":     'import "pe"\nrule probe{condition: pe.is_pe}',
    "elf":    'import "elf"\nrule probe{condition: elf.type == elf.ET_EXEC}',
    "math":   'import "math"\nrule probe{condition: math.entropy(0,filesize) > 0}',
    "hash":   'import "hash"\nrule probe{condition: hash.sha256(0,filesize) != ""}',
    "dotnet": 'import "dotnet"\nrule probe{condition: dotnet.is_dotnet}',
}

OPTIONAL_MODULES = {
    "macho":  'import "macho"\nrule probe{condition: macho.magic == 0xFEEDFACE}',
}

def test_yara_modules():
    try:
        import yara
    except ImportError:
        return None, None
    available, unavailable = [], []
    for mod, probe in {**REQUIRED_MODULES, **OPTIONAL_MODULES}.items():
        try:
            yara.compile(source=probe)
            available.append(mod)
        except Exception:
            unavailable.append(mod)
    return available, unavailable

def main():
    print("\n" + "="*60)
    print("  IR Toolkit — Setup")
    print("="*60 + "\n")

    # ── Step 1: Install base requirements ────────────────────────────────────
    print("[1/3] Installing Python dependencies...")
    result = run(
        [sys.executable, "-m", "pip", "install", "-r", "requirements.txt"],
        capture_output=False
    )
    print()

    # ── Step 2: Test yara-python modules ─────────────────────────────────────
    print("[2/3] Checking yara-python module support...")
    # Force reimport in case it was just installed
    if "yara" in sys.modules:
        del sys.modules["yara"]

    available, unavailable = test_yara_modules()

    if available is None:
        print("  [!] yara-python failed to import. Check the pip output above.")
        sys.exit(1)

    required_missing = [m for m in REQUIRED_MODULES if m in unavailable]

    if not required_missing:
        print(f"  [✓] All required modules available: {', '.join(sorted(available))}")
        if unavailable:
            print(f"  [~] Optional modules unavailable (not needed): {', '.join(sorted(unavailable))}")
    else:
        print(f"  [!] Missing required modules: {', '.join(required_missing)}")
        print(f"  [*] Attempting reinstall with full module support...")
        print()

        # ── Step 2a: Try reinstalling with --no-binary to force build from source
        # This gives the best chance of including OpenSSL (for hash module) etc.
        pip_install("yara-python", extra_flags=["--no-binary", "yara-python"])

        # Re-test
        if "yara" in sys.modules:
            del sys.modules["yara"]
        available, unavailable = test_yara_modules()
        required_missing = [m for m in REQUIRED_MODULES if m in unavailable]

        if not required_missing:
            print(f"\n  [✓] Reinstall succeeded — modules available: {', '.join(sorted(available))}")
        else:
            print(f"\n  [~] Still missing: {', '.join(required_missing)}")
            print()
            print("  This usually means the OpenSSL development libraries aren't installed.")
            print("  The app will still work — rules using missing modules are skipped during scans.")
            print()
            if sys.platform.startswith("win"):
                print("  On Windows, try installing a pre-built wheel that includes OpenSSL:")
                print("  https://github.com/VirusTotal/yara-python/releases")
            elif sys.platform.startswith("linux"):
                print("  On Linux, install OpenSSL dev headers first:")
                print("    Ubuntu/Debian:  sudo apt-get install libssl-dev")
                print("    Fedora/RHEL:    sudo dnf install openssl-devel")
                print("  Then re-run: python setup.py")
            elif sys.platform.startswith("darwin"):
                print("  On macOS, install OpenSSL via Homebrew:")
                print("    brew install openssl")
                print("  Then re-run: python setup.py")
            print()

    # ── Step 3: Summary ───────────────────────────────────────────────────────
    print("[3/3] Setup complete.\n")
    print("  YARA modules available:")
    for mod in sorted(available):
        tag = "(required)" if mod in REQUIRED_MODULES else "(optional)"
        print(f"    [✓] {mod:10} {tag}")
    for mod in sorted(unavailable):
        tag = "(MISSING — rules using this module will be skipped)" if mod in REQUIRED_MODULES else "(optional — not needed)"
        print(f"    [✗] {mod:10} {tag}")

    print()
    print("  Start the toolkit with:  python app.py")
    print("  Then open:               http://localhost:5000")
    print()

if __name__ == "__main__":
    main()
