# IR Toolkit

A local Flask-based IR toolkit. Runs entirely on your machine — no cloud, no uploads.

## Modules

| Module | What it does |
|--------|-------------|
| **YARA Rules** | Manage rules, import `.yar` files, run real scans via `yara-python` |
| **File Hasher** | MD5/SHA1/SHA256/SHA512, magic bytes, string extraction, YARA rule generation |
| **Artifact Parser** | Generate PowerShell script to run Zimmerman tools against a CyLR collection |
| **UAL Logs** | Parse M365 Unified Audit Logs, group by operation, export to XLSX/CSV |

---

## Setup

### 1. Run the setup script (first time only)

```bash
python setup.py
```

This installs all dependencies and validates that `yara-python` was built with full module support (`pe`, `elf`, `math`, `hash`, `dotnet`). These modules are required to run the majority of YARA Forge rules. If any are missing the script will attempt to fix it automatically, and tell you exactly what to do if it can't.

### 2. Start the server

```bash
python app.py
```

Then open **http://localhost:5000**

---

> **Do not use `pip install -r requirements.txt` directly** — use `python setup.py` instead, which validates the yara-python module build after installation and handles edge cases where the default wheel is missing OpenSSL support.

---

## Module notes

### YARA Rules
- Scanning uses `yara-python` directly — no external `yara.exe` binary needed.
- Rules are stored in memory per session. Use **Export all** to save a `.yar` file you can re-import.
- To persist rules across restarts, import the exported `.yar` file on startup.

### File Hasher
- The file is sent to localhost only — never leaves your machine.
- YARA rule generation happens server-side with real `hashlib` hashes.
- For deeper string filtering, run `yarGen` externally and import the result.

### Artifact Parser
- Generates a `.ps1` script — run it on Windows with Zimmerman tools installed.
- Install Zimmerman tools: `.\Get-ZimmermanTools.ps1 -Dest C:\Tools\ZimmermanTools`
- Use **Check tools** to verify your tools directory before generating the script.
- After running the script, load the output CSVs into the results viewer.
- Run `EvtxECmd.exe --sync` and `SQLECmd.exe --sync` before first use.

### UAL Logs
- Drop the standard M365 UAL CSV export (with `AuditData` column).
- Server-side parsing flattens all nested JSON fields.
- Export to XLSX (one sheet per operation, matching your original Python script) or flat CSV.
- Large files: the UI shows the first 500 rows per operation; **Export** sends all rows.

---

## File structure

```
ir_toolkit/
├── app.py                  # Flask entry point
├── requirements.txt
├── modules/
│   ├── yara_module.py      # YARA CRUD + real scanning
│   ├── hasher_module.py    # File hashing + YARA rule gen
│   ├── ual_module.py       # UAL CSV parsing + export
│   └── artifact_module.py  # Zimmerman tool config + script gen
├── templates/
│   └── index.html          # Single-page app
└── static/
    └── js/
        └── app.js          # Frontend logic
```

---

## Adding new modules

1. Create `modules/your_module.py` with a Flask `Blueprint`
2. Register it in `app.py`: `app.register_blueprint(your_bp, url_prefix="/api/your")`
3. Add a nav item and module `<div>` in `templates/index.html`
4. Add the JS logic in `static/js/app.js`
