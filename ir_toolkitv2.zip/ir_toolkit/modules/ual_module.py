"""
UAL Module — M365 Unified Audit Log Parser
- Parses CSV with AuditData JSON column
- Flattens nested JSON, groups by Operation
- Exports to XLSX / CSV
- IP Geolocation enrichment via ip-api.com batch endpoint (free, no key needed)
"""

import csv, json, io, re, time, math, ipaddress, urllib.request, urllib.error
from datetime import datetime
from flask import Blueprint, request, jsonify, send_file, Response
import pandas as pd

ual_bp = Blueprint("ual", __name__)

# ── IP geolocation cache (in-process, persists for the session) ──────────────
_geo_cache = {}   # { ip_str: { city, regionName, country, ... } or None }

IP_REGEX = re.compile(
    r'^(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)$'
)
# Matches bare "1.2.3.4:56789" — used to split ClientIP:port into two columns
_IP_PORT_RE = re.compile(
    r'^((?:\d{1,3}\.){3}\d{1,3}):(\d+)$'
)

def _is_private(ip_str):
    """Return True for RFC1918 / loopback / link-local / special-use IPs."""
    try:
        addr = ipaddress.ip_address(ip_str.strip())
        return addr.is_private or addr.is_loopback or addr.is_link_local or addr.is_reserved
    except ValueError:
        return True   # not a valid IP — treat as skip

def _is_ip(value):
    """Return True if the cell value looks like a routable IPv4 address."""
    v = str(value or "").strip()
    # Strip port if present (e.g. "1.2.3.4:12345")
    if ":" in v:
        v = v.split(":")[0]
    return bool(IP_REGEX.match(v)) and not _is_private(v)

def _extract_ip(value):
    """Extract the bare IP from a value that may include port."""
    v = str(value or "").strip()
    if ":" in v:
        v = v.split(":")[0]
    return v if IP_REGEX.match(v) else None

def _ip_col_names(columns):
    """
    Return columns that are likely to contain IP addresses.
    Matches column names that contain 'ip' or 'address' (case-insensitive),
    excluding obvious non-IP columns like 'EmailAddress', 'DisplayName'.
    """
    skip_words = {"email", "display", "name", "smtp", "alias", "upn", "user"}
    result = []
    for col in columns:
        cl = col.lower()
        if ("ip" in cl or "address" in cl) and not any(w in cl for w in skip_words):
            result.append(col)
    return result

def _format_geo(geo):
    """Format a geo result into a concise string."""
    if not geo or geo.get("status") == "fail":
        return ""
    parts = []
    if geo.get("city"):       parts.append(geo["city"])
    if geo.get("regionName"): parts.append(geo["regionName"])
    if geo.get("country"):    parts.append(geo["country"])
    extra = []
    if geo.get("proxy"):   extra.append("VPN/Proxy")
    if geo.get("hosting"): extra.append("Hosting")
    if geo.get("isp"):     extra.append(geo["isp"])
    label = ", ".join(parts) if parts else "Unknown"
    if extra:
        label += f" [{'; '.join(extra)}]"
    return label

def _batch_geolocate(ips, batch_size=100, rate_limit_rpm=44):
    """
    Look up a list of unique IPs using ip-api.com batch endpoint.
    Batches of 100, rate-limited to stay under 45 req/min.
    Returns dict { ip: geo_dict }.
    """
    results = {}
    # Only look up IPs not already cached
    to_fetch = [ip for ip in ips if ip not in _geo_cache]

    if not to_fetch:
        return {ip: _geo_cache[ip] for ip in ips if ip in _geo_cache}

    # Split into batches
    batches = [to_fetch[i:i+batch_size] for i in range(0, len(to_fetch), batch_size)]
    min_interval = 60.0 / rate_limit_rpm   # seconds between requests

    for i, batch in enumerate(batches):
        if i > 0:
            time.sleep(min_interval)
        try:
            payload = json.dumps([
                {"query": ip, "fields": "status,message,city,regionName,country,countryCode,lat,lon,isp,org,proxy,hosting,query"}
                for ip in batch
            ]).encode()
            req = urllib.request.Request(
                "http://ip-api.com/batch?fields=status,message,city,regionName,country,countryCode,lat,lon,isp,org,proxy,hosting,query",
                data=payload,
                headers={"Content-Type": "application/json", "User-Agent": "IR-Toolkit/1.0"},
            )
            with urllib.request.urlopen(req, timeout=15) as resp:
                batch_results = json.loads(resp.read().decode())
            for geo in batch_results:
                ip_key = geo.get("query", "")
                _geo_cache[ip_key] = geo
                results[ip_key] = geo
        except Exception as e:
            # Cache failures as None so we don't retry
            for ip in batch:
                _geo_cache[ip] = None
            print(f"[UAL geo] Batch {i+1} failed: {e}")

    # Return cache hits for all requested IPs
    return {ip: _geo_cache.get(ip) for ip in ips}

# ── Geolocation endpoint ────────────────────────────────────────────────────
@ual_bp.route("/geolocate", methods=["POST"])
def geolocate():
    """
    Find IP columns in the provided rows, look up unique IPs,
    return a geo_map { ip: formatted_string } and column metadata.
    POST body: { "operations": { op: { columns: [...], rows: [...] } } }
    Streams SSE progress.
    """
    data = request.json or {}
    operations = data.get("operations", {})

    def generate():
        def emit(cls, text, **extra):
            return f"data: {json.dumps({'cls': cls, 'text': text, **extra})}\n\n"

        # ── Step 1: Find IP columns and collect unique IPs ────────────────
        ip_cols_by_op = {}   # { op: [col_name, ...] }
        all_ips = set()

        for op, op_data in operations.items():
            cols = op_data.get("columns", [])
            rows = op_data.get("rows", [])
            ip_cols = _ip_col_names(cols)
            if not ip_cols:
                continue
            # Confirm columns actually contain IPs by sampling values
            confirmed = []
            for col in ip_cols:
                sample = [r.get(col,"") for r in rows[:50] if r.get(col,"")]
                if any(_is_ip(v) for v in sample):
                    confirmed.append(col)
                    for row in rows:
                        ip = _extract_ip(row.get(col, ""))
                        if ip and _is_ip(row.get(col, "")):
                            all_ips.add(ip)
            if confirmed:
                ip_cols_by_op[op] = confirmed

        if not all_ips:
            yield emit("warn", "[~] No routable IP addresses found in detected IP columns.")
            yield f"data: {json.dumps({'cls': 'complete', 'geo_map': {}, 'ip_cols_by_op': {}})}\n\n"
            return

        unique_ips = sorted(all_ips)
        # Filter out already cached
        uncached = [ip for ip in unique_ips if ip not in _geo_cache]

        yield emit("info", f"[*] Found {len(unique_ips):,} unique routable IPs across {len(ip_cols_by_op)} operation(s)")
        yield emit("info", f"[*] IP columns detected: { {op: cols for op, cols in ip_cols_by_op.items()} }")
        if uncached:
            yield emit("info", f"[*] {len(uncached):,} IPs to look up ({len(unique_ips)-len(uncached):,} already cached)")
        else:
            yield emit("info", f"[*] All {len(unique_ips):,} IPs served from cache")

        # ── Step 2: Batch geolocate ─────────────────────────────────────────
        batches = [uncached[i:i+100] for i in range(0, len(uncached), 100)]
        if batches:
            yield emit("cmd", f"[*] Looking up {len(uncached):,} IPs in {len(batches)} batch(es) via ip-api.com...")

        min_interval = 60.0 / 44   # stay under 45 req/min

        for i, batch in enumerate(batches):
            if i > 0:
                time.sleep(min_interval)
            try:
                payload = json.dumps([
                    {"query": ip, "fields": "status,message,city,regionName,country,countryCode,lat,lon,isp,org,proxy,hosting,query"}
                    for ip in batch
                ]).encode()
                req = urllib.request.Request(
                    "http://ip-api.com/batch",
                    data=payload,
                    headers={"Content-Type": "application/json", "User-Agent": "IR-Toolkit/1.0"},
                )
                with urllib.request.urlopen(req, timeout=15) as resp:
                    batch_results = json.loads(resp.read().decode())
                for geo in batch_results:
                    ip_key = geo.get("query", "")
                    _geo_cache[ip_key] = geo
                pct = round((i + 1) / len(batches) * 100)
                yield emit("progress", f"[{i+1}/{len(batches)}] Batch complete",
                           current=i+1, total=len(batches), pct=pct)
            except Exception as e:
                for ip in batch:
                    _geo_cache.setdefault(ip, None)
                yield emit("warn", f"[~] Batch {i+1} failed: {e}")

        # ── Step 3: Build geo_map { ip: label } and geo_coords { ip: {lat,lon} } ──
        geo_map    = {}
        geo_coords = {}
        success    = 0
        for ip in unique_ips:
            geo   = _geo_cache.get(ip)
            label = _format_geo(geo)
            geo_map[ip] = label
            if label:
                success += 1
            if geo and geo.get("lat") is not None and geo.get("lon") is not None:
                geo_coords[ip] = {"lat": geo["lat"], "lon": geo["lon"]}

        yield emit("done", f"[✓] Geolocation complete — {success:,} of {len(unique_ips):,} IPs resolved")
        yield f"data: {json.dumps({'cls': 'complete', 'geo_map': geo_map, 'ip_cols_by_op': ip_cols_by_op, 'geo_coords': geo_coords})}\n\n"

    return Response(generate(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

# ── Parse ─────────────────────────────────────────────────────────────────────
@ual_bp.route("/parse", methods=["POST"])
def parse():
    if "file" not in request.files:
        return jsonify({"error": "no file uploaded"}), 400

    f = request.files["file"]
    if not f.filename.lower().endswith(".csv"):
        return jsonify({"error": "expected a .csv file"}), 400

    try:
        content = f.read().decode("utf-8-sig", errors="replace")
        rows_by_op, parsed, errors = _parse_ual_csv(content)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    # Build summary for the frontend
    summary = {
        "parsed": parsed,
        "errors": errors,
        "operations": {
            op: {
                "count": len(rows),
                "columns": list(rows[0].keys()) if rows else [],
                # Send first 500 rows per operation to keep response manageable
                "rows": rows[:500],
                "total": len(rows),
            }
            for op, rows in rows_by_op.items()
        }
    }
    return jsonify(summary)

# ── Export ─────────────────────────────────────────────────────────────────────
@ual_bp.route("/export", methods=["POST"])
def export():
    """
    POST body:
      file        — the original UAL CSV (multipart)
      format      — 'xlsx' or 'csv'
      operations  — JSON list of operation names to include (all if omitted)
    """
    if "file" not in request.files:
        return jsonify({"error": "no file uploaded"}), 400

    f       = request.files["file"]
    fmt     = request.form.get("format", "xlsx")
    ops_raw = request.form.get("operations", "")
    wanted_ops = json.loads(ops_raw) if ops_raw else None

    # Geo data forwarded from the browser (populated after a Geolocate run)
    geo_map  = json.loads(request.form.get("geo_map",  "{}") or "{}")
    geo_cols = json.loads(request.form.get("geo_cols", "{}") or "{}")

    content = f.read().decode("utf-8-sig", errors="replace")
    rows_by_op, _, _ = _parse_ual_csv(content)

    if wanted_ops:
        rows_by_op = {op: rows for op, rows in rows_by_op.items() if op in wanted_ops}

    # Inject geo columns right after each detected IP column
    if geo_map and geo_cols:
        for op, rows in rows_by_op.items():
            ip_col_list = geo_cols.get(op, [])
            if not ip_col_list or not rows:
                continue
            new_rows = []
            for row in rows:
                new_row = {}
                for k, v in row.items():
                    new_row[k] = v
                    if k in ip_col_list:
                        ip     = str(v or "").strip()
                        new_row[k + "_geo"] = geo_map.get(ip, "")
                new_rows.append(new_row)
            rows_by_op[op] = new_rows

    if fmt == "xlsx":
        buf = io.BytesIO()
        with pd.ExcelWriter(buf, engine="openpyxl") as writer:
            for op, rows in rows_by_op.items():
                if not rows:
                    continue
                df = pd.DataFrame(rows)
                safe_name = re.sub(r'[\\/*?:\[\]]', '', op)[:31] or "Sheet1"
                df.to_excel(writer, sheet_name=safe_name, index=False)
        buf.seek(0)
        return send_file(buf, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                         as_attachment=True, download_name="UAL_Export.xlsx")
    else:
        # Flat CSV — merge all operations
        all_rows = []
        for rows in rows_by_op.values():
            all_rows.extend(rows)
        if not all_rows:
            return jsonify({"error": "no data"}), 400
        cols = list(all_rows[0].keys())
        buf = io.StringIO()
        writer = csv.DictWriter(buf, fieldnames=cols, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(all_rows)
        return Response(buf.getvalue(), mimetype="text/csv",
                        headers={"Content-Disposition": "attachment; filename=UAL_Export.csv"})

# ── Impossible Travel ────────────────────────────────────────────────────────
def _haversine_km(lat1, lon1, lat2, lon2):
    """Great-circle distance in km between two lat/lon points."""
    R    = 6371
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a    = math.sin(dlat/2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon/2)**2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

def _row_ip(row):
    """Return the bare IP from common M365 IP column names."""
    return (row.get("ClientIP") or row.get("ClientIPAddress") or row.get("actorIpAddress") or "").strip()

@ual_bp.route("/travel", methods=["POST"])
def travel():
    """
    Impossible travel analysis across ALL UserLoggedIn rows.
    POST fields: file (CSV), geo_map (JSON), geo_coords (JSON { ip: {lat,lon} })
    Returns: { flags, total_rows, analyzed_pairs, skipped_no_ip, skipped_no_coords }
    """
    if "file" not in request.files:
        return jsonify({"error": "no file uploaded"}), 400

    geo_map    = json.loads(request.form.get("geo_map",    "{}") or "{}")
    geo_coords = json.loads(request.form.get("geo_coords", "{}") or "{}")

    if not geo_coords:
        return jsonify({"error": "No geo coordinate data found — run Geolocate IPs first."}), 400

    content = request.files["file"].read().decode("utf-8-sig", errors="replace")
    rows_by_op, _, _ = _parse_ual_csv(content)

    rows = rows_by_op.get("UserLoggedIn", [])
    if not rows:
        return jsonify({"error": "No UserLoggedIn operation found in this file."}), 400

    SPEED_LIMIT_KMH = 900

    # Group by UserId
    by_user = {}
    for row in rows:
        user = (row.get("UserId") or row.get("UserID") or "Unknown").strip()
        by_user.setdefault(user, []).append(row)

    flags             = []
    analyzed_pairs    = 0
    skipped_no_ip     = 0
    skipped_no_coords = 0
    skipped_date_err  = 0

    for user, user_rows in by_user.items():
        try:
            sorted_rows = sorted(user_rows, key=lambda r: r.get("CreationDate") or "")
        except Exception:
            sorted_rows = user_rows

        for i in range(1, len(sorted_rows)):
            prev = sorted_rows[i - 1]
            curr = sorted_rows[i]

            ip1 = _row_ip(prev)
            ip2 = _row_ip(curr)
            if not ip1 or not ip2:
                skipped_no_ip += 1
                continue
            if ip1 == ip2:
                continue

            c1 = geo_coords.get(ip1)
            c2 = geo_coords.get(ip2)
            if not c1 or not c2:
                skipped_no_coords += 1
                continue

            analyzed_pairs += 1

            try:
                t1 = datetime.fromisoformat(prev["CreationDate"].replace(" ", "T"))
                t2 = datetime.fromisoformat(curr["CreationDate"].replace(" ", "T"))
                delta_hours = (t2 - t1).total_seconds() / 3600
            except Exception:
                skipped_date_err += 1
                continue

            if delta_hours < 0:
                continue

            dist_km   = _haversine_km(float(c1["lat"]), float(c1["lon"]),
                                      float(c2["lat"]), float(c2["lon"]))
            speed_kmh = (dist_km / delta_hours) if delta_hours > 0 else None  # None = simultaneous

            if (speed_kmh is None and dist_km > 0) or (speed_kmh and speed_kmh > SPEED_LIMIT_KMH):
                flags.append({
                    "user":        user,
                    "t1":          prev.get("CreationDate", ""),
                    "ip1":         ip1,
                    "loc1":        geo_map.get(ip1, ip1),
                    "t2":          curr.get("CreationDate", ""),
                    "ip2":         ip2,
                    "loc2":        geo_map.get(ip2, ip2),
                    "delta_hours": round(delta_hours, 4),
                    "dist_km":     round(dist_km, 1),
                    "speed_kmh":   round(speed_kmh, 1) if speed_kmh is not None else None,
                })

    return jsonify({
        "flags":             flags,
        "total_rows":        len(rows),
        "analyzed_pairs":    analyzed_pairs,
        "skipped_no_ip":     skipped_no_ip,
        "skipped_no_coords": skipped_no_coords,
        "skipped_date_err":  skipped_date_err,
    })

# ── Core parser (your original logic) ────────────────────────────────────────
def _flatten_json(obj, prefix=""):
    flat = {}
    for key, value in obj.items():
        full_key = f"{prefix}{key}"
        if isinstance(value, dict):
            flat.update(_flatten_json(value, full_key + "."))
        elif isinstance(value, list):
            for i, item in enumerate(value):
                if isinstance(item, dict):
                    flat.update(_flatten_json(item, f"{full_key}[{i}]."))
                else:
                    flat[f"{full_key}[{i}]"] = item
        else:
            flat[full_key] = value
    return flat

def _parse_ual_csv(content):
    rows_by_op = {}
    parsed = 0
    errors = 0

    reader = csv.DictReader(io.StringIO(content))

    # Find AuditData column case-insensitively
    fieldnames = reader.fieldnames or []
    audit_col = next((f for f in fieldnames if f.strip().lower() == "auditdata"), None)
    if not audit_col:
        raise ValueError("No AuditData column found. Is this a valid M365 UAL export?")

    for row in reader:
        try:
            # Flatten AuditData JSON into the row
            audit_raw = row.get(audit_col, "").strip()
            if audit_raw:
                try:
                    audit_obj = json.loads(audit_raw)
                    flat = _flatten_json(audit_obj)
                    row.update(flat)
                except json.JSONDecodeError:
                    errors += 1

            # Split "IP:port" values — e.g. ClientIP "185.98.168.102:27943"
            # becomes ClientIP = "185.98.168.102", ClientIP_Port = "27943"
            for col in list(row.keys()):
                m = _IP_PORT_RE.match(str(row.get(col) or '').strip())
                if m:
                    row[col] = m.group(1)
                    row[col + '_Port'] = m.group(2)

            # Remove the raw blob — it's been expanded
            row.pop("AuditData", None)
            row.pop("auditdata", None)

            # Normalise CreationDate to "YYYY-MM-DDTHH:MM:SS" regardless of source format
            if row.get("CreationDate"):
                try:
                    cd = str(row["CreationDate"]).strip()
                    if "T" in cd or (len(cd) > 4 and cd[:4].isdigit()):
                        # ISO-style: "2025-11-26T14:47:19.000Z" → "2025-11-26T14:47:19"
                        row["CreationDate"] = cd.split(".")[0].split("Z")[0]
                    elif "/" in cd:
                        # US locale: "11/26/2025 14:47" or "11/26/2025 14:47:19"
                        fmt = "%m/%d/%Y %H:%M:%S" if cd.count(":") >= 2 else "%m/%d/%Y %H:%M"
                        row["CreationDate"] = datetime.strptime(cd, fmt).strftime("%Y-%m-%dT%H:%M:%S")
                except Exception:
                    pass

            operation = row.get("Operation", "Unknown")
            if operation not in rows_by_op:
                rows_by_op[operation] = []
            rows_by_op[operation].append(dict(row))
            parsed += 1

        except Exception:
            errors += 1

    return rows_by_op, parsed, errors
