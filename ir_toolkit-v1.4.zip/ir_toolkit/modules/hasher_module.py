"""
YARA Creator Module
- Real MD5/SHA1/SHA256/SHA512 via hashlib
- Magic byte detection
- yarGen on-demand setup (only when user requests it)
- yarGen rule generation with live streaming output
"""

import os, re, hashlib, sys, json, shutil, subprocess, tempfile, threading
from flask import Blueprint, request, jsonify, Response

hasher_bp = Blueprint("hasher", __name__)

MAX_FILE_SIZE  = 500 * 1024 * 1024  # 500 MB
BASE_DIR       = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
YARGEN_DIR     = os.path.join(BASE_DIR, "yarGen")
YARGEN_SCRIPT  = os.path.join(YARGEN_DIR, "yarGen.py")

# Track auto-setup state so we only run it once per process
_setup_state   = "unknown"   # unknown | running | ready | failed
_setup_lock    = threading.Lock()
_setup_log     = []          # accumulated log lines for status endpoint


# ── Hashing ───────────────────────────────────────────────────────────────────
MAGIC_SIGS = [
    (b"\x4D\x5A",                          "PE/Windows Executable (MZ)"),
    (b"\x7F\x45\x4C\x46",                  "ELF Executable"),
    (b"\x50\x4B\x03\x04",                  "ZIP Archive"),
    (b"\x50\x4B\x05\x06",                  "ZIP Archive (empty)"),
    (b"\x25\x50\x44\x46",                  "PDF Document"),
    (b"\xFF\xD8\xFF",                       "JPEG Image"),
    (b"\x89\x50\x4E\x47",                  "PNG Image"),
    (b"\x47\x49\x46\x38",                  "GIF Image"),
    (b"\xD0\xCF\x11\xE0",                  "MS Office / OLE Compound File"),
    (b"\x52\x61\x72\x21",                  "RAR Archive"),
    (b"\x1F\x8B",                           "GZIP Archive"),
    (b"\x42\x5A\x68",                       "BZIP2 Archive"),
    (b"\x37\x7A\xBC\xAF",                  "7-Zip Archive"),
    (b"\x4D\x53\x43\x46",                  "Microsoft Cabinet (CAB)"),
    (b"\x4C\x00\x00\x00\x01\x14\x02\x00", "Windows Shortcut (LNK)"),
    (b"\x23\x21",                           "Script (Shebang)"),
    (b"\xEF\xBB\xBF",                       "UTF-8 BOM Text"),
    (b"\xFF\xFE",                           "UTF-16 LE Text"),
    (b"\x53\x51\x4C\x69",                  "SQLite Database"),
]

def _detect_magic(data):
    header  = data[:16]
    hex_str = " ".join(f"{b:02X}" for b in header)
    for sig, label in MAGIC_SIGS:
        if header[:len(sig)] == sig:
            return {"label": label, "hex": hex_str}
    return {"label": "Unknown / Data", "hex": hex_str}

@hasher_bp.route("/hash", methods=["POST"])
def hash_file():
    if "file" not in request.files:
        return jsonify({"error": "no file uploaded"}), 400
    f    = request.files["file"]
    data = f.read()
    if len(data) > MAX_FILE_SIZE:
        return jsonify({"error": "File too large (max 500 MB)"}), 413
    return jsonify({
        "name":    f.filename,
        "size":    len(data),
        "md5":     hashlib.md5(data).hexdigest(),
        "sha1":    hashlib.sha1(data).hexdigest(),
        "sha256":  hashlib.sha256(data).hexdigest(),
        "sha512":  hashlib.sha512(data).hexdigest(),
        "magic":   _detect_magic(data),
        "strings": _extract_strings(data),
    })

# ── String extraction ─────────────────────────────────────────────────────────
GENERIC_STRINGS = [
    "this program cannot be run in dos mode",
    "microsoft", "windows", "program files",
    "kernel32.dll", "ntdll.dll", "user32.dll", "advapi32.dll",
    ".text", ".data", ".rdata", ".rsrc", ".reloc",
    "getprocaddress", "loadlibrarya", "loadlibraryw",
    "virtualalloc", "virtualprotect",
    "copyright", "all rights reserved",
    "visual c++", "runtime library",
]

def _is_generic(s):
    sl = s.lower()
    return any(g in sl for g in GENERIC_STRINGS)

def _score_string(s):
    unique      = len(set(s))
    has_special = bool(re.search(r'[^a-zA-Z0-9 ]', s))
    return len(s) * 0.6 + unique * 0.3 + (10 if has_special else 0)

def _extract_strings(data, min_len=6):
    """Extract printable ASCII strings ≥ min_len, filter generics, score & deduplicate."""
    results, cur = [], []
    for byte in data:
        if 0x20 <= byte <= 0x7E:
            cur.append(chr(byte))
        else:
            if len(cur) >= min_len:
                s = "".join(cur)
                if not _is_generic(s):
                    results.append(s)
            cur = []
    if len(cur) >= min_len:
        s = "".join(cur)
        if not _is_generic(s):
            results.append(s)
    seen, unique = set(), []
    for s in results:
        if s not in seen:
            seen.add(s)
            unique.append(s)
    unique.sort(key=_score_string, reverse=True)
    return unique[:300]

# ── Quick rule generation (hand-picked strings, no yarGen needed) ─────────────
@hasher_bp.route("/quick-rule", methods=["POST"])
def quick_rule():
    """
    POST JSON:
      name, sha256, md5, size, magic_label,
      mode          — 'hash' | 'strings' | 'or'
      tolerance_pct — 0-50
      strings       — list of selected strings
    """
    import math
    from datetime import date

    d           = request.json or {}
    name        = d.get("name", "unknown")
    sha256      = d.get("sha256", "")
    md5         = d.get("md5", "")
    size        = int(d.get("size", 0))
    magic_label = d.get("magic_label", "Unknown")
    mode        = d.get("mode", "hash")
    tol_pct     = int(d.get("tolerance_pct", 0))
    strings     = d.get("strings", [])

    rule_name = re.sub(r'[^a-zA-Z0-9_]', '_', name)
    if rule_name and rule_name[0].isdigit():
        rule_name = "_" + rule_name

    today = date.today().isoformat()
    lines = [
        f"rule {rule_name} {{",
        f"    meta:",
        f'        description = "Quick rule for {name}"',
        f'        date        = "{today}"',
        f'        md5         = "{md5}"',
        f'        sha256      = "{sha256}"',
        f'        filetype    = "{magic_label}"',
    ]

    if tol_pct == 0:
        size_cond = f"filesize == {size}"
    else:
        lo = math.floor(size * (1 - tol_pct / 100))
        hi = math.ceil(size  * (1 + tol_pct / 100))
        size_cond = f"filesize >= {lo} and filesize <= {hi}"

    use_strings = mode in ("strings", "or") and strings
    use_hash    = mode in ("hash", "or")

    if use_strings:
        lines.append("    strings:")
        for i, s in enumerate(strings, 1):
            esc = s.replace("\\", "\\\\").replace('"', '\\"')
            lines.append(f'        $str{i} = "{esc}" ascii wide')

    lines.append("    condition:")
    if mode == "hash":
        lines.append(f'        {size_cond} and')
        lines.append(f'        hash.sha256(0, filesize) == "{sha256}"')
    elif mode == "strings":
        threshold = max(1, math.ceil(len(strings) * 0.6))
        lines.append(f'        {size_cond} and')
        lines.append(f'        {threshold} of ($str*)')
    else:  # or
        threshold = max(1, math.ceil(len(strings) * 0.6))
        lines.append(f'        ({size_cond} and hash.sha256(0, filesize) == "{sha256}")')
        lines.append(f'        or')
        lines.append(f'        ({size_cond} and {threshold} of ($str*))')

    lines.append("}")
    return jsonify({"rule": "\n".join(lines), "name": rule_name})


# ── yarGen setup helpers ──────────────────────────────────────────────────────
def _yargen_ready():
    """True if yarGen script exists and has at least one DB file."""
    if not os.path.isfile(YARGEN_SCRIPT):
        return False
    db_dir = os.path.join(YARGEN_DIR, "dbs")
    if not os.path.isdir(db_dir):
        return False
    return any(f.endswith((".db", ".pkl", ".json")) for f in os.listdir(db_dir))

def _log(cls, text):
    """Append a line to the setup log and print to server console."""
    entry = {"cls": cls, "text": text}
    _setup_log.append(entry)
    print(f"[yarGen setup] {text}")
    return entry

def _run_setup_sync():
    """Blocking setup — called in a background thread on first run."""
    global _setup_state
    try:
        # ── Step 1: clone or pull ──────────────────────────────────────────
        if not os.path.isdir(YARGEN_DIR):
            _log("cmd", "[*] Cloning yarGen from GitHub...")
            result = subprocess.run(
                ["git", "clone", "https://github.com/Neo23x0/yarGen.git", YARGEN_DIR],
                capture_output=True, text=True, timeout=120
            )
            if result.returncode != 0:
                _log("error", f"[!] git clone failed: {result.stderr.strip()[:300]}")
                _setup_state = "failed"
                return
            _log("info", "[+] yarGen cloned.")
        else:
            _log("info", "[*] yarGen already present — pulling latest...")
            subprocess.run(["git", "-C", YARGEN_DIR, "pull"],
                           capture_output=True, timeout=60)
            _log("info", "[+] Up to date.")

        # ── Step 2: pip install requirements ──────────────────────────────
        req = os.path.join(YARGEN_DIR, "requirements.txt")
        if os.path.isfile(req):
            _log("cmd", "[*] Installing yarGen Python dependencies...")
            r = subprocess.run(
                [sys.executable, "-m", "pip", "install", "-r", req,
                 "--break-system-packages", "-q"],
                capture_output=True, text=True, timeout=180
            )
            if r.returncode != 0:
                _log("warn", f"[~] pip note: {r.stderr.strip()[:200]}")
            else:
                _log("info", "[+] Dependencies installed.")

        # ── Step 3: download goodware databases ────────────────────────────
        if not _yargen_ready():
            _log("cmd", "[*] Downloading yarGen goodware databases...")
            _log("info", "[*] This is a one-time download (~few hundred MB). Please wait...")
            proc = subprocess.Popen(
                [sys.executable, YARGEN_SCRIPT, "--update"],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, cwd=YARGEN_DIR,
            )
            for line in proc.stdout:
                line = line.rstrip()
                if line:
                    _log("info" if "error" not in line.lower() else "warn", line)
            proc.wait(timeout=600)
            if proc.returncode != 0:
                _log("warn", "[~] --update returned non-zero. Databases may be partial.")
            else:
                _log("info", "[+] Databases downloaded.")
        else:
            _log("info", "[*] yarGen databases already present — skipping download.")

        if _yargen_ready():
            _setup_state = "ready"
            _log("done", "[✓] yarGen is ready.")
        else:
            _setup_state = "failed"
            _log("error", "[!] Setup finished but yarGen databases not found.")

    except Exception as e:
        _log("error", f"[!] Setup error: {e}")
        _setup_state = "failed"

def _ensure_setup():
    """Trigger setup in background if not already done. Non-blocking."""
    global _setup_state
    with _setup_lock:
        if _setup_state == "unknown":
            if _yargen_ready():
                _setup_state = "ready"
                _log("info", "[*] yarGen already installed — skipping setup.")
            else:
                _setup_state = "running"
                t = threading.Thread(target=_run_setup_sync, daemon=True)
                t.start()


# ── Setup status endpoint (polled by frontend) ────────────────────────────────
@hasher_bp.route("/setup-status", methods=["GET"])
def setup_status():
    """Return current setup state and log lines since a given index."""
    since = int(request.args.get("since", 0))
    return jsonify({
        "state":     _setup_state,
        "log":       _setup_log[since:],
        "log_total": len(_setup_log),
    })

# ── Explicit setup trigger (called by frontend on demand, not at import time) ──
@hasher_bp.route("/trigger-setup", methods=["POST"])
def trigger_setup():
    """
    Start yarGen setup in the background.
    Called when the user explicitly clicks Run yarGen for the first time.
    """
    _ensure_setup()
    return jsonify({"state": _setup_state})


# ── yarGen rule generation (streaming) ────────────────────────────────────────
@hasher_bp.route("/yargen/run", methods=["POST"])
def yargen_run():
    """
    POST multipart: file, optional identifier, optional prefix.
    Streams SSE events. Final event has cls='rule' with the rule text.
    """
    if "file" not in request.files:
        return jsonify({"error": "no file uploaded"}), 400

    if _setup_state == "running":
        return jsonify({"error": "yarGen is still being set up. Please wait."}), 503
    if _setup_state == "failed":
        return jsonify({"error": "yarGen setup failed. Check server logs."}), 500
    if not _yargen_ready():
        return jsonify({"error": "yarGen not ready yet."}), 503

    uploaded = request.files["file"]
    identifier = request.form.get("identifier", "").strip()
    prefix     = request.form.get("prefix", "").strip()

    tmp_dir     = tempfile.mkdtemp(prefix="irtoolkit_yargen_")
    safe_name   = re.sub(r'[^\w.\-]', '_', uploaded.filename) or "sample"
    sample_path = os.path.join(tmp_dir, safe_name)
    out_file    = os.path.join(tmp_dir, "out.yar")

    try:
        uploaded.save(sample_path)
    except Exception as e:
        shutil.rmtree(tmp_dir, ignore_errors=True)
        return jsonify({"error": f"Could not save file: {e}"}), 500

    def generate():
        def emit(cls, text):
            return f"data: {json.dumps({'cls': cls, 'text': text})}\n\n"

        try:
            cmd = [
                sys.executable, YARGEN_SCRIPT,
                "-m", tmp_dir,
                "-o", out_file,
                "--excludegood",
                "-a", "IR Toolkit",
            ]
            if identifier: cmd += ["-b", identifier]
            if prefix:     cmd += ["--prefix", prefix]

            yield emit("cmd",  f"[*] File: {uploaded.filename}")
            yield emit("cmd",  f"[*] Running yarGen...")
            yield emit("info", "[*] Extracting strings and filtering against goodware database...")

            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                cwd=YARGEN_DIR,
            )
            for line in proc.stdout:
                line = line.rstrip()
                if not line:
                    continue
                cls = "warn"  if "error"   in line.lower() else \
                      "match" if "rule"    in line.lower() else \
                      "done"  if "written" in line.lower() else "info"
                yield emit(cls, line)

            proc.wait(timeout=300)

            if os.path.isfile(out_file):
                rule_text = open(out_file, encoding="utf-8", errors="replace").read().strip()
                if rule_text:
                    yield emit("done", "[+] Rule generation complete.")
                    yield f"data: {json.dumps({'cls': 'rule', 'text': rule_text})}\n\n"
                else:
                    yield emit("warn", "[~] yarGen produced no output. The file may lack unique strings after goodware filtering.")
            else:
                yield emit("error", "[!] No output file produced.")

        except subprocess.TimeoutExpired:
            yield emit("error", "[!] yarGen timed out (5 min limit).")
        except Exception as e:
            yield emit("error", f"[!] Unexpected error: {e}")
        finally:
            shutil.rmtree(tmp_dir, ignore_errors=True)

    return Response(generate(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
