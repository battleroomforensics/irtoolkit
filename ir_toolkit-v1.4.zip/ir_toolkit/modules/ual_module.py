"""
UAL Module — M365 Unified Audit Log Parser
- Parses CSV with AuditData JSON column
- Flattens nested JSON, groups by Operation
- Exports to XLSX / CSV
- IP Geolocation enrichment via ip-api.com batch endpoint (free, no key needed)
"""

import csv, json, io, re, time, math, ipaddress, urllib.request, urllib.error
from datetime import datetime
from flask import Blueprint, request, jsonify, send_file, Response
import pandas as pd

ual_bp = Blueprint("ual", __name__)

# ── IP geolocation cache (in-process, persists for the session) ──────────────
_geo_cache = {}   # { ip_str: { city, regionName, country, ... } or None }

# Matches bare IPv4:port — "1.2.3.4:56789"
_IP_PORT_RE = re.compile(r'^((?:\d{1,3}\.){3}\d{1,3}):(\d+)$')
# Matches [IPv6]:port — "[2001:db8::1]:12345"
_IPV6_PORT_RE = re.compile(r'^\[([^\]]+)\]:(\d+)$')

# Excel cell character limit
_XL_MAX_CELL = 32767

def _parse_ip_port(value):
    """
    Split "IP:port" or "[IPv6]:port" into (ip, port).
    Returns (None, None) if the value is not an IP:port pattern.
    Returns (ip, None) if the value is a plain IP (no port).
    """
    v = str(value or "").strip()
    # Bracketed IPv6 with port: [2001:db8::1]:12345
    m = _IPV6_PORT_RE.match(v)
    if m:
        return m.group(1), m.group(2)
    # IPv4 with port: 1.2.3.4:12345
    m = _IP_PORT_RE.match(v)
    if m:
        return m.group(1), m.group(2)
    # Bare IP (IPv4 or IPv6) — validate via ipaddress
    try:
        ipaddress.ip_address(v)
        return v, None
    except ValueError:
        return None, None

def _extract_ip(value):
    """Return the bare IP string (IPv4 or IPv6), or None if not a valid IP."""
    ip, _ = _parse_ip_port(value)
    return ip

def _is_routable(ip_str):
    """Return True for a globally routable IPv4 or IPv6 address."""
    if not ip_str:
        return False
    try:
        addr = ipaddress.ip_address(ip_str.strip())
        return not (addr.is_private or addr.is_loopback or addr.is_link_local
                    or addr.is_reserved or addr.is_unspecified or addr.is_multicast)
    except ValueError:
        return False

def _is_ip(value):
    """Return True if the cell value contains a routable IP (IPv4 or IPv6)."""
    ip = _extract_ip(value)
    return ip is not None and _is_routable(ip)

def _ip_col_names(columns):
    """
    Return columns that are likely to contain IP addresses.
    Matches column names that contain 'ip' or 'address' (case-insensitive),
    excluding obvious non-IP columns like 'EmailAddress', 'DisplayName'.
    """
    skip_words = {"email", "display", "name", "smtp", "alias", "upn", "user"}
    result = []
    for col in columns:
        cl = col.lower()
        if ("ip" in cl or "address" in cl) and not any(w in cl for w in skip_words):
            result.append(col)
    return result

def _format_geo(geo):
    """Format a geo result into a concise string."""
    if not geo or geo.get("status") == "fail":
        return ""
    parts = []
    if geo.get("city"):       parts.append(geo["city"])
    if geo.get("regionName"): parts.append(geo["regionName"])
    if geo.get("country"):    parts.append(geo["country"])
    extra = []
    if geo.get("proxy"):   extra.append("VPN/Proxy")
    if geo.get("hosting"): extra.append("Hosting")
    if geo.get("isp"):     extra.append(geo["isp"])
    label = ", ".join(parts) if parts else "Unknown"
    if extra:
        label += f" [{'; '.join(extra)}]"
    return label

GEO_FIELDS = "status,message,city,regionName,country,countryCode,lat,lon,isp,org,proxy,hosting,query"

def _batch_geolocate(ips, batch_size=100, rate_limit_rpm=44):
    """
    Look up a list of unique IPs (IPv4 or IPv6) via ip-api.com batch endpoint.
    Batches of 100, rate-limited to stay under 45 req/min.
    Returns dict { ip: geo_dict }.
    """
    results = {}
    to_fetch = [ip for ip in ips if ip not in _geo_cache]

    if not to_fetch:
        return {ip: _geo_cache[ip] for ip in ips if ip in _geo_cache}

    batches = [to_fetch[i:i+batch_size] for i in range(0, len(to_fetch), batch_size)]
    min_interval = 60.0 / rate_limit_rpm

    for i, batch in enumerate(batches):
        if i > 0:
            time.sleep(min_interval)
        try:
            payload = json.dumps([
                {"query": ip, "fields": GEO_FIELDS}
                for ip in batch
            ]).encode()
            req = urllib.request.Request(
                f"http://ip-api.com/batch?fields={GEO_FIELDS}",
                data=payload,
                headers={"Content-Type": "application/json", "User-Agent": "IR-Toolkit/1.0"},
            )
            with urllib.request.urlopen(req, timeout=15) as resp:
                batch_results = json.loads(resp.read().decode())
            for geo in batch_results:
                ip_key = geo.get("query", "")
                _geo_cache[ip_key] = geo
                results[ip_key] = geo
        except Exception as e:
            for ip in batch:
                _geo_cache[ip] = None
            print(f"[UAL geo] Batch {i+1} failed: {e}")

    return {ip: _geo_cache.get(ip) for ip in ips}

# ── Geolocation endpoint ────────────────────────────────────────────────────
@ual_bp.route("/geolocate", methods=["POST"])
def geolocate():
    """
    Find IP columns in the provided rows, look up unique IPs,
    return a geo_map { ip: formatted_string } and column metadata.
    POST body: { "operations": { op: { columns: [...], rows: [...] } } }
    Streams SSE progress.
    """
    data = request.json or {}
    operations = data.get("operations", {})

    def generate():
        def emit(cls, text, **extra):
            return f"data: {json.dumps({'cls': cls, 'text': text, **extra})}\n\n"

        # ── Step 1: Find IP columns and collect unique IPs ────────────────
        ip_cols_by_op = {}   # { op: [col_name, ...] }
        all_ips = set()

        for op, op_data in operations.items():
            cols = op_data.get("columns", [])
            rows = op_data.get("rows", [])
            ip_cols = _ip_col_names(cols)
            if not ip_cols:
                continue
            # Confirm columns actually contain IPs by sampling values
            confirmed = []
            for col in ip_cols:
                sample = [r.get(col,"") for r in rows[:50] if r.get(col,"")]
                if any(_is_ip(v) for v in sample):
                    confirmed.append(col)
                    for row in rows:
                        ip = _extract_ip(row.get(col, ""))
                        if ip and _is_ip(row.get(col, "")):
                            all_ips.add(ip)
            if confirmed:
                ip_cols_by_op[op] = confirmed

        if not all_ips:
            yield emit("warn", "[~] No routable IP addresses found in detected IP columns.")
            yield f"data: {json.dumps({'cls': 'complete', 'geo_map': {}, 'ip_cols_by_op': {}})}\n\n"
            return

        unique_ips = sorted(all_ips)
        # Filter out already cached
        uncached = [ip for ip in unique_ips if ip not in _geo_cache]

        yield emit("info", f"[*] Found {len(unique_ips):,} unique routable IPs across {len(ip_cols_by_op)} operation(s)")
        yield emit("info", f"[*] IP columns detected: { {op: cols for op, cols in ip_cols_by_op.items()} }")
        if uncached:
            yield emit("info", f"[*] {len(uncached):,} IPs to look up ({len(unique_ips)-len(uncached):,} already cached)")
        else:
            yield emit("info", f"[*] All {len(unique_ips):,} IPs served from cache")

        # ── Step 2: Batch geolocate ─────────────────────────────────────────
        batches = [uncached[i:i+100] for i in range(0, len(uncached), 100)]
        if batches:
            yield emit("cmd", f"[*] Looking up {len(uncached):,} IPs in {len(batches)} batch(es) via ip-api.com...")

        min_interval = 60.0 / 44   # stay under 45 req/min

        for i, batch in enumerate(batches):
            if i > 0:
                time.sleep(min_interval)
            try:
                payload = json.dumps([
                    {"query": ip, "fields": GEO_FIELDS}
                    for ip in batch
                ]).encode()
                req = urllib.request.Request(
                    f"http://ip-api.com/batch?fields={GEO_FIELDS}",
                    data=payload,
                    headers={"Content-Type": "application/json", "User-Agent": "IR-Toolkit/1.0"},
                )
                with urllib.request.urlopen(req, timeout=15) as resp:
                    batch_results = json.loads(resp.read().decode())
                for geo in batch_results:
                    ip_key = geo.get("query", "")
                    _geo_cache[ip_key] = geo
                pct = round((i + 1) / len(batches) * 100)
                yield emit("progress", f"[{i+1}/{len(batches)}] Batch complete",
                           current=i+1, total=len(batches), pct=pct)
            except Exception as e:
                for ip in batch:
                    _geo_cache.setdefault(ip, None)
                yield emit("warn", f"[~] Batch {i+1} failed: {e}")

        # ── Step 3: Build geo_map { ip: label } and geo_coords { ip: {lat,lon} } ──
        geo_map    = {}
        geo_coords = {}
        success    = 0
        for ip in unique_ips:
            geo   = _geo_cache.get(ip)
            label = _format_geo(geo)
            geo_map[ip] = label
            if label:
                success += 1
            if geo and geo.get("lat") is not None and geo.get("lon") is not None:
                geo_coords[ip] = {"lat": geo["lat"], "lon": geo["lon"]}

        yield emit("done", f"[✓] Geolocation complete — {success:,} of {len(unique_ips):,} IPs resolved")
        yield f"data: {json.dumps({'cls': 'complete', 'geo_map': geo_map, 'ip_cols_by_op': ip_cols_by_op, 'geo_coords': geo_coords})}\n\n"

    return Response(generate(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

# ── Parse (SSE streaming with per-row progress) ────────────────────────────────
@ual_bp.route("/parse", methods=["POST"])
def parse():
    if "file" not in request.files:
        return jsonify({"error": "no file uploaded"}), 400

    f = request.files["file"]
    if not f.filename.lower().endswith(".csv"):
        return jsonify({"error": "expected a .csv file"}), 400

    try:
        content = f.read().decode("utf-8-sig", errors="replace")
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    total_lines = max(1, content.count('\n') - 1)

    def generate():
        # Immediately tell the client how many rows to expect
        yield f"data: {json.dumps({'cls': 'start', 'total': total_lines})}\n\n"

        rows_by_op = None
        parsed = errors = 0

        try:
            for event in _parse_ual_csv_gen(content):
                if event['type'] == 'progress':
                    yield f"data: {json.dumps({'cls': 'progress', 'pct': event['pct'], 'current': event['current'], 'total': event['total']})}\n\n"
                elif event['type'] == 'result':
                    rows_by_op = event['rows_by_op']
                    parsed     = event['parsed']
                    errors     = event['errors']
                elif event['type'] == 'error':
                    yield f"data: {json.dumps({'cls': 'error', 'text': event['message']})}\n\n"
                    return
        except Exception as exc:
            yield f"data: {json.dumps({'cls': 'error', 'text': str(exc)})}\n\n"
            return

        if rows_by_op is None:
            yield f"data: {json.dumps({'cls': 'error', 'text': 'Parse failed unexpectedly'})}\n\n"
            return

        summary = {
            "parsed": parsed,
            "errors": errors,
            "operations": {
                op: {
                    "count":   len(rows),
                    # Union of ALL preview-row keys so columns that only appear in
                    # some rows (e.g. FolderItem.Subject in newer records) are not
                    # silently dropped when row 0 happens to lack them.
                    "columns": list(dict.fromkeys(
                        k for row in rows[:500] for k in row.keys()
                    )),
                    "rows":    rows[:500],
                    "total":   len(rows),
                }
                for op, rows in rows_by_op.items()
            },
        }
        yield f"data: {json.dumps({'cls': 'complete', **summary})}\n\n"

    return Response(generate(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

# ── Row filter helper ─────────────────────────────────────────────────────────
def _row_filter_match(row, term, col=""):
    """Return True if the row matches ANY comma-separated search term (case-insensitive)."""
    terms = [t.strip().lower() for t in term.split(',') if t.strip()] if term else []
    if not terms:
        return True
    if col:
        val = str(row.get(col, "") or "").lower()
        return any(t in val for t in terms)
    vals = [str(v or "").lower() for v in row.values()]
    return any(any(t in v for v in vals) for t in terms)

# ── Full-file search (bypasses 500-row preview) ──────────────────────────────
@ual_bp.route("/search", methods=["POST"])
def search_full():
    """
    Re-parse the entire CSV and return ALL rows matching the search term.
    Streams SSE progress while parsing, then sends a 'complete' event with results.
    POST fields (multipart): file, term, col (optional column name)
    """
    if "file" not in request.files:
        return jsonify({"error": "no file"}), 400

    term = request.form.get("term", "").strip()
    col  = request.form.get("col",  "").strip()
    if not term:
        return jsonify({"error": "no search term provided"}), 400

    try:
        content = request.files["file"].read().decode("utf-8-sig", errors="replace")
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    total_lines = max(1, content.count('\n') - 1)

    def generate():
        yield f"data: {json.dumps({'cls': 'start', 'total': total_lines})}\n\n"

        matched_by_op = {}   # { op: [matching rows] }
        count_by_op   = {}   # { op: total matches in full file }
        total_scanned = 0

        try:
            for event in _parse_ual_csv_gen(content):
                if event['type'] == 'progress':
                    yield f"data: {json.dumps({'cls': 'progress', 'pct': event['pct'], 'current': event['current'], 'total': event['total']})}\n\n"
                elif event['type'] == 'result':
                    total_scanned = event['parsed']
                    for op, rows in event['rows_by_op'].items():
                        hits = [r for r in rows if _row_filter_match(r, term, col)]
                        if hits:
                            count_by_op[op]   = len(hits)
                            matched_by_op[op] = hits[:500]   # cap display at 500/op
                elif event['type'] == 'error':
                    yield f"data: {json.dumps({'cls': 'error', 'text': event['message']})}\n\n"
                    return
        except Exception as exc:
            yield f"data: {json.dumps({'cls': 'error', 'text': str(exc)})}\n\n"
            return

        # Build per-op result objects with union column sets
        results = {
            op: {
                "columns":        list(dict.fromkeys(k for r in rows for k in r.keys())),
                "rows":           rows,
                "total_matching": count_by_op[op],
            }
            for op, rows in matched_by_op.items()
        }
        total_matched = sum(count_by_op.values())
        yield f"data: {json.dumps({'cls': 'complete', 'results': results, 'total_matched': total_matched, 'total_scanned': total_scanned})}\n\n"

    return Response(generate(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

# ── Unique XLSX sheet name (deduplicates and strips illegal chars) ────────────
def _safe_sheet_name(op, used):
    base = re.sub(r'[\\/*?:\[\]]', '', op)[:31].strip() or "Sheet1"
    name = base
    n    = 2
    while name in used:
        suffix = f"_{n}"
        name   = base[:31 - len(suffix)] + suffix
        n += 1
    used.add(name)
    return name

# ── Sanitise a cell value for Excel ──────────────────────────────────────────
def _xl_cell(v):
    """Convert to string and clamp to Excel's 32,767 char cell limit."""
    if v is None:
        return ""
    s = str(v)
    return s[:_XL_MAX_CELL] if len(s) > _XL_MAX_CELL else s

# ── Export ─────────────────────────────────────────────────────────────────────
@ual_bp.route("/export", methods=["POST"])
def export():
    """
    POST fields (multipart):
      file         — the original UAL CSV
      format       — 'xlsx' | 'csv'
      operations   — JSON list of operation names to include (all if omitted)
      geo_map      — JSON { ip: label }   (optional)
      geo_cols     — JSON { op: [col] }   (optional)
      filter_term  — search string to apply as a row filter (optional)
      filter_col   — column to restrict filter to ('' = all columns)
    """
    if "file" not in request.files:
        return jsonify({"error": "no file uploaded"}), 400

    f            = request.files["file"]
    fmt          = request.form.get("format", "xlsx")
    ops_raw      = request.form.get("operations", "")
    wanted_ops   = json.loads(ops_raw) if ops_raw else None
    geo_map      = json.loads(request.form.get("geo_map",  "{}") or "{}")
    geo_cols     = json.loads(request.form.get("geo_cols", "{}") or "{}")
    filter_term  = request.form.get("filter_term", "").strip()
    filter_col   = request.form.get("filter_col",  "").strip()

    content = f.read().decode("utf-8-sig", errors="replace")
    rows_by_op, _, _ = _parse_ual_csv(content)

    # Filter to requested operations
    if wanted_ops:
        rows_by_op = {op: rows for op, rows in rows_by_op.items() if op in wanted_ops}

    # Apply search filter (re-filters the full dataset, not just the 500-row preview)
    if filter_term:
        rows_by_op = {
            op: [r for r in rows if _row_filter_match(r, filter_term, filter_col)]
            for op, rows in rows_by_op.items()
        }
        # Drop operations with no matching rows
        rows_by_op = {op: rows for op, rows in rows_by_op.items() if rows}

    # Inject geo columns right after each detected IP column
    if geo_map and geo_cols:
        for op, rows in rows_by_op.items():
            ip_col_list = geo_cols.get(op, [])
            if not ip_col_list or not rows:
                continue
            new_rows = []
            for row in rows:
                new_row = {}
                for k, v in row.items():
                    new_row[k] = v
                    if k in ip_col_list:
                        new_row[k + "_geo"] = geo_map.get(str(v or "").strip(), "")
                new_rows.append(new_row)
            rows_by_op[op] = new_rows

    if not rows_by_op:
        return jsonify({"error": "No data to export (all rows filtered out)."}), 400

    if fmt == "xlsx":
        buf        = io.BytesIO()
        used_names = set()
        with pd.ExcelWriter(buf, engine="openpyxl") as writer:
            for op, rows in rows_by_op.items():
                if not rows:
                    continue
                sheet = _safe_sheet_name(op, used_names)
                # Column union across all rows so fields that only appear in some rows
                # (e.g. FolderItem.Subject added by Microsoft to newer records) are not
                # silently dropped when row 0 happens to lack them.
                cols = list(dict.fromkeys(k for row in rows for k in row.keys()))
                data = [[_xl_cell(row.get(c)) for c in cols] for row in rows]
                df   = pd.DataFrame(data, columns=cols)
                df.to_excel(writer, sheet_name=sheet, index=False)
        buf.seek(0)
        return send_file(buf,
                         mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                         as_attachment=True, download_name="UAL_Export.xlsx")
    else:
        # Flat CSV — all operations merged
        all_rows = []
        for rows in rows_by_op.values():
            all_rows.extend(rows)
        if not all_rows:
            return jsonify({"error": "no data"}), 400
        # Build a superset of all columns so no data is lost when ops have different schemas
        all_cols = list(dict.fromkeys(c for row in all_rows for c in row.keys()))
        buf = io.StringIO()
        writer = csv.DictWriter(buf, fieldnames=all_cols, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(all_rows)
        return Response(buf.getvalue(), mimetype="text/csv",
                        headers={"Content-Disposition": "attachment; filename=UAL_Export.csv"})

# ── Impossible Travel ────────────────────────────────────────────────────────
def _haversine_km(lat1, lon1, lat2, lon2):
    """Great-circle distance in km between two lat/lon points."""
    R    = 6371
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a    = math.sin(dlat/2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon/2)**2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

def _row_ip(row):
    """Return the bare IP from common M365 IP column names."""
    return (row.get("ClientIP") or row.get("ClientIPAddress") or row.get("actorIpAddress") or "").strip()

@ual_bp.route("/travel", methods=["POST"])
def travel():
    """
    Impossible travel analysis across ALL UserLoggedIn rows.
    POST fields: file (CSV), geo_map (JSON), geo_coords (JSON { ip: {lat,lon} })
    Returns: { flags, total_rows, analyzed_pairs, skipped_no_ip, skipped_no_coords }
    """
    if "file" not in request.files:
        return jsonify({"error": "no file uploaded"}), 400

    geo_map    = json.loads(request.form.get("geo_map",    "{}") or "{}")
    geo_coords = json.loads(request.form.get("geo_coords", "{}") or "{}")

    if not geo_coords:
        return jsonify({"error": "No geo coordinate data found — run Geolocate IPs first."}), 400

    content = request.files["file"].read().decode("utf-8-sig", errors="replace")
    rows_by_op, _, _ = _parse_ual_csv(content)

    rows = rows_by_op.get("UserLoggedIn", [])
    if not rows:
        return jsonify({"error": "No UserLoggedIn operation found in this file."}), 400

    SPEED_LIMIT_KMH = 900

    # Group by UserId
    by_user = {}
    for row in rows:
        user = (row.get("UserId") or row.get("UserID") or "Unknown").strip()
        by_user.setdefault(user, []).append(row)

    flags             = []
    analyzed_pairs    = 0
    skipped_no_ip     = 0
    skipped_no_coords = 0
    skipped_date_err  = 0

    for user, user_rows in by_user.items():
        try:
            sorted_rows = sorted(user_rows, key=lambda r: r.get("CreationDate") or "")
        except Exception:
            sorted_rows = user_rows

        for i in range(1, len(sorted_rows)):
            prev = sorted_rows[i - 1]
            curr = sorted_rows[i]

            ip1 = _row_ip(prev)
            ip2 = _row_ip(curr)
            if not ip1 or not ip2:
                skipped_no_ip += 1
                continue
            if ip1 == ip2:
                continue

            c1 = geo_coords.get(ip1)
            c2 = geo_coords.get(ip2)
            if not c1 or not c2:
                skipped_no_coords += 1
                continue

            analyzed_pairs += 1

            try:
                t1 = datetime.fromisoformat(prev["CreationDate"].replace(" ", "T"))
                t2 = datetime.fromisoformat(curr["CreationDate"].replace(" ", "T"))
                delta_hours = (t2 - t1).total_seconds() / 3600
            except Exception:
                skipped_date_err += 1
                continue

            if delta_hours < 0:
                continue

            dist_km   = _haversine_km(float(c1["lat"]), float(c1["lon"]),
                                      float(c2["lat"]), float(c2["lon"]))
            speed_kmh = (dist_km / delta_hours) if delta_hours > 0 else None  # None = simultaneous

            if (speed_kmh is None and dist_km > 0) or (speed_kmh and speed_kmh > SPEED_LIMIT_KMH):
                flags.append({
                    "user":        user,
                    "t1":          prev.get("CreationDate", ""),
                    "ip1":         ip1,
                    "loc1":        geo_map.get(ip1, ip1),
                    "t2":          curr.get("CreationDate", ""),
                    "ip2":         ip2,
                    "loc2":        geo_map.get(ip2, ip2),
                    "delta_hours": round(delta_hours, 4),
                    "dist_km":     round(dist_km, 1),
                    "speed_kmh":   round(speed_kmh, 1) if speed_kmh is not None else None,
                })

    return jsonify({
        "flags":             flags,
        "total_rows":        len(rows),
        "analyzed_pairs":    analyzed_pairs,
        "skipped_no_ip":     skipped_no_ip,
        "skipped_no_coords": skipped_no_coords,
        "skipped_date_err":  skipped_date_err,
    })

# ── Core parser ───────────────────────────────────────────────────────────────

def _is_name_value_list(lst):
    """
    Return True when every element of lst is a dict with at least a string 'Name'
    key and a 'Value' key — the Name/Value pair pattern used by M365 for arrays
    like Parameters, ExtendedProperties, etc.
    """
    return bool(lst) and all(
        isinstance(item, dict)
        and isinstance(item.get("Name"), str)
        and "Value" in item
        for item in lst
    )

def _flatten_json(obj, prefix=""):
    """
    Recursively flatten a dict into a single-level dict of column→value pairs.

    Special handling for arrays of {Name, Value} dicts (common in M365 UAL):
      Parameters = [{"Name":"From","Value":"x@y.com"}, ...]
    becomes:
      Parameters.From = "x@y.com"
    rather than:
      Parameters[0].Name = "From", Parameters[0].Value = "x@y.com"

    All other lists keep the index-based fallback.
    """
    flat = {}
    for key, value in obj.items():
        full_key = f"{prefix}{key}"

        if isinstance(value, dict):
            flat.update(_flatten_json(value, full_key + "."))

        elif isinstance(value, list):
            if _is_name_value_list(value):
                # Pivot: use Name as column suffix, Value as cell value
                seen = {}  # dedup tracker for duplicate Names
                for item in value:
                    name = str(item["Name"])
                    # Deduplicate: append _2, _3 ... for repeated names
                    count = seen.get(name, 0) + 1
                    seen[name] = count
                    col = f"{full_key}.{name}" if count == 1 else f"{full_key}.{name}_{count}"
                    val = item["Value"]
                    if isinstance(val, dict):
                        flat.update(_flatten_json(val, col + "."))
                    elif isinstance(val, list):
                        # Nested list inside a Value — store as JSON string
                        flat[col] = json.dumps(val)
                    else:
                        flat[col] = val
            else:
                # Generic list — index-based expansion
                for i, item in enumerate(value):
                    if isinstance(item, dict):
                        flat.update(_flatten_json(item, f"{full_key}[{i}]."))
                    else:
                        flat[f"{full_key}[{i}]"] = item

        else:
            flat[full_key] = value

    return flat

def _postprocess_row(row, audit_col=None):
    """
    Apply in-place post-processing to a flattened row dict:
      1. Remove the raw AuditData blob column.
      2. Split any IP:port / [IPv6]:port cell values into two columns.
      3. Normalise CreationDate to YYYY-MM-DDTHH:MM:SS.
    """
    # 1. Remove AuditData blob (by canonical names and the detected column name)
    row.pop("AuditData", None)
    row.pop("auditdata", None)
    if audit_col:
        row.pop(audit_col, None)

    # 2. IP:port splitting
    for col in list(row.keys()):
        raw = str(row.get(col) or "").strip()
        ip, port = _parse_ip_port(raw)
        if ip and port:
            row[col]           = ip
            row[col + "_Port"] = port

    # 3. Normalise CreationDate
    cd_raw = row.get("CreationDate")
    if cd_raw:
        try:
            cd = str(cd_raw).strip()
            if "T" in cd or (len(cd) > 4 and cd[:4].isdigit()):
                row["CreationDate"] = cd.split(".")[0].split("Z")[0]
            elif "/" in cd:
                fmt = "%m/%d/%Y %H:%M:%S" if cd.count(":") >= 2 else "%m/%d/%Y %H:%M"
                row["CreationDate"] = datetime.strptime(cd, fmt).strftime("%Y-%m-%dT%H:%M:%S")
        except Exception:
            pass


def _explode_mail_items(audit_obj, csv_base):
    """
    Explode a MailItemsAccessed AuditData object into one row per accessed message.

    M365 bundles multiple accessed messages into a single UAL record:
      Folders = [{ "Id": ..., "Path": "\\Inbox",
                   "FolderItems": [{ "Id":..., "ImmutableId":...,
                                     "InternetMessageId":..., "SizeInBytes":... }, ...] }]

    This function returns a list of flat row dicts — one per FolderItem — each
    containing the full parent-record metadata plus clean per-message columns:
      Folder.Id, Folder.Path,
      FolderItem.Id, FolderItem.ImmutableId,
      FolderItem.InternetMessageId, FolderItem.SizeInBytes

    If the record has no FolderItems (e.g., sync-style access), one base row is
    returned with just the folder path (no per-item columns).

    csv_base  — dict of the raw CSV fields, excluding the AuditData blob column
    audit_obj — the parsed AuditData JSON dict
    """
    folders = audit_obj.get("Folders") or []

    # Flatten everything in the audit object EXCEPT the Folders array itself
    base_audit = {k: v for k, v in audit_obj.items() if k != "Folders"}
    base_flat  = _flatten_json(base_audit)

    # Merge: CSV fields first (so audit fields can override / add to them)
    base_merged = dict(csv_base)
    base_merged.update(base_flat)

    rows = []
    for folder in folders:
        # Flatten all folder-level fields (everything except FolderItems itself)
        folder_meta = {k: v for k, v in folder.items() if k != "FolderItems"}
        flat_folder = _flatten_json(folder_meta, prefix="Folder.")

        items = folder.get("FolderItems") or []
        for item in items:
            r = dict(base_merged)
            r.update(flat_folder)
            # Dynamically flatten ALL fields from the item — picks up Subject,
            # SenderAddress, RecipientAddress, or anything else Microsoft adds
            r.update(_flatten_json(item, prefix="FolderItem."))
            rows.append(r)

        if not items:
            # Folder present but no individual items (sync/aggregate access)
            r = dict(base_merged)
            r.update(flat_folder)
            rows.append(r)

    if not rows:
        # Fallback: no Folders at all — return a single base row
        rows = [dict(base_merged)]

    return rows


def _parse_ual_csv_gen(content, progress_interval=2500):
    """
    Generator that parses a UAL CSV and yields two kinds of dicts:
      {'type': 'progress', 'current': N, 'total': T, 'pct': P}  — every progress_interval rows
      {'type': 'result',   'rows_by_op': ..., 'parsed': N, 'errors': N}  — once at the end
      {'type': 'error',    'message': '...'}                             — on fatal errors

    Set progress_interval=0 to suppress progress yields (used by blocking callers).
    """
    total_lines = max(1, content.count('\n') - 1)   # fast estimate from newline count
    rows_by_op  = {}
    parsed      = 0
    errors      = 0

    reader     = csv.DictReader(io.StringIO(content))
    fieldnames = reader.fieldnames or []
    audit_col  = next((f for f in fieldnames if f.strip().lower() == "auditdata"), None)
    if not audit_col:
        yield {'type': 'error',
               'message': 'No AuditData column found. Is this a valid M365 UAL export?'}
        return

    for i, row in enumerate(reader):
        try:
            audit_raw = row.get(audit_col, "").strip()
            audit_obj = {}
            if audit_raw:
                try:
                    audit_obj = json.loads(audit_raw)
                except json.JSONDecodeError:
                    errors += 1

            operation = (audit_obj.get("Operation")
                         or row.get("Operation")
                         or "Unknown")

            if operation == "MailItemsAccessed" and isinstance(audit_obj.get("Folders"), list):
                csv_base = {k: v for k, v in row.items() if k != audit_col}
                for r in _explode_mail_items(audit_obj, csv_base):
                    _postprocess_row(r, audit_col)
                    rows_by_op.setdefault(operation, []).append(r)
                    parsed += 1
            else:
                flat = _flatten_json(audit_obj)
                row.update(flat)
                _postprocess_row(row, audit_col)
                operation = row.get("Operation", "Unknown")
                rows_by_op.setdefault(operation, []).append(dict(row))
                parsed += 1

        except Exception:
            errors += 1

        # Yield progress periodically
        if progress_interval and (i + 1) % progress_interval == 0:
            pct = min(98, round((i + 1) / total_lines * 100))
            yield {'type': 'progress',
                   'current': i + 1, 'total': total_lines, 'pct': pct}

    yield {'type': 'result',
           'rows_by_op': rows_by_op, 'parsed': parsed, 'errors': errors}


def _parse_ual_csv(content):
    """Blocking wrapper around _parse_ual_csv_gen. Used by export / travel endpoints."""
    for event in _parse_ual_csv_gen(content, progress_interval=0):
        if event['type'] == 'result':
            return event['rows_by_op'], event['parsed'], event['errors']
        if event['type'] == 'error':
            raise ValueError(event['message'])
    return {}, 0, 0


# ── Detection rules ────────────────────────────────────────────────────────────

_PERSISTENCE_OPS = {
    "addserviceprincipal",
    "consent to application",
    "add delegated permission",
    "add app role assignment to service principal",
    "add member to role",
    "set federation settings on domain",
    "add owner to application",
    "add owner to service principal",
}

_MFA_OPS = {
    "disable strong authentication",
    "delete userstrongauthenticationmtd",
    "admindeletedusercredential",
    "userstrongauthenticationmethoddeletedbyuser",
}

_SHAREPOINT_SENSITIVE_KW = [
    "password", "secret", "confidential", "salary", "ssn",
    "social security", "credit card", "private key", "api key",
    "token", "vpn", "credential",
]


def _suspicious_inbox_name(name):
    """Return True if a New-InboxRule name looks attacker-created."""
    if name is None:
        return False
    name = str(name).strip()
    if not name:
        return False
    if len(name) <= 2:
        return True
    if not any(c.isalpha() for c in name):
        return True
    return False


def _detect_device_code_phishing(rows_by_op):
    rows = rows_by_op.get("UserLoggedIn", [])
    hits = [r for r in rows
            if str(r.get("ExtendedProperties.RequestType", "") or "").strip().lower() == "cmsi:cmsi"]
    if not hits:
        return None
    return {
        "rule": "Device Code Phishing",
        "severity": "HIGH",
        "description": (
            "UserLoggedIn events with ExtendedProperties.RequestType = 'Cmsi:Cmsi' indicate "
            "device code authentication — used in device code phishing attacks where attackers "
            "trick users into authenticating to attacker-controlled devices."
        ),
        "count": len(hits),
        "rows": hits[:200],
        "columns": list(dict.fromkeys(k for r in hits[:50] for k in r.keys())),
    }


def _detect_suspicious_inbox_rules(rows_by_op):
    rows = rows_by_op.get("New-InboxRule", [])
    hits = []
    for row in rows:
        name = row.get("Parameters.Name") or row.get("Name") or ""
        if _suspicious_inbox_name(name):
            hits.append(row)
    if not hits:
        return None
    return {
        "rule": "Suspicious Inbox Rule Name",
        "severity": "HIGH",
        "description": (
            "New-InboxRule events with a suspicious name — very short (≤2 characters) or "
            "containing no alphabetic characters. Threat actors commonly name inbox rules "
            "with single characters or punctuation to avoid detection."
        ),
        "count": len(hits),
        "rows": hits[:200],
        "columns": list(dict.fromkeys(k for r in hits[:50] for k in r.keys())),
    }


def _detect_persistence_operations(rows_by_op):
    hits = []
    for op, rows in rows_by_op.items():
        if op.lower() in _PERSISTENCE_OPS:
            hits.extend(rows)
    if not hits:
        return None
    ops_found = sorted({str(r.get("Operation", "")) for r in hits})
    return {
        "rule": "Persistence / Privilege Operations",
        "severity": "HIGH",
        "description": (
            "Rare operations associated with persistence or privilege escalation: "
            f"{', '.join(ops_found)}. These include service principal creation, application "
            "consent, delegated permission grants, role assignments, and federation changes."
        ),
        "count": len(hits),
        "rows": hits[:200],
        "columns": list(dict.fromkeys(k for r in hits[:50] for k in r.keys())),
    }


def _detect_python_useragent(rows_by_op):
    hits = []
    for op, rows in rows_by_op.items():
        if not rows:
            continue
        all_cols = list(dict.fromkeys(k for r in rows[:10] for k in r.keys()))
        ua_cols = [c for c in all_cols if "useragent" in c.lower()]
        for row in rows:
            for col in ua_cols:
                if "python" in str(row.get(col, "") or "").lower():
                    hits.append(row)
                    break
    if not hits:
        return None
    return {
        "rule": "Python UserAgent",
        "severity": "MEDIUM",
        "description": (
            "Events with a UserAgent string containing 'python', indicating a Python HTTP library "
            "(e.g. requests, urllib). May indicate automated scripted access, data harvesting, "
            "or attacker tooling."
        ),
        "count": len(hits),
        "rows": hits[:200],
        "columns": list(dict.fromkeys(k for r in hits[:50] for k in r.keys())),
    }


def _detect_sharepoint_search(rows_by_op):
    rows = rows_by_op.get("SearchQueryInitiatedSharePoint", [])
    if not rows:
        return None
    sensitive_hits = []
    by_user = {}
    for row in rows:
        user = str(row.get("UserId") or row.get("UserID") or "Unknown")
        by_user.setdefault(user, []).append(row)
        row_text = " ".join(str(v or "").lower() for v in row.values())
        if any(kw in row_text for kw in _SHAREPOINT_SENSITIVE_KW):
            sensitive_hits.append(row)
    heavy_searchers = {u: r for u, r in by_user.items() if len(r) >= 5}
    severity = "MEDIUM"
    detail_parts = [f"{len(rows)} SharePoint search queries detected"]
    if sensitive_hits:
        severity = "HIGH"
        detail_parts.append(
            f"{len(sensitive_hits)} contain sensitive keywords (password, secret, credential, etc.)"
        )
    if heavy_searchers:
        severity = "HIGH"
        names = ", ".join(sorted(heavy_searchers)[:5])
        detail_parts.append(f"{len(heavy_searchers)} user(s) performed ≥5 searches: {names}")
    return {
        "rule": "SharePoint Search Activity",
        "severity": severity,
        "description": (
            "SearchQueryInitiatedSharePoint events detected — threat actors search SharePoint "
            f"to locate sensitive files before exfiltration. {'; '.join(detail_parts)}."
        ),
        "count": len(rows),
        "rows": rows[:200],
        "columns": list(dict.fromkeys(k for r in rows[:50] for k in r.keys())),
    }


def _detect_mass_download(rows_by_op):
    WINDOW_MINUTES = 10
    THRESHOLD = 50
    download_ops = ["FileDownloaded", "FileSyncDownloadedFull", "FileDownloadOperation"]
    all_rows = []
    for op in download_ops:
        all_rows.extend(rows_by_op.get(op, []))
    if not all_rows:
        return None
    by_user = {}
    for row in all_rows:
        user = str(row.get("UserId") or row.get("UserID") or "Unknown")
        by_user.setdefault(user, []).append(row)
    hits = []
    flagged_users = []
    for user, user_rows in by_user.items():
        dated = []
        for row in user_rows:
            try:
                t = datetime.fromisoformat(str(row["CreationDate"]).replace(" ", "T"))
                dated.append((t, row))
            except Exception:
                pass
        dated.sort(key=lambda x: x[0])
        for i, (t_start, _) in enumerate(dated):
            window = [r for t, r in dated[i:]
                      if (t - t_start).total_seconds() <= WINDOW_MINUTES * 60]
            if len(window) >= THRESHOLD:
                flagged_users.append(f"{user} ({len(window)} in {WINDOW_MINUTES}m)")
                hits.extend(window)
                break
    if not hits:
        return None
    return {
        "rule": "Mass File Download",
        "severity": "HIGH",
        "description": (
            f"User(s) downloaded ≥{THRESHOLD} files within a {WINDOW_MINUTES}-minute window — "
            f"a potential data exfiltration indicator. Flagged: {'; '.join(flagged_users[:10])}."
        ),
        "count": len(hits),
        "rows": hits[:200],
        "columns": list(dict.fromkeys(k for r in hits[:50] for k in r.keys())),
    }


def _detect_mfa_manipulation(rows_by_op):
    hits = []
    for op, rows in rows_by_op.items():
        op_lower = op.lower()
        if op_lower in _MFA_OPS:
            hits.extend(rows)
        elif op_lower == "update user":
            for row in rows:
                row_text = " ".join(str(v or "").lower() for v in row.values())
                if "strongauthentication" in row_text:
                    hits.append(row)
    if not hits:
        return None
    return {
        "rule": "MFA Manipulation",
        "severity": "HIGH",
        "description": (
            "Events indicating MFA modification or disabling: explicit MFA disable operations "
            "or user update events affecting StrongAuthentication properties."
        ),
        "count": len(hits),
        "rows": hits[:200],
        "columns": list(dict.fromkeys(k for r in hits[:50] for k in r.keys())),
    }


def _detect_mail_geo_anomaly(rows_by_op, geo_map):
    if not geo_map:
        return None
    mail_rows  = rows_by_op.get("MailItemsAccessed", [])
    login_rows = rows_by_op.get("UserLoggedIn",      [])
    if not mail_rows or not login_rows:
        return None

    def _country(ip):
        geo = geo_map.get(ip, "")
        base = geo.split("[")[0].strip()
        parts = [p.strip() for p in base.split(",")]
        return parts[-1] if parts else ""

    login_countries = {}
    for row in login_rows:
        user = str(row.get("UserId") or "Unknown")
        ip   = (row.get("ClientIP") or row.get("ClientIPAddress") or "").strip()
        country = _country(ip)
        if country:
            login_countries.setdefault(user, set()).add(country)

    hits = []
    for row in mail_rows:
        user    = str(row.get("UserId") or "Unknown")
        ip      = (row.get("ClientIP") or row.get("ClientIPAddress") or "").strip()
        country = _country(ip)
        if not country:
            continue
        known = login_countries.get(user, set())
        if known and country not in known:
            hits.append(row)
    if not hits:
        return None
    return {
        "rule": "MailItemsAccessed Geo Anomaly",
        "severity": "MEDIUM",
        "description": (
            "MailItemsAccessed events from IP addresses in countries not seen in UserLoggedIn "
            "for the same user. May indicate an adversary reading email from a different location "
            "than the user's normal sign-in locations."
        ),
        "count": len(hits),
        "rows": hits[:200],
        "columns": list(dict.fromkeys(k for r in hits[:50] for k in r.keys())),
    }


def _detect_impossible_travel(rows_by_op, geo_map, geo_coords):
    """Flag consecutive UserLoggedIn events requiring impossible travel speed (>900 km/h)."""
    SPEED_LIMIT_KMH = 900
    rows = rows_by_op.get("UserLoggedIn", [])
    if not rows or not geo_coords:
        return None

    by_user = {}
    for row in rows:
        user = (row.get("UserId") or row.get("UserID") or "Unknown").strip()
        by_user.setdefault(user, []).append(row)

    flags = []
    for user, user_rows in by_user.items():
        try:
            sorted_rows = sorted(user_rows, key=lambda r: r.get("CreationDate") or "")
        except Exception:
            sorted_rows = user_rows

        for i in range(1, len(sorted_rows)):
            prev, curr = sorted_rows[i - 1], sorted_rows[i]
            ip1 = (prev.get("ClientIP") or prev.get("ClientIPAddress") or prev.get("actorIpAddress") or "").strip()
            ip2 = (curr.get("ClientIP") or curr.get("ClientIPAddress") or curr.get("actorIpAddress") or "").strip()
            if not ip1 or not ip2 or ip1 == ip2:
                continue
            c1 = geo_coords.get(ip1)
            c2 = geo_coords.get(ip2)
            if not c1 or not c2:
                continue
            try:
                t1 = datetime.fromisoformat(prev["CreationDate"].replace(" ", "T"))
                t2 = datetime.fromisoformat(curr["CreationDate"].replace(" ", "T"))
                delta_hours = (t2 - t1).total_seconds() / 3600
            except Exception:
                continue
            if delta_hours < 0:
                continue
            dist_km   = _haversine_km(float(c1["lat"]), float(c1["lon"]),
                                      float(c2["lat"]), float(c2["lon"]))
            speed_kmh = (dist_km / delta_hours) if delta_hours > 0 else None
            if (speed_kmh is None and dist_km > 0) or (speed_kmh and speed_kmh > SPEED_LIMIT_KMH):
                flags.append({
                    "User":               user,
                    "From_Time":          prev.get("CreationDate", ""),
                    "From_IP":            ip1,
                    "From_Location":      geo_map.get(ip1, ip1),
                    "To_Time":            curr.get("CreationDate", ""),
                    "To_IP":              ip2,
                    "To_Location":        geo_map.get(ip2, ip2),
                    "Distance_km":        round(dist_km, 1),
                    "Required_Speed_kmh": round(speed_kmh, 1) if speed_kmh is not None else "∞ (simultaneous)",
                    "Delta_hours":        round(delta_hours, 4),
                })

    if not flags:
        return None
    users = sorted({f["User"] for f in flags})
    return {
        "rule": "Impossible Travel",
        "severity": "HIGH",
        "description": (
            f"Consecutive UserLoggedIn events for the same account require travel speeds "
            f"exceeding {SPEED_LIMIT_KMH} km/h — physically impossible. "
            f"{len(flags)} instance(s) across {len(users)} user(s): {', '.join(users[:5])}."
        ),
        "count": len(flags),
        "rows":    flags,
        "columns": ["User", "From_Time", "From_IP", "From_Location",
                    "To_Time", "To_IP", "To_Location",
                    "Distance_km", "Required_Speed_kmh", "Delta_hours"],
    }


_DETECTION_RULES = [
    _detect_device_code_phishing,
    _detect_suspicious_inbox_rules,
    _detect_persistence_operations,
    _detect_python_useragent,
    _detect_sharepoint_search,
    _detect_mass_download,
    _detect_mfa_manipulation,
]


@ual_bp.route("/detections", methods=["POST"])
def run_detections():
    """
    Run all detection rules over the UAL CSV.
    POST fields (multipart): file (CSV), geo_map (JSON, optional), geo_coords (JSON, optional)
    Returns: { findings, geo_available }
    """
    if "file" not in request.files:
        return jsonify({"error": "no file uploaded"}), 400

    geo_map    = json.loads(request.form.get("geo_map",    "{}") or "{}")
    geo_coords = json.loads(request.form.get("geo_coords", "{}") or "{}")
    content    = request.files["file"].read().decode("utf-8-sig", errors="replace")
    rows_by_op, _, _ = _parse_ual_csv(content)

    findings = []
    for fn in _DETECTION_RULES:
        try:
            result = fn(rows_by_op)
            if result:
                findings.append(result)
        except Exception as e:
            print(f"[UAL detections] {fn.__name__} failed: {e}")

    # Geo-dependent rules
    for geo_fn, args in [
        (_detect_mail_geo_anomaly,    (rows_by_op, geo_map)),
        (_detect_impossible_travel,   (rows_by_op, geo_map, geo_coords)),
    ]:
        try:
            result = geo_fn(*args)
            if result:
                findings.append(result)
        except Exception as e:
            print(f"[UAL detections] {geo_fn.__name__} failed: {e}")

    return jsonify({"findings": findings, "geo_available": bool(geo_coords)})
